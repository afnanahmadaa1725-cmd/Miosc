"""أدوات مساعدة للقالب المدفوع."""

from pathlib import Path


def safe_filename(name: str, user_id: int) -> str:
    return f"{user_id}_{Path(name).name.replace(chr(0), '').strip() or 'audio.bin'}"
