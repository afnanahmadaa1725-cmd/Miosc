"""Live free-tier subscription checks and factory broadcast registration."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from database.connection import Database
from database.models import BotSubscriber, ForcedSub, SubscriptionCheck

logger = logging.getLogger("music-bot-factory")
_subscriber_lock = asyncio.Lock()
GROUP_COMMANDS = {
    "الانتظار",
    "queue",
    "بنك",
    "ping",
    "الاوامر",
    "الاعدادات",
    "الإعدادات",
    "اعدادات",
    "settings",
    "الضبط",
    "تفعيل",
    "الادمنيه",
    "الادمنية",
    "الإدمنيه",
    "الإدمنية",
    "الاحصائيات",
    "الإحصائيات",
    "احصائيات",
    "إحصائيات",
    "تخطي",
    "skip",
    "وقف",
    "pause",
    "توقف",
    "استئناف",
    "resume",
    "تشغيل",
    "انهاء",
    "إنهاء",
    "stop",
    "تكرار",
    "كتم",
    "الغاء_الكتم",
    "إلغاء_الكتم",
    "السجل",
    "history",
    "اصلاح",
    "إصلاح",
    "fix",
    "ايدي",
    "id",
    "تحذير",
    "تنظيف",
}


def _is_bot_interaction(event) -> bool:
    if hasattr(event, "data") and hasattr(event, "message"):
        return True
    if event.chat.type == "private":
        command = (
            event.text.split(maxsplit=1)[0].split("@", maxsplit=1)[0].casefold()
            if event.text
            else ""
        )
        return command != "/start"
    if event.chat.type not in {"group", "supergroup"} or not event.text:
        return False
    text = re.sub(r"\s+", " ", event.text.strip()).casefold()
    return text.startswith("/") or text in GROUP_COMMANDS or bool(
        re.match(
            r"^(?:شغل|تشغيل|play|اضافة|إضافة|اضف|add|يوت|يوتيوب|رفع|تنزيل|قفل|فتح|"
            r"تقديم|ارجع|حذف|اضف صورة|اضف صوره|الغاء|إلغاء)(?:\s|_|$)",
            text,
        )
    )


async def _record_subscriber(
    database: Database, bot_id: int, user_id: int
) -> None:
    async with _subscriber_lock:
        try:
            async with database.session() as session:
                exists = await session.scalar(
                    select(BotSubscriber.id).where(
                        BotSubscriber.bot_id == bot_id,
                        BotSubscriber.user_id == user_id,
                    )
                )
                if exists is None:
                    session.add(BotSubscriber(bot_id=bot_id, user_id=user_id))
                    await session.commit()
        except IntegrityError:
            logger.info(
                "Subscriber registration raced for user %s and bot %s",
                user_id,
                bot_id,
                exc_info=True,
            )
        except Exception:
            logger.exception(
                "Could not register user %s for factory broadcast on bot %s",
                user_id,
                bot_id,
            )


async def _check_subscriptions_with_factory(
    database: Database, bot_id: int, user_id: int
) -> tuple[set[str], str | None]:
    request_id = uuid4().hex
    async with database.session() as session:
        session.add(
            SubscriptionCheck(
                request_id=request_id,
                bot_id=bot_id,
                user_id=user_id,
            )
        )
        await session.commit()

    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        async with database.session() as session:
            request = await session.get(SubscriptionCheck, request_id)
            if request is None:
                raise RuntimeError("اختفى طلب التحقق قبل اكتماله.")
            if request.status == "done":
                missing = set(json.loads(request.missing_chat_ids))
                error = request.error
                await session.delete(request)
                await session.commit()
                return missing, error
        await asyncio.sleep(0.25)

    async with database.session() as session:
        request = await session.get(SubscriptionCheck, request_id)
        if request and request.status == "done":
            missing = set(json.loads(request.missing_chat_ids))
            error = request.error
            await session.delete(request)
            await session.commit()
            return missing, error
        if request and request.status == "pending":
            await session.delete(request)
            await session.commit()
    return set(), "تأخر رد بوت الصانع المركزي؛ حاول التحقق مرة أخرى."


async def _ptb_subscription_keyboard(
    database: Database, missing_chat_ids: set[str]
):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    async with database.session() as session:
        channels = (
            await session.execute(select(ForcedSub).order_by(ForcedSub.id))
        ).scalars().all()
    rows = [
        [
            InlineKeyboardButton(
                text=channel.title or "اشترك",
                url=channel.invite_link,
                style="success",
            )
        ]
        for channel in channels
        if channel.chat_id in missing_chat_ids
    ]
    rows.append(
        [
            InlineKeyboardButton(
                text="تحقق من الاشتراك",
                callback_data="factory:check_sub",
                style="success",
            )
        ]
    )
    return InlineKeyboardMarkup(rows)


class PTBFactoryFreeAccessHandler:
    def __init__(self, database: Database, bot_id: int) -> None:
        self.database = database
        self.bot_id = bot_id

    async def __call__(
        self, update: Update, context
    ) -> None:
        from telegram.ext import ApplicationHandlerStop

        user = update.effective_user
        event = update.callback_query or update.effective_message
        if user is None or user.is_bot or event is None:
            return
        is_start = (
            update.message is not None
            and bool(update.message.text)
            and update.message.text.split(maxsplit=1)[0]
            .split("@", maxsplit=1)[0]
            .casefold()
            == "/start"
        )
        if not (_is_bot_interaction(event) or is_start):
            return
        await _record_subscriber(self.database, self.bot_id, user.id)
        if (
            update.callback_query is not None
            and update.callback_query.data == "factory:check_sub"
        ):
            return

        missing, error = await _check_subscriptions_with_factory(
            self.database, self.bot_id, user.id
        )
        if not missing and not error:
            return

        keyboard = await _ptb_subscription_keyboard(self.database, missing)
        prompt = (
            error
            or "اشترك في القنوات المطلوبة من بوت الصانع المركزي ثم اضغط "
            "«تحقق من الاشتراك»."
        )
        if update.callback_query is not None:
            if update.callback_query.message is not None:
                await update.callback_query.message.reply_text(
                    prompt, reply_markup=keyboard
                )
            await update.callback_query.answer(
                error or "اشترك في القنوات المطلوبة أولاً.",
                show_alert=True,
            )
        elif update.effective_message is not None:
            await update.effective_message.reply_text(
                prompt, reply_markup=keyboard
            )
        raise ApplicationHandlerStop


def install_free_tier_features_ptb(
    application, database: Database, bot_id: int
) -> None:
    from telegram import Update
    from telegram.ext import CallbackQueryHandler, TypeHandler

    application.add_handler(
        TypeHandler(
            Update,
            PTBFactoryFreeAccessHandler(database, bot_id),
        ),
        group=-1,
    )

    async def recheck_subscription(
        update: Update, context
    ) -> None:
        callback = update.callback_query
        if callback is None:
            return
        missing, error = await _check_subscriptions_with_factory(
            database, bot_id, callback.from_user.id
        )
        if missing or error:
            keyboard = await _ptb_subscription_keyboard(database, missing)
            if callback.message is not None:
                await callback.message.edit_reply_markup(reply_markup=keyboard)
            await callback.answer(
                error or "لم يكتمل الاشتراك في جميع القنوات المطلوبة.",
                show_alert=True,
            )
            return
        await callback.answer("تم التحقق من اشتراكك بنجاح.")
        if callback.message is not None:
            await callback.message.edit_reply_markup(reply_markup=None)

    application.add_handler(
        CallbackQueryHandler(
            recheck_subscription,
            pattern=r"^factory:check_sub$",
        )
    )
