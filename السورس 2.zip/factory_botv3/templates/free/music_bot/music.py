"""بوت موسيقى للمجموعات: python-telegram-bot للبوت وTelethon/PyTgCalls للمساعد."""

import asyncio
from html import escape
import json
import inspect
import logging
import os
import re
import sqlite3
import tempfile
import time
from time import perf_counter
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from uuid import uuid4

import yt_dlp
from telegram import (
    Bot,
    CallbackQuery,
    ChatMemberUpdated,
    ChatPermissions,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
    Update,
)
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    ChatMemberHandler,
    CommandHandler,
    MessageHandler,
    filters,
)
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.users import GetFullUserRequest

import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("music-bot")


class PTBMessageAdapter:
    def __init__(self, message: Message) -> None:
        self._message = message

    def __getattr__(self, name):
        return getattr(self._message, name)

    async def answer(self, text: str, **kwargs):
        return await self._message.reply_text(text, **kwargs)

    async def answer_photo(self, photo, **kwargs):
        return await self._message.reply_photo(photo=photo, **kwargs)

    async def answer_audio(self, audio, **kwargs):
        return await self._message.reply_audio(audio=audio, **kwargs)

    async def delete(self):
        return await self._message.delete()

FLASH_KICK_ALERT_THRESHOLD = 5
FLASH_KICK_DEMOTION_THRESHOLD = 10
HELPER_SETUP_TEXT = (
    "• عند التشغيل يحاول حساب المساعد الانضمام للمجموعة والمكالمة ليبدأ البث الصوتي ♫"
    if config.HAS_HELPER_SESSION
    else "• أضف جلسة مساعد من إدارة الصانع لتفعيل تشغيل الموسيقى في المكالمات."
)
HELPER_START_TEXT = (
    "♥︎ يتم تفعيل البوت وانضمام المساعد تلقائياً"
    if config.HAS_HELPER_SESSION
    else "♥︎ يعمل البوت فوراً؛ أضف جلسة مساعد من الصانع لتشغيل الموسيقى بالمكالمات"
)

SETTINGS_TEXT = (
    "✿ انت الان بداخل اعدادات البوت النصية من هنا يمكنك التحكم بالبوت باستخدام الاوامر التالية ♥︎♫\n"
    "• امر شغل + اسم الاغنية: لبدأ تشغيل الاغنية.\n"
    "• امر ايقاف: لايقاف تشغيل الاغنية مؤقتاً.\n"
    "• امر استئناف: لاستئناف التشغيل.\n"
    "• امر الاعدادات: لعرض قائمة الاعدادات الحالية.\n"
    "• امر انهاء: لايقاف الاغنية وتفريغ قائمة الانتظار.\n"
    "• امر تخطي: للانتقال الى الاغنية التالية.\n"
    "• امر السجل: لعرض سجل التشغيل والاغاني المضافة.\n"
    "• امر اصلاح: تنظيف السجل واصلاح المشاكل المؤقتة.\n"
    "• امر اضافة + اسم الاغنية: لاضافة اغنية لقائمة الانتظار.\n"
    "• اضف البوت في المجموعة بصلاحية مشرف، ثم شغّل المكالمة الصوتية واستخدم الاوامر.\n"
    f"{HELPER_SETUP_TEXT}"
)

START_TEXT = (
    "♫ اهلا بك عزيزي في بوت الاغاني\n"
    "♥︎ هذا البوت مخصص لتشغيل الاغاني داخل المكالمات\n"
    "♥︎ قم باضافة البوت داخل مجموعتك او قناتك\n"
    f"{HELPER_START_TEXT}\n"
    "للاشتراك برسائل الإدارة الاختيارية، ابدأ بوت الصانع وأرسل /broadcast_optin "
    "هناك. لإلغاء الاشتراك أرسل /broadcast_optout."
)

NO_QUEUE_TEXT = (
    "لاتوجد اغنيه مضافة لقائمة الانتظار. قم باضافة اغنيه بأمر "
    "(اضافة + اسم الاغنية)."
)

DATA_DIR = Path(config.DATABASE_PATH).parent
DATA_DIR.mkdir(parents=True, exist_ok=True)
Path(config.IMAGES_DIR).mkdir(parents=True, exist_ok=True)
Path(config.CACHE_DIR).mkdir(parents=True, exist_ok=True)

bot = Bot(token=config.BOT_TOKEN)
userbot = TelegramClient(
    StringSession(config.SESSION_STRING),
    api_id=config.API_ID,
    api_hash=config.API_HASH,
)
call_py: PyTgCalls | None = None


def _require_call_py() -> PyTgCalls:
    if call_py is None:
        raise RuntimeError(
            "لا تتوفر جلسة حساب مساعد لهذا البوت؛ أضف جلسة من إدارة الصانع لتفعيل المكالمات."
        )
    return call_py


class MusicDatabase:
    """تخزين إعدادات البوت والطوابير وسجلات إدارة الأعضاء في SQLite."""

    def __init__(self, path: str) -> None:
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                name TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                track_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                action TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS bot_users (
                user_id INTEGER PRIMARY KEY,
                first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS bot_admins (
                user_id INTEGER PRIMARY KEY,
                added_by INTEGER NOT NULL,
                display_name TEXT,
                username TEXT,
                added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS chat_bot_admins (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                added_by INTEGER NOT NULL,
                display_name TEXT,
                username TEXT,
                added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS bot_chats (
                chat_id INTEGER PRIMARY KEY,
                chat_type TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS flash_kicks (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                kick_count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (chat_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS group_muted (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL DEFAULT '',
                username TEXT,
                action TEXT NOT NULL,
                actor_id INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS group_restricted (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL DEFAULT '',
                username TEXT,
                action TEXT NOT NULL,
                actor_id INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS group_moderators (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL DEFAULT '',
                username TEXT,
                action TEXT NOT NULL,
                actor_id INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS group_warnings (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                warning_count INTEGER NOT NULL DEFAULT 0,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL DEFAULT '',
                username TEXT,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (chat_id, user_id)
            );
            """
        )
        admin_columns = {
            str(row["name"])
            for row in self.connection.execute("PRAGMA table_info(bot_admins)")
        }
        if "display_name" not in admin_columns:
            self.connection.execute("ALTER TABLE bot_admins ADD COLUMN display_name TEXT")
        if "username" not in admin_columns:
            self.connection.execute("ALTER TABLE bot_admins ADD COLUMN username TEXT")
        if config.OWNER_ID:
            self.connection.execute(
                "INSERT OR IGNORE INTO bot_admins(user_id, added_by) VALUES(?, ?)",
                (config.OWNER_ID, config.OWNER_ID),
            )
        self.connection.commit()

    def get_setting(self, name: str) -> str | None:
        row = self.connection.execute(
            "SELECT value FROM settings WHERE name = ?", (name,)
        ).fetchone()
        return str(row["value"]) if row else None

    def set_setting(self, name: str, value: str) -> None:
        self.connection.execute(
            "INSERT INTO settings(name, value) VALUES(?, ?) "
            "ON CONFLICT(name) DO UPDATE SET value = excluded.value",
            (name, value),
        )
        self.connection.commit()

    def delete_setting(self, name: str) -> None:
        self.connection.execute("DELETE FROM settings WHERE name = ?", (name,))
        self.connection.commit()

    def is_chat_lock_enabled(self, chat_id: int, category: str) -> bool:
        return self.get_setting(f"chat_lock:{chat_id}:{category}") == "1"

    def set_chat_lock(self, chat_id: int, category: str, enabled: bool) -> None:
        self.set_setting(f"chat_lock:{chat_id}:{category}", "1" if enabled else "0")

    def record_flash_kick(self, chat_id: int, user_id: int) -> int:
        self.connection.execute(
            "INSERT INTO flash_kicks(chat_id, user_id, kick_count) VALUES(?, ?, 1) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET "
            "kick_count = flash_kicks.kick_count + 1",
            (chat_id, user_id),
        )
        self.connection.commit()
        row = self.connection.execute(
            "SELECT kick_count FROM flash_kicks WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        ).fetchone()
        return int(row["kick_count"])

    def record_user(self, user_id: int) -> None:
        self.connection.execute(
            "INSERT OR IGNORE INTO bot_users(user_id) VALUES(?)",
            (user_id,),
        )
        self.connection.commit()

    def list_bot_admins(self) -> list[int]:
        rows = self.connection.execute(
            "SELECT user_id FROM bot_admins ORDER BY added_at, user_id"
        ).fetchall()
        return [int(row["user_id"]) for row in rows]

    def list_bot_admin_profiles(self) -> list[sqlite3.Row]:
        return self.connection.execute(
            "SELECT user_id, display_name, username, added_at FROM bot_admins "
            "ORDER BY added_at, user_id"
        ).fetchall()

    def list_chat_bot_admin_profiles(self, chat_id: int) -> list[sqlite3.Row]:
        return self.connection.execute(
            "SELECT user_id, display_name, username, added_at FROM chat_bot_admins "
            "WHERE chat_id = ? ORDER BY added_at, user_id",
            (chat_id,),
        ).fetchall()

    def add_chat_bot_admin(
        self,
        chat_id: int,
        user_id: int,
        added_by: int,
        *,
        display_name: str,
        username: str | None,
    ) -> None:
        self.connection.execute(
            "INSERT INTO chat_bot_admins"
            "(chat_id, user_id, added_by, display_name, username) "
            "VALUES(?, ?, ?, ?, ?) ON CONFLICT(chat_id, user_id) DO UPDATE SET "
            "display_name = excluded.display_name, username = excluded.username",
            (chat_id, user_id, added_by, display_name, username),
        )
        self.connection.commit()

    def remove_chat_bot_admin(self, chat_id: int, user_id: int) -> None:
        self.connection.execute(
            "DELETE FROM chat_bot_admins WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        )
        self.connection.commit()

    def list_active_group_chats(self) -> list[sqlite3.Row]:
        return self.connection.execute(
            "SELECT chat_id, chat_type FROM bot_chats "
            "WHERE is_active = 1 AND chat_type IN ('group', 'supergroup') "
            "ORDER BY updated_at DESC"
        ).fetchall()

    def add_bot_admin(
        self,
        user_id: int,
        added_by: int,
        *,
        display_name: str | None = None,
        username: str | None = None,
    ) -> None:
        self.connection.execute(
            "INSERT INTO bot_admins(user_id, added_by, display_name, username) "
            "VALUES(?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET "
            "display_name = COALESCE(excluded.display_name, bot_admins.display_name), "
            "username = COALESCE(excluded.username, bot_admins.username)",
            (user_id, added_by, display_name, username),
        )
        self.connection.commit()

    def remove_bot_admin(self, user_id: int) -> bool:
        cursor = self.connection.execute(
            "DELETE FROM bot_admins WHERE user_id = ?",
            (user_id,),
        )
        self.connection.commit()
        return cursor.rowcount > 0

    @staticmethod
    def _group_member_table(category: str) -> str:
        tables = {
            "muted": "group_muted",
            "restricted": "group_restricted",
            "moderators": "group_moderators",
        }
        try:
            return tables[category]
        except KeyError as exc:
            raise ValueError(f"Unknown group member category: {category}") from exc

    def record_group_member(
        self,
        category: str,
        chat_id: int,
        user_id: int,
        *,
        first_name: str,
        last_name: str = "",
        username: str | None = None,
        action: str,
        actor_id: int,
    ) -> None:
        table = self._group_member_table(category)
        self.connection.execute(
            f"INSERT INTO {table} "
            "(chat_id, user_id, first_name, last_name, username, action, actor_id) "
            "VALUES(?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET "
            "first_name = excluded.first_name, last_name = excluded.last_name, "
            "username = excluded.username, action = excluded.action, "
            "actor_id = excluded.actor_id",
            (
                chat_id,
                user_id,
                first_name,
                last_name,
                username,
                action,
                actor_id,
            ),
        )
        self.connection.commit()

    def list_group_members(
        self, category: str, chat_id: int | None = None
    ) -> list[sqlite3.Row]:
        table = self._group_member_table(category)
        if chat_id is None:
            query = (
                f"SELECT chat_id, user_id, first_name, last_name, username, "
                f"action, actor_id, created_at FROM {table} "
                "ORDER BY created_at, chat_id, user_id"
            )
            return self.connection.execute(query).fetchall()
        query = (
            f"SELECT chat_id, user_id, first_name, last_name, username, "
            f"action, actor_id, created_at FROM {table} WHERE chat_id = ? "
            "ORDER BY created_at, user_id"
        )
        return self.connection.execute(query, (chat_id,)).fetchall()

    def forget_group_member(
        self, category: str, chat_id: int, user_id: int
    ) -> None:
        table = self._group_member_table(category)
        self.connection.execute(
            f"DELETE FROM {table} WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        )
        self.connection.commit()

    def clear_group_members(self, category: str, chat_id: int) -> None:
        table = self._group_member_table(category)
        self.connection.execute(
            f"DELETE FROM {table} WHERE chat_id = ?", (chat_id,)
        )
        self.connection.commit()

    def record_warning(
        self,
        chat_id: int,
        user_id: int,
        *,
        first_name: str,
        last_name: str = "",
        username: str | None = None,
        maximum: int = 7,
    ) -> int:
        self.connection.execute(
            "INSERT INTO group_warnings "
            "(chat_id, user_id, warning_count, first_name, last_name, username) "
            "VALUES(?, ?, 1, ?, ?, ?) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET "
            "warning_count = MIN(group_warnings.warning_count + 1, ?), "
            "first_name = excluded.first_name, last_name = excluded.last_name, "
            "username = excluded.username, updated_at = CURRENT_TIMESTAMP",
            (chat_id, user_id, first_name, last_name, username, maximum),
        )
        self.connection.commit()
        row = self.connection.execute(
            "SELECT warning_count FROM group_warnings "
            "WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        ).fetchone()
        return int(row["warning_count"])

    def record_chat(self, chat_id: int, chat_type: str, *, active: bool = True) -> None:
        self.connection.execute(
            "INSERT INTO bot_chats(chat_id, chat_type, is_active) VALUES(?, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET "
            "chat_type = excluded.chat_type, is_active = excluded.is_active, "
            "updated_at = CURRENT_TIMESTAMP",
            (chat_id, chat_type, int(active)),
        )
        self.connection.commit()

    def get_statistics(self) -> tuple[int, int, int]:
        users = self.connection.execute(
            "SELECT COUNT(*) FROM bot_users"
        ).fetchone()[0]
        channels = self.connection.execute(
            "SELECT COUNT(*) FROM bot_chats "
            "WHERE chat_type = 'channel' AND is_active = 1"
        ).fetchone()[0]
        groups = self.connection.execute(
            "SELECT COUNT(*) FROM bot_chats "
            "WHERE chat_type IN ('group', 'supergroup') AND is_active = 1"
        ).fetchone()[0]
        return int(users), int(channels), int(groups)

    def queue_size(self, chat_id: int) -> int:
        row = self.connection.execute(
            "SELECT COUNT(*) AS count FROM queue WHERE chat_id = ?", (chat_id,)
        ).fetchone()
        return int(row["count"])

    def enqueue(self, chat_id: int, track: dict[str, Any]) -> None:
        self.connection.execute(
            "INSERT INTO queue(chat_id, track_json) VALUES(?, ?)",
            (chat_id, json.dumps(track, ensure_ascii=False)),
        )
        self.connection.commit()

    def dequeue(self, chat_id: int) -> dict[str, Any] | None:
        row = self.connection.execute(
            "SELECT id, track_json FROM queue WHERE chat_id = ? ORDER BY id LIMIT 1",
            (chat_id,),
        ).fetchone()
        if not row:
            return None
        self.connection.execute("DELETE FROM queue WHERE id = ?", (row["id"],))
        self.connection.commit()
        return json.loads(row["track_json"])

    def clear_queue(self, chat_id: int) -> None:
        self.connection.execute("DELETE FROM queue WHERE chat_id = ?", (chat_id,))
        self.connection.commit()

    def list_queue(self, chat_id: int, limit: int = 20) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            "SELECT track_json FROM queue WHERE chat_id = ? ORDER BY id LIMIT ?",
            (chat_id, limit),
        ).fetchall()
        return [json.loads(row["track_json"]) for row in rows]

    def remove_queue_item(self, chat_id: int, position: int) -> bool:
        row = self.connection.execute(
            "SELECT id FROM queue WHERE chat_id = ? ORDER BY id LIMIT 1 OFFSET ?",
            (chat_id, position - 1),
        ).fetchone()
        if not row:
            return False
        self.connection.execute("DELETE FROM queue WHERE id = ?", (row["id"],))
        self.connection.commit()
        return True

    def add_history(self, chat_id: int, title: str, action: str) -> None:
        self.connection.execute(
            "INSERT INTO history(chat_id, title, action) VALUES(?, ?, ?)",
            (chat_id, title, action),
        )
        self.connection.commit()

    def get_history(self, chat_id: int, limit: int = 20) -> list[sqlite3.Row]:
        return self.connection.execute(
            "SELECT title, action, created_at FROM history "
            "WHERE chat_id = ? ORDER BY id DESC LIMIT ?",
            (chat_id, limit),
        ).fetchall()

    def clear_history(self, chat_id: int) -> None:
        self.connection.execute("DELETE FROM history WHERE chat_id = ?", (chat_id,))
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()


db = MusicDatabase(config.DATABASE_PATH)

# حالة البث لا يمكن استعادتها بعد إعادة تشغيل السيرفر، لكن الطابور والسجل يبقيان محفوظين.
players: dict[int, dict[str, Any]] = {}
chat_locks: dict[int, asyncio.Lock] = {}
pending_admin_add: dict[int, tuple[int, int, bool]] = {}


def _button(
    text: str,
    *,
    style: str | None = None,
    callback_data: str | None = None,
    url: str | None = None,
) -> InlineKeyboardButton:
    return InlineKeyboardButton(
        text=text,
        style=style,
        callback_data=callback_data,
        url=url,
    )


def add_group_url(username: str) -> str:
    return f"https://t.me/{username}?startgroup=true"


def main_keyboard(username: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [_button("طريقة عمل البوت ✷", style="primary", callback_data="help")],
            [_button("قائمة الاوامر", style="success", callback_data="commands")],
            [
                _button("اضفني 𝐀𝐃𝐃", style="primary", url=add_group_url(username)),
                _button(
                    "الادارة كريفن",
                    style="primary",
                    url=f"https://t.me/{config.DEVELOPER_USERNAME}",
                ),
            ],
            [
                _button(
                    "سورس كريفن",
                    style="success",
                    url=f"https://t.me/{config.SOURCE_CHANNEL}",
                )
            ],
        ]
    )


def settings_keyboard(username: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                _button(
                    "سورس كريفن",
                    style="primary",
                    url=f"https://t.me/{config.SOURCE_CHANNEL}",
                )
            ],
            [_button("𝐀𝐃𝐃", style="success", url=add_group_url(username))],
            [_button("رجوع", style="primary", callback_data="home")],
        ]
    )


def commands_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                _button("المشرفين", style="primary", callback_data="commands_admins"),
                _button("المستخدمين", style="primary", callback_data="commands_users"),
            ],
            [
                _button("المطورين", style="primary", callback_data="commands_developers"),
                _button("المالك", style="primary", callback_data="commands_owner"),
            ],
            [_button("رجوع", style="danger", callback_data="home")],
        ]
    )


ADMIN_COMMANDS_TEXT = (
    "⌯ <b>أوامر المشرفين</b>\n\n"
    "<b>التحكم بالتشغيل:</b>\n"
    "<code>تخطي</code>\n- لتخطي المقطع الحالي\n"
    "<code>وقف</code>\nـ إيقاف التشغيل مؤقتاً\n"
    "<code>استئناف</code>\nـ استئناف التشغيل\n"
    "<code>انهاء</code>\nـ إيقاف التشغيل نهائياً\n\n"
    "<b>أدوات إضافية:</b>\n"
    "<code>تقديم [عدد الثواني]</code>\nـ لتقديم وقت المقطع\n"
    "<code>ارجع [عدد الثواني]</code>\nـ لإرجاع وقت المقطع\n"
    "<code>تكرار</code>\nـ تكرار المقطع الحالي\n"
    "<code>حذف [رقم]</code>\nـ حذف مقطع من القائمة\n"
    "<code>كتم</code>\nـ كتم صوت البوت بالمكالمة\n"
    "<code>الغاء_الكتم</code>\n- إلغاء كتم الصوت"
)

USER_COMMANDS_TEXT = (
    "⌯︙ <b>أوامر المستخدمين</b>\n\n"
    "<b>قائمة التشغيل:</b>\n"
    "<code>شغل</code> + اسم الأغنية (للمشرفين فقط)\nـ تشغيل مقطع صوتي\n"
    "<code>الانتظار</code>\nـ عرض قائمة التشغيل\n"
    "<code>يوت</code> + اسم الأغنية\nـ تشغيل أغنية صوتية دون لوحة التحكم\n\n"
    "<b>أوامر عامة:</b>\n"
    "<code>بنك</code>\n— فحص سرعة الاستجابة"
)

DEVELOPER_COMMANDS_TEXT = (
    "⌯︙ <b>أوامر المطور</b>\n\n› لوحة أو ادارة\n"
    "للحصول على لوحة خاصة بالمطورين فقط."
)

OWNER_COMMANDS_TEXT = (
    "⌯︙ <b>أوامر المالك</b>\n\n"
    "<b>التحكم والوصول:</b>\n"
    "<code>الضبط</code>\n— ضبط إعدادات المجموعة\n"
    "<code>تفعيل</code>\n— تحديث قائمة المشرفين\n\n"
    "<b>الادمنيه:</b>\n"
    "<code>الادمنيه</code>\n— قائمة الادمنيه المُصرح لهم\n"
    "<code>تنزيل ادمن + ايدي</code>\n— تنزيل الادمن من إدارة البوت وإزالته."
)


def command_page_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[_button("رجوع", style="danger", callback_data="commands")]]
    )


def owner_commands_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                _button("الضبط", style="primary", callback_data="owner_settings"),
                _button("تفعيل", style="primary", callback_data="owner_activate"),
            ],
            [_button("الادمنيه", style="primary", callback_data="owner_admins")],
            [_button("رجوع", style="danger", callback_data="commands")],
        ]
    )


ADMIN_PANEL_TEXT = "⌯︙ <b>قائمة التحكم الرئيسيه للادارة:</b>"


def admin_panel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                _button("الادمنيه", style="primary", callback_data="panel_admins"),
                _button("المقيدين", style="primary", callback_data="panel_restricted"),
            ],
            [
                _button("المشرفين", style="success", callback_data="panel_moderators"),
                _button("المكتوميين", style="success", callback_data="panel_muted"),
            ],
            [
                _button("اوامر الكتم", style="primary", callback_data="panel_mute_commands"),
                _button("اوامر الرفع", style="primary", callback_data="panel_promote_commands"),
            ],
            [_button("اوامر القفل", style="danger", callback_data="panel_lock")],
            [_button("اوامر الحمايه", style="danger", callback_data="panel_protection")],
            [_button("رجوع", style="danger", callback_data="home")],
        ]
    )


ADMIN_PANEL_SECTIONS = {
    "panel_admins": "⌯︙ <b>الادمنيه</b>\nقسم إدارة الادمنيه المصرح لهم.",
    "panel_restricted": "⌯︙ <b>المقيدين</b>\nقسم عرض وإلغاء تقييد الأعضاء.",
    "panel_moderators": "⌯︙ <b>المشرفين</b>\nقسم عرض وإدارة مشرفي المجموعة.",
    "panel_muted": "⌯︙ <b>المكتوميين</b>\nقسم عرض وإلغاء كتم الأعضاء.",
    "panel_mute_commands": (
        "⌯ كتم | لكتم مستخدم ومنعه من الكتابه بالمجموعه.\n"
        "⌯ طرد | لطرد عضو من المجموعه.\n"
        "⌯ دولي | لكتم مستخدم ومنعه من الكتابه بالمجموعه.\n"
        "⌯ سكته | لكتم مستخدم ومنعة من الكتابه بالمجموعه.\n"
        "⌯ انجب | لتقييد مستخدم ومنعه من الكتابه بالمجموعه.\n"
        "⌯ تقييد | لتقييد مستخدم ومنعه من الكتابه بالمجموعه.\n"
        "<code>الغاء الكتم</code> + يوزر العضو أو بالرد على رسالته | لفك الكتم\n"
        "<code>تحذير</code> بالرد على رسالة العضو | لإعطائه تحذيراً، وعند 7 يُكتم\n"
        "<code>الغاء التقييد</code> + يوزر العضو أو بالرد على رسالته | لفك التقييد\n"
        "<code>الغاء المكتومين</code> | لفك الكتم والتقييد عن الجميع\n"
        "<code>تنظيف</code> | لحذف آخر 50 رسالة في المجموعة\n"
        "⌯ يمكنك تنفيذ احد هذه الاوامر الخاصه بالكتم."
    ),
    "panel_promote_commands": (
        "⌯ رفع مشرف | لرفع مستخدم الى مشرف بالمجموعه\n"
        "⌯ رفع مميز | لرفع مستخدم برتبة مميز بالمجموعه\n"
        "⌯ رفع مدير | لرفع مستخدم برتبة مدير بالمجموعه\n"
        "⌯ رفع اداري | لرفع مستخدم برتبة اداري بالمجموعه\n"
        "⌯ رفع متفاعل | لرفع مستخدم برتبة متفاعل بالمجموعه."
    ),
    "panel_lock": (
        "⌯︙ <b>اوامر القفل</b>\n"
        "<code>ايدي</code> | لعرض ايدي ومعلومات العضو\n"
        "<code>قفل الملصقات</code> | لقفل إرسال الملصقات بالمجموعة\n"
        "<code>فتح الملصقات</code> | لفتح إرسال الملصقات بالمجموعة\n"
        "<code>قفل المتحركة</code> | لقفل إرسال GIF بالمجموعة\n"
        "<code>فتح المتحركة</code> | لفتح إرسال GIF بالمجموعة\n"
        "<code>قفل الصور</code> | لقفل إرسال الصور بالمجموعة\n"
        "<code>فتح الصور</code> | لفتح إرسال الصور بالمجموعة\n"
        "<code>قفل الفيديو</code> | لقفل إرسال الفيديو بالمجموعة\n"
        "<code>فتح الفيديو</code> | لفتح إرسال الفيديو بالمجموعة\n"
        "<code>قفل الصوتيه</code> | لقفل إرسال الصوتيات بالمجموعة\n"
        "<code>فتح الصوتيه</code> | لفتح إرسال الصوتيات بالمجموعة\n"
        "<code>قفل الروابط</code> | لمنع إرسال الروابط بكل صيغها\n"
        "<code>فتح الروابط</code> | للسماح بإرسال الروابط\n"
        "<code>قفل التفليش</code> | لمراقبة حالات الطرد\n"
        "<code>فتح التفليش</code> | لإيقاف مراقبة حالات الطرد\n"
        "⌯︙ تنفذ هذه الأوامر من قبل المشرفين فقط."
    ),
    "panel_protection": (
        "⌯︙ <b>اوامر حماية المجموعة</b>\n"
        "<code>قفل الدردشة</code> | لمنع الأعضاء من إرسال الرسائل\n"
        "<code>فتح الدردشة</code> | لاستعادة صلاحيات الدردشة السابقة\n"
        "<code>قفل التاك</code> | لمنع التاك والمنشن للأعضاء\n"
        "<code>فتح التاك</code> | للسماح بالتاك والمنشن للأعضاء\n"
        "<code>تنزيل مشرف</code> | بالرد على المشرف لتنزيله من الإشراف\n"
        "⌯︙ تنفذ هذه الأوامر من قبل المشرفين فقط."
    ),
}


def admin_panel_section_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [_button("رجوع", style="danger", callback_data="admin_panel")]
        ]
    )


ADMIN_PANEL_LIST_CATEGORIES = {
    "panel_admins": "admins",
    "panel_restricted": "restricted",
    "panel_moderators": "moderators",
    "panel_muted": "muted",
}
ADMIN_LIST_PAGE_SIZE = 10
ADMIN_LIST_PHOTO_PAGE_SIZE = 3


def admin_panel_list_keyboard(
    category: str,
    offset: int,
    total: int,
    page_size: int,
    *,
    allow_clear: bool = False,
) -> InlineKeyboardMarkup:
    rows = []
    navigation = []
    if offset > 0:
        navigation.append(
            _button(
                "السابق",
                style="primary",
                callback_data=f"panel_list:{category}:{max(0, offset - page_size)}",
            )
        )
    if offset + page_size < total:
        navigation.append(
            _button(
                "التالي",
                style="primary",
                callback_data=f"panel_list:{category}:{offset + page_size}",
            )
        )
    if navigation:
        rows.append(navigation)
    if allow_clear and category in {"muted", "restricted"}:
        rows.append(
            [
                _button(
                    "الغاء الكل",
                    style="primary",
                    callback_data=f"panel_clear:{category}",
                )
            ]
        )
    rows.append([_button("رجوع", style="danger", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_panel_clear_confirmation_keyboard(category: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                _button(
                    "تاكيد",
                    style="success",
                    callback_data=f"panel_clear_confirm:{category}",
                )
            ],
            [
                _button(
                    "الغاء",
                    style="danger",
                    callback_data=f"panel_clear_cancel:{category}",
                )
            ],
        ]
    )


def _member_display_name(row: sqlite3.Row) -> str:
    name = " ".join(
        " ".join(str(part).split())
        for part in (row["first_name"], row["last_name"])
        if part and str(part).strip()
    )
    return name or str(row["user_id"])


def _member_list_line(
    row: sqlite3.Row, index: int, *, category: str, chat_title: str | None = None
) -> str:
    user_id = int(row["user_id"])
    name = escape(_member_display_name(row)[:80])
    username = row["username"]
    username_text = f"@{escape(str(username))}" if username else "غير متوفر"
    details = (
        f"⌯︙ {index}. <a href=\"tg://user?id={user_id}\">{name}</a>"
        f" | اليوزر: {username_text} | الايدي: <code>{user_id}</code>"
    )
    if chat_title is not None:
        details += f" | المجموعة: {escape(chat_title[:40])}"
    if category in {"muted", "restricted", "moderators"}:
        action_label = "الرتبة" if category == "moderators" else "الأمر"
        details += (
            f" | {action_label}: <code>{escape(str(row['action']))}</code>"
            f" | بواسطة: <code>{int(row['actor_id'])}</code>"
            f" | التاريخ: {escape(str(row['created_at']))}"
        )
    return details


async def admin_panel_list_page(
    section: str,
    chat_id: int,
    offset: int = 0,
    *,
    chat_title: str | None = None,
    page_size: int = ADMIN_LIST_PAGE_SIZE,
    allow_clear: bool = False,
    api=None,
) -> tuple[str, InlineKeyboardMarkup]:
    api = api or bot
    category = ADMIN_PANEL_LIST_CATEGORIES[section]
    if category == "admins":
        if chat_id:
            rows = db.list_chat_bot_admin_profiles(chat_id)
            heading = "⌯︙ <b>ادمن البوت في هذه المجموعة/القناة فقط</b>"
        else:
            rows = db.list_bot_admin_profiles()
            heading = "⌯︙ <b>الادمنيه المصرح لهم بالتحكم بالبوت</b>"
    else:
        rows = db.list_group_members(
            category, None if chat_id == 0 else chat_id
        )
        heading = {
            "restricted": "⌯︙ <b>قائمة المقيدين</b>",
            "moderators": "⌯︙ <b>قائمة المشرفين والرتب المرفوعة</b>",
            "muted": "⌯︙ <b>قائمة المكتومين</b>",
        }[category]

    total = len(rows)
    offset = max(0, offset // page_size * page_size)
    last_page_offset = max(0, (total - 1) // page_size * page_size)
    offset = min(offset, last_page_offset)
    page = rows[offset : offset + page_size]
    lines = [heading]
    if total == 0:
        lines.append("لا توجد بيانات مسجلة في هذا القسم حالياً.")
    else:
        lines.append(
            f"<i>عرض {offset + 1}–{offset + len(page)} من {total}</i>"
        )
        group_titles: dict[int, str] = {}
        for index, row in enumerate(page, start=offset + 1):
            member_chat_title = None
            if category != "admins" and chat_id == 0:
                member_chat_id = int(row["chat_id"])
                if member_chat_id not in group_titles:
                    try:
                        group = await api.get_chat(member_chat_id)
                        group_titles[member_chat_id] = group.title or str(member_chat_id)
                    except Exception:
                        logger.exception(
                            "تعذر جلب اسم المجموعة %s أثناء عرض سجلات الأعضاء",
                            member_chat_id,
                        )
                        group_titles[member_chat_id] = str(member_chat_id)
                member_chat_title = group_titles[member_chat_id]
            if category == "admins":
                user_id = int(row["user_id"])
                display_name = escape(str(row["display_name"] or user_id))
                username = row["username"]
                username_text = (
                    f"@{escape(str(username))}" if username else "غير متوفر"
                )
                lines.append(
                    f"⌯︙ {index}. <a href=\"tg://user?id={user_id}\">"
                    f"{display_name[:80]}</a> | اليوزر: {username_text} "
                    f"| الايدي: <code>{user_id}</code> "
                    f"| أضيف: {escape(str(row['added_at']))}"
                )
            else:
                lines.append(
                    _member_list_line(
                        row,
                        index,
                        category=category,
                        chat_title=member_chat_title,
                    )
                )
    return (
        "\n".join(lines),
        admin_panel_list_keyboard(
            category, offset, total, page_size, allow_clear=allow_clear
        ),
    )


def owner_admins_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [_button("اضف ادمن", style="success", callback_data="owner_add_admin")],
            [_button("رجوع", style="danger", callback_data="commands_owner")],
        ]
    )


def owner_group_keyboard(groups: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    rows = [
        [_button(title[:60], style="primary", callback_data=f"owner_group:{chat_id}")]
        for chat_id, title in groups
    ]
    rows.append([_button("رجوع", style="danger", callback_data="commands_owner")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def control_keyboard(username: str, paused: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [
            _button("تشغيل", style="primary", callback_data="ctrl_play"),
            _button("انهاء", style="primary", callback_data="ctrl_stop"),
            _button("تخطي", style="primary", callback_data="ctrl_skip"),
        ]
    ]
    if not paused:
        rows.append(
            [
                _button("+10s ↻", style="primary", callback_data="ctrl_forward"),
                _button("▹", style="danger", callback_data="ctrl_pause"),
                _button("-10s ↺", style="primary", callback_data="ctrl_rewind"),
            ]
        )
    rows.extend(
        [
            [
                _button(
                    "سورس كريفن",
                    style="primary",
                    url=f"https://t.me/{config.SOURCE_CHANNEL}",
                )
            ],
            [_button("𝐀𝐃𝐃", style="success", url=add_group_url(username))],
            [_button("✘", style="danger", callback_data="noop")],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def control_caption(track: dict[str, Any]) -> str:
    return (
        f"• تم تشغيل: {track['title']} ♫\n"
        f"• مدة التشغيل: {track.get('duration_text') or 'غير معروف'} ◴"
    )


def _parse_duration(info: dict[str, Any]) -> int | None:
    duration = info.get("duration")
    return int(duration) if isinstance(duration, (int, float)) and duration > 0 else None


def _resolve_track(query: str) -> dict[str, Any] | None:
    """البحث أو تحليل رابط، مع حفظ رابط المصدر بدلاً من رابط البث المؤقت."""
    query = query.strip()
    if not query:
        return None
    options = {
        "format": "bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "default_search": "ytsearch1",
        "socket_timeout": 20,
        "retries": 2,
    }
    if config.YT_DLP_COOKIEFILE:
        options["cookiefile"] = config.YT_DLP_COOKIEFILE
    lookup = query if re.match(r"^https?://", query, flags=re.IGNORECASE) else f"ytsearch1:{query}"
    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(lookup, download=False)
    if not info:
        return None
    if info.get("entries"):
        info = next((entry for entry in info["entries"] if entry), None)
    if not info or not info.get("url"):
        return None
    webpage_url = info.get("webpage_url") or info.get("original_url") or query
    if not urlparse(str(webpage_url)).scheme and not query.startswith("http"):
        webpage_url = f"https://www.youtube.com/watch?v={info.get('id', '')}"
    return {
        "title": str(info.get("title") or "مقطع صوتي"),
        "source": str(webpage_url),
        "duration": _parse_duration(info),
        "duration_text": str(info.get("duration_string") or "غير معروف"),
    }


def _get_stream_url(source: str) -> str:
    options = {
        "format": "bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 20,
        "retries": 2,
    }
    if config.YT_DLP_COOKIEFILE:
        options["cookiefile"] = config.YT_DLP_COOKIEFILE
    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(source, download=False)
    if info and info.get("entries"):
        info = next((entry for entry in info["entries"] if entry), None)
    if not info or not info.get("url"):
        raise ValueError("تعذر استخراج رابط البث. تحقق من الرابط أو جرّب البحث باسم الأغنية.")
    return str(info["url"])


def _download_track(source: str) -> str:
    """تنزيل الصوت إلى مجلد التخزين المؤقت حتى لا يعتمد الطابور على رابط مؤقت."""
    options = {
        "format": "bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "outtmpl": str(Path(config.CACHE_DIR) / "%(id)s.%(ext)s"),
        "socket_timeout": 30,
        "retries": 2,
    }
    if config.YT_DLP_COOKIEFILE:
        options["cookiefile"] = config.YT_DLP_COOKIEFILE
    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(source, download=True)
        if info and info.get("entries"):
            info = next((entry for entry in info["entries"] if entry), None)
        if not info:
            raise ValueError("تعذر تنزيل الملف الصوتي.")
        candidates = [
            info.get("requested_downloads", [{}])[0].get("filepath"),
            downloader.prepare_filename(info),
        ]
        for candidate in candidates:
            if candidate and Path(candidate).is_file():
                return str(Path(candidate).resolve())
        media_id = str(info.get("id", ""))
        matches = list(Path(config.CACHE_DIR).glob(f"{media_id}.*")) if media_id else []
        if matches:
            return str(matches[0].resolve())
    raise ValueError("اكتمل البحث لكن لم يُعثر على الملف الصوتي بعد تنزيله.")


async def resolve_track(query: str) -> dict[str, Any] | None:
    return await asyncio.to_thread(_resolve_track, query)


async def get_stream_url(track: dict[str, Any]) -> str:
    media_path = track.get("media_path")
    if media_path and Path(media_path).is_file():
        return str(media_path)
    return await asyncio.to_thread(_get_stream_url, str(track["source"]))


async def cache_track(track: dict[str, Any]) -> dict[str, Any]:
    track["media_path"] = await asyncio.to_thread(_download_track, str(track["source"]))
    return track


def _has_full_bot_admin_rights(chat_type: str, member: Any) -> bool:
    required_rights = [
        "can_manage_chat",
        "can_delete_messages",
        "can_manage_video_chats",
        "can_promote_members",
        "can_change_info",
        "can_invite_users",
    ]
    if chat_type == "channel":
        required_rights.extend(["can_post_messages", "can_edit_messages"])
    else:
        required_rights.extend(
            [
                "can_restrict_members",
                "can_pin_messages",
                "can_manage_topics",
            ]
        )
    return all(getattr(member, right, False) is True for right in required_rights)


async def is_group_admin(chat_id: int, user_id: int | None, api=None) -> bool:
    if user_id is None:
        return False
    if _is_bot_admin(user_id):
        return True
    member = await (api or bot).get_chat_member(chat_id, user_id)
    status = getattr(member.status, "value", member.status)
    return status in {"administrator", "creator"}


async def require_group_admin(message: Message) -> bool:
    try:
        allowed = await is_group_admin(
            message.chat.id, message.from_user.id if message.from_user else None
        )
    except Exception:
        logger.exception("تعذر التحقق من صلاحيات المستخدم في %s", message.chat.id)
        await message.answer("تعذر التحقق من صلاحياتك حالياً. حاول مرة أخرى.")
        return False
    if not allowed:
        await message.answer("ـ عذراً هذا الامر يخص المشرفين فقط ⚠️")
    return allowed


PROTECTION_CATEGORIES = {
    "الملصقات": ("stickers", "الملصقات"),
    "ملصقات": ("stickers", "الملصقات"),
    "المتحركة": ("animations", "المتحركة"),
    "المتحركه": ("animations", "المتحركة"),
    "الصور": ("photos", "الصور"),
    "صور": ("photos", "الصور"),
    "الفيديو": ("videos", "الفيديو"),
    "الفديو": ("videos", "الفيديو"),
    "فيديو": ("videos", "الفيديو"),
    "الصوتيه": ("audio", "الصوتيه"),
    "الصوتية": ("audio", "الصوتيه"),
    "الصوتيات": ("audio", "الصوتيه"),
    "الصوت": ("audio", "الصوتيه"),
    "الروابط": ("links", "الروابط"),
    "روابط": ("links", "الروابط"),
}

MUTE_COMMANDS = {"كتم", "دولي", "سكته", "انجب", "تقييد"}


_CHAT_PERMISSION_FIELDS = set(inspect.signature(ChatPermissions).parameters) - {
    "api_kwargs"
}


def _chat_permissions(values: dict[str, Any]) -> ChatPermissions:
    return ChatPermissions(
        **{
            name: value
            for name, value in values.items()
            if name in _CHAT_PERMISSION_FIELDS
        }
    )


MUTE_PERMISSIONS = _chat_permissions(
    {
        "can_send_messages": False,
        "can_send_audios": False,
        "can_send_documents": False,
        "can_send_photos": False,
        "can_send_videos": False,
        "can_send_video_notes": False,
        "can_send_voice_notes": False,
        "can_send_polls": False,
        "can_send_other_messages": False,
        "can_add_web_page_previews": False,
        "can_react_to_messages": False,
    }
)

MEMBER_TAG_RANKS = {
    "مميز": "مميز",
    "مدير": "مدير",
    "اداري": "اداري",
    "إداري": "اداري",
    "متفاعل": "متفاعل",
}


async def _resolve_telethon_user(chat_id: int, target: Any) -> Any:
    lookup = target.username or target.id
    try:
        entity = await userbot.get_entity(lookup)
        if getattr(entity, "id", None) == target.id:
            return entity
    except Exception:
        logger.debug("تعذر حل المستخدم مباشرة عبر Telethon: %s", target.id)

    try:
        participants = await userbot.get_participants(chat_id)
    except Exception as exc:
        raise RuntimeError(
            "تعذر الوصول إلى أعضاء المجموعة عبر حساب المساعد."
        ) from exc
    entity = next(
        (participant for participant in participants if participant.id == target.id),
        None,
    )
    if entity is None:
        raise RuntimeError(
            "لم يتم العثور على العضو في المجموعة عبر حساب المساعد."
        )
    return entity


async def handle_promotion_command(message: Message, text: str) -> bool:
    if message.chat.type not in {"group", "supergroup"}:
        return False
    command = text.strip().lstrip("/").split("@", maxsplit=1)[0]
    match = re.fullmatch(r"رفع\s+(مشرف|مميز|مدير|اداري|إداري|متفاعل)", command)
    if not match:
        return False
    if not await require_group_admin(message):
        return True

    reply = message.reply_to_message
    target = reply.from_user if reply else None
    if target is None:
        await message.answer("ـ نفذ الأمر بالرد على رسالة العضو المطلوب.")
        return True

    try:
        bot_id = (await bot.get_me()).id
        if target.id == bot_id:
            await message.answer("لا يمكن تنفيذ أمر الرفع على البوت.")
            return True
        bot_member = await bot.get_chat_member(message.chat.id, bot_id)
        target_member = await bot.get_chat_member(message.chat.id, target.id)
    except Exception:
        logger.exception("تعذر التحقق من صلاحيات الرفع في %s", message.chat.id)
        await message.answer("تعذر التحقق من العضو أو صلاحيات البوت.")
        return True

    bot_status = getattr(bot_member.status, "value", bot_member.status)
    if bot_status != "administrator":
        await message.answer("يجب أن يكون البوت مشرفاً في المجموعة لتنفيذ الرفع.")
        return True
    target_status = getattr(target_member.status, "value", target_member.status)
    if target_status in {"creator", "administrator"}:
        await message.answer("المستخدم مالك أو مشرف بالفعل ولا يمكن رفعه بهذا الأمر.")
        return True
    if target_status in {"left", "kicked"}:
        await message.answer("المستخدم ليس عضواً حالياً في المجموعة.")
        return True

    rank = match.group(1)
    if not getattr(bot_member, "can_manage_tags", False):
        await message.answer(
            "يجب منح البوت صلاحية تعديل وسوم الأعضاء لتنفيذ أوامر الرتب."
        )
        return True
    try:
        if rank == "مشرف":
            if not getattr(bot_member, "can_promote_members", False):
                await message.answer(
                    "يجب منح البوت صلاحية إضافة مشرفين لرفع مشرف جديد."
                )
                return True
            promoted = await bot.promote_chat_member(
                chat_id=message.chat.id,
                user_id=target.id,
                is_anonymous=False,
                can_manage_chat=False,
                can_delete_messages=True,
                can_manage_video_chats=True,
                can_restrict_members=True,
                can_promote_members=False,
                can_change_info=False,
                can_invite_users=True,
                can_post_stories=True,
                can_edit_stories=True,
                can_delete_stories=True,
                can_post_messages=False,
                can_edit_messages=False,
                can_pin_messages=True,
                can_manage_topics=False,
                can_manage_direct_messages=False,
                can_manage_tags=True,
                can_send_welcome_messages=True,
            )
            if not promoted:
                raise RuntimeError("لم تؤكد Telegram نجاح رفع المشرف.")
            db.record_group_member(
                "moderators",
                message.chat.id,
                target.id,
                first_name=target.first_name,
                last_name=target.last_name or "",
                username=target.username,
                action=rank,
                actor_id=message.from_user.id if message.from_user else 0,
            )
            await bot.set_chat_administrator_custom_title(
                chat_id=message.chat.id,
                user_id=target.id,
                custom_title="مشرف",
            )
        else:
            tag = MEMBER_TAG_RANKS[rank]
            updated = await bot.set_chat_member_tag(
                chat_id=message.chat.id,
                user_id=target.id,
                tag=tag,
            )
            if not updated:
                raise RuntimeError("لم تؤكد Telegram نجاح تعديل وسم العضو.")
            db.record_group_member(
                "moderators",
                message.chat.id,
                target.id,
                first_name=target.first_name,
                last_name=target.last_name or "",
                username=target.username,
                action=rank,
                actor_id=message.from_user.id if message.from_user else 0,
            )
        await message.answer(f"تم رفع {target.full_name} برتبة {rank}.")
    except Exception as exc:
        logger.exception(
            "تعذر رفع العضو %s برتبة %s في المجموعة %s",
            target.id,
            rank,
            message.chat.id,
        )
        await message.answer(f"تعذر تنفيذ الرفع: {str(exc)[:300]}")
    return True


async def resolve_moderation_target(
    message: Message, command_text: str
) -> Any | None:
    if message.reply_to_message and message.reply_to_message.from_user:
        return message.reply_to_message.from_user
    username_match = re.fullmatch(
        r"@[A-Za-z0-9_]{5,32}", command_text.strip()
    )
    if not username_match:
        await message.answer("نفذ الأمر بالرد على رسالة العضو أو أرسل يوزره مثل @username.")
        return None
    try:
        if not userbot.is_connected() or not await userbot.is_user_authorized():
            raise RuntimeError("الحساب المساعد غير متصل أو غير مصادق عليه.")
        user = await userbot.get_entity(username_match.group(0).lstrip("@"))
    except Exception:
        logger.exception(
            "تعذر العثور على المستخدم %s لتنفيذ أمر إداري",
            username_match.group(0),
        )
        await message.answer("تعذر العثور على المستخدم بهذا اليوزر.")
        return None
    if not getattr(user, "first_name", None):
        await message.answer("اليوزر المحدد لا يعود إلى حساب مستخدم.")
        return None
    return user


def moderation_target_name(target: Any) -> str:
    return getattr(
        target,
        "full_name",
        " ".join(
            part
            for part in (
                getattr(target, "first_name", ""),
                getattr(target, "last_name", ""),
            )
            if part
        )
        or str(target.id),
    )


async def restore_member_chat_permissions(
    chat_id: int, user_id: int, api=None
) -> None:
    api = api or bot
    chat = await api.get_chat(chat_id)
    permissions = getattr(chat, "permissions", None)
    if permissions is None:
        raise RuntimeError("تعذر قراءة صلاحيات المجموعة الافتراضية.")
    updated = await api.restrict_chat_member(
        chat_id=chat_id,
        user_id=user_id,
        permissions=permissions,
        use_independent_chat_permissions=True,
    )
    if not updated:
        raise RuntimeError("لم تؤكد Telegram نجاح رفع التقييد.")


async def release_tracked_members(
    category: str, chat_id: int, api=None
) -> tuple[int, int]:
    api = api or bot
    rows = db.list_group_members(category, chat_id)
    if not rows:
        return 0, 0
    bot_member = await api.get_chat_member(chat_id, (await api.get_me()).id)
    if not getattr(bot_member, "can_restrict_members", False):
        raise RuntimeError("يجب منح البوت صلاحية تقييد الأعضاء.")
    released = 0
    failed = 0
    for row in rows:
        user_id = int(row["user_id"])
        try:
            member = await api.get_chat_member(chat_id, user_id)
            status = getattr(member.status, "value", member.status)
            if status not in {"left", "kicked"}:
                await restore_member_chat_permissions(chat_id, user_id, api=api)
            db.forget_group_member(category, chat_id, user_id)
            released += 1
        except Exception:
            logger.exception(
                "تعذر رفع %s عن المستخدم %s في المجموعة %s",
                category,
                user_id,
                chat_id,
            )
            failed += 1
    return released, failed


async def handle_moderation_command(message: Message, text: str) -> bool:
    if message.chat.type not in {"group", "supergroup"}:
        return False
    command = re.sub(r"\s+", " ", text.strip()).casefold()
    if command.startswith("/"):
        first, separator, remainder = command[1:].partition(" ")
        command = f"{first.split('@', maxsplit=1)[0]}{separator}{remainder}"
    supported_commands = (
        MUTE_COMMANDS
        | {
            "طرد",
            "الغاء الكتم",
            "إلغاء الكتم",
            "الغاء التقييد",
            "إلغاء التقييد",
            "تحذير",
            "الغاء المكتومين",
            "إلغاء المكتومين",
            "تنظيف",
        }
    )
    normalized_aliases = {
        "إلغاء الكتم": "الغاء الكتم",
        "إلغاء التقييد": "الغاء التقييد",
        "إلغاء المكتومين": "الغاء المكتومين",
    }
    command_name = None
    target_argument = ""
    for candidate in sorted(supported_commands, key=len, reverse=True):
        candidate = normalized_aliases.get(candidate, candidate)
        match = re.fullmatch(
            rf"{re.escape(candidate)}(?:\s+(.+))?",
            command,
        )
        if match:
            command_name = candidate
            target_argument = (match.group(1) or "").strip()
            break
    if command_name is None:
        return False
    if not await require_group_admin(message):
        return True

    chat_id = message.chat.id
    if command_name == "تنظيف":
        try:
            bot_member = await bot.get_chat_member(chat_id, (await bot.get_me()).id)
            if not getattr(bot_member, "can_delete_messages", False):
                await message.answer("يجب منح البوت صلاحية حذف الرسائل لتنفيذ التنظيف.")
                return True
            if not userbot.is_connected() or not await userbot.is_user_authorized():
                raise RuntimeError("الحساب المساعد غير متصل أو غير مصادق عليه.")
            message_ids = [
                int(item.id)
                async for item in userbot.iter_messages(chat_id, limit=50)
            ]
            if message.message_id not in message_ids:
                message_ids.append(message.message_id)
            message_ids = sorted(set(message_ids), reverse=True)[:50]
            deleted = await bot.delete_messages(chat_id, message_ids)
            if not deleted:
                raise RuntimeError("لم تؤكد Telegram حذف الرسائل.")
            await message.answer(f"تم تنظيف {len(message_ids)} رسالة من المجموعة.")
        except Exception as exc:
            logger.exception("تعذر حذف آخر 50 رسالة في المجموعة %s", chat_id)
            await message.answer(f"تعذر تنفيذ التنظيف: {str(exc)[:250]}")
        return True

    if command_name == "الغاء المكتومين":
        try:
            released_muted, failed_muted = await release_tracked_members(
                "muted", chat_id
            )
            released_restricted, failed_restricted = await release_tracked_members(
                "restricted", chat_id
            )
            await message.answer(
                "تم رفع الكتم والتقييد عن "
                f"{released_muted + released_restricted} مستخدم. "
                f"تعذر رفعه عن {failed_muted + failed_restricted} مستخدم."
            )
        except Exception as exc:
            logger.exception("تعذر إلغاء كتم وتقييد المجموعة %s", chat_id)
            await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:250]}")
        return True

    if command_name in {"الغاء الكتم", "الغاء التقييد"}:
        target = await resolve_moderation_target(message, target_argument)
        if target is None:
            return True
        category = "muted" if command_name == "الغاء الكتم" else "restricted"
        try:
            bot_member = await bot.get_chat_member(chat_id, (await bot.get_me()).id)
            if not getattr(bot_member, "can_restrict_members", False):
                await message.answer("يجب منح البوت صلاحية تقييد الأعضاء.")
                return True
            member = await bot.get_chat_member(chat_id, target.id)
            status = getattr(member.status, "value", member.status)
            if status in {"creator", "administrator"}:
                await message.answer("لا يمكن تنفيذ الأمر على مالك المجموعة أو مشرفها.")
                return True
            if status in {"left", "kicked"}:
                db.forget_group_member(category, chat_id, target.id)
                await message.answer("المستخدم ليس عضواً حالياً في المجموعة.")
                return True
            await restore_member_chat_permissions(chat_id, target.id)
            db.forget_group_member(category, chat_id, target.id)
            await message.answer(
                f"تم رفع القيد عن {moderation_target_name(target)}."
            )
        except Exception as exc:
            logger.exception(
                "تعذر تنفيذ %s عن المستخدم %s في المجموعة %s",
                command_name,
                target.id,
                chat_id,
            )
            await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:250]}")
        return True

    if command_name == "تحذير":
        target = await resolve_moderation_target(message, target_argument)
        if target is None:
            return True
        try:
            bot_member = await bot.get_chat_member(chat_id, (await bot.get_me()).id)
            if not getattr(bot_member, "can_restrict_members", False):
                await message.answer(
                    "يجب منح البوت صلاحية تقييد الأعضاء حتى يكتم العضو عند 7 تحذيرات."
                )
                return True
            member = await bot.get_chat_member(chat_id, target.id)
            status = getattr(member.status, "value", member.status)
            if status in {"creator", "administrator"}:
                await message.answer("لا يمكن تحذير مالك المجموعة أو مشرفها.")
                return True
            if status in {"left", "kicked"}:
                await message.answer("هذا المستخدم ليس عضواً حالياً في المجموعة.")
                return True
            warnings = db.record_warning(
                chat_id,
                target.id,
                first_name=target.first_name,
                last_name=getattr(target, "last_name", "") or "",
                username=getattr(target, "username", None),
            )
            mention = (
                f"@{target.username}"
                if getattr(target, "username", None)
                else moderation_target_name(target)
            )
            if warnings == 7:
                await bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=target.id,
                    permissions=MUTE_PERMISSIONS,
                    use_independent_chat_permissions=True,
                )
                db.forget_group_member("restricted", chat_id, target.id)
                db.record_group_member(
                    "muted",
                    chat_id,
                    target.id,
                    first_name=target.first_name,
                    last_name=getattr(target, "last_name", "") or "",
                    username=getattr(target, "username", None),
                    action="تحذيرات 7/7",
                    actor_id=message.from_user.id if message.from_user else 0,
                )
                await message.answer(
                    f"ـ العضو {mention} تم اعطائه تحذير 7/7 وتم كتمه."
                )
            else:
                await message.answer(
                    f"ـ العضو {mention} تم اعطائه تحذير {warnings}/7"
                )
        except Exception as exc:
            logger.exception(
                "تعذر تحذير المستخدم %s في المجموعة %s",
                target.id,
                chat_id,
            )
            await message.answer(f"تعذر تنفيذ التحذير: {str(exc)[:250]}")
        return True

    target = await resolve_moderation_target(message, target_argument)
    if target is None:
        return True
    try:
        bot_id = (await bot.get_me()).id
        if target.id == bot_id:
            await message.answer("لا يمكن تنفيذ هذا الأمر على البوت.")
            return True
        bot_member = await bot.get_chat_member(chat_id, bot_id)
    except Exception:
        logger.exception("تعذر التحقق من البوت في المجموعة %s", chat_id)
        await message.answer("تعذر التحقق من صلاحيات البوت في المجموعة.")
        return True
    if not getattr(bot_member, "can_restrict_members", False):
        await message.answer(
            "يجب منح البوت صلاحية حظر وتقييد الأعضاء لتنفيذ هذا الأمر."
        )
        return True

    try:
        target_member = await bot.get_chat_member(chat_id, target.id)
    except Exception:
        logger.exception(
            "تعذر التحقق من العضو %s في المجموعة %s", target.id, chat_id
        )
        await message.answer("تعذر العثور على العضو أو التحقق من رتبته.")
        return True
    target_status = getattr(target_member.status, "value", target_member.status)
    if target_status in {"creator", "administrator"}:
        await message.answer("لا يمكن تنفيذ هذا الأمر على مالك المجموعة أو مشرفها.")
        return True
    if target_status in {"left", "kicked"}:
        await message.answer("هذا المستخدم ليس عضواً حالياً في المجموعة.")
        return True

    try:
        if command_name == "طرد":
            await bot.ban_chat_member(
                chat_id=chat_id,
                user_id=target.id,
                revoke_messages=False,
            )
            await bot.unban_chat_member(
                chat_id=chat_id,
                user_id=target.id,
                only_if_banned=True,
            )
            result = f"تم طرد {target.full_name} من المجموعة."
        else:
            await bot.restrict_chat_member(
                chat_id=chat_id,
                user_id=target.id,
                permissions=MUTE_PERMISSIONS,
                use_independent_chat_permissions=True,
            )
            category = (
                "restricted"
                if command_name in {"تقييد", "انجب"}
                else "muted"
            )
            other_category = "muted" if category == "restricted" else "restricted"
            db.forget_group_member(other_category, chat_id, target.id)
            db.record_group_member(
                category,
                chat_id,
                target.id,
                first_name=target.first_name,
                last_name=getattr(target, "last_name", "") or "",
                username=getattr(target, "username", None),
                action=command_name,
                actor_id=message.from_user.id if message.from_user else 0,
            )
            result = f"تم كتم {target.full_name} ومنعه من الكتابة بالمجموعة."
        await message.answer(result)
    except Exception as exc:
        logger.exception(
            "تعذر تنفيذ أمر %s على العضو %s في المجموعة %s",
            command_name,
            target.id,
            chat_id,
        )
        await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:300]}")
    return True


def _normalize_protection_command(text: str) -> str:
    command = re.sub(r"\s+", " ", text.strip())
    if command.startswith("/"):
        command = command[1:]
        first, separator, remainder = command.partition(" ")
        command = f"{first.split('@', maxsplit=1)[0]}{separator}{remainder}"
    return command.casefold()


async def _require_protection_admin(message: Message) -> bool:
    try:
        allowed = await is_group_admin(
            message.chat.id, message.from_user.id if message.from_user else None
        )
    except Exception:
        logger.exception(
            "تعذر التحقق من صلاحيات أمر الحماية في المجموعة %s",
            message.chat.id,
        )
        await message.answer("تعذر التحقق من صلاحياتك حالياً. حاول مرة أخرى.")
        return False
    if not allowed:
        await message.answer(
            "- عذرا هذا الامر مخصص للادارة والمشرفين فقط."
        )
    return allowed


def _closed_chat_permissions() -> ChatPermissions:
    return _chat_permissions(
        {
            "can_send_messages": False,
            "can_send_audios": False,
            "can_send_documents": False,
            "can_send_photos": False,
            "can_send_videos": False,
            "can_send_video_notes": False,
            "can_send_voice_notes": False,
            "can_send_polls": False,
            "can_send_other_messages": False,
            "can_add_web_page_previews": False,
            "can_react_to_messages": False,
        }
    )


async def handle_protection_command(message: Message, text: str) -> bool:
    if message.chat.type not in {"group", "supergroup"}:
        return False
    command = _normalize_protection_command(text)

    if command in {"قفل الدردشة", "قفل الدردشه", "فتح الدردشة", "فتح الدردشه"}:
        if not await _require_protection_admin(message):
            return True
        lock_name = f"chat_permissions:{message.chat.id}"
        is_lock = command.startswith("قفل")
        try:
            bot_member = await bot.get_chat_member(
                message.chat.id, (await bot.get_me()).id
            )
            if not getattr(bot_member, "can_restrict_members", False):
                await message.answer(
                    "يجب منح البوت صلاحية تقييد الأعضاء لتغيير صلاحيات الدردشة."
                )
                return True
            if is_lock:
                chat = await bot.get_chat(message.chat.id)
                current_permissions = getattr(chat, "permissions", None)
                if current_permissions is None:
                    await message.answer(
                        "تعذر قراءة صلاحيات الدردشة الحالية، لذلك لم يتم قفلها "
                        "حتى لا تضيع إعداداتها عند الفتح."
                    )
                    return True
                saved_permissions = db.get_setting(lock_name)
                if saved_permissions is None:
                    db.set_setting(
                        lock_name,
                        json.dumps(
                            current_permissions.model_dump(exclude_none=True),
                            ensure_ascii=False,
                        ),
                    )
                try:
                    await bot.set_chat_permissions(
                        chat_id=message.chat.id,
                        permissions=_closed_chat_permissions(),
                        use_independent_chat_permissions=True,
                    )
                except Exception:
                    if saved_permissions is None:
                        db.delete_setting(lock_name)
                    raise
                db.set_chat_lock(message.chat.id, "chat", True)
                await message.answer("تم قفل الدردشة ومنع الأعضاء من إرسال الرسائل.")
                return True

            saved_permissions = db.get_setting(lock_name)
            if not db.is_chat_lock_enabled(message.chat.id, "chat"):
                await message.answer("الدردشة مفتوحة بالفعل.")
                return True
            if not saved_permissions:
                await message.answer(
                    "تعذر استعادة إعدادات الدردشة السابقة. لم يتم تغيير الصلاحيات."
                )
                return True
            previous_permissions = _chat_permissions(
                json.loads(saved_permissions)
            )
            await bot.set_chat_permissions(
                chat_id=message.chat.id,
                permissions=previous_permissions,
                use_independent_chat_permissions=True,
            )
            db.set_chat_lock(message.chat.id, "chat", False)
            db.delete_setting(lock_name)
            await message.answer("تم فتح الدردشة واستعادة صلاحياتها السابقة.")
        except Exception as exc:
            logger.exception(
                "تعذر تنفيذ أمر %s في المجموعة %s",
                command,
                message.chat.id,
            )
            await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:250]}")
        return True

    if command in {"قفل التاك", "فتح التاك", "قفل التاغ", "فتح التاغ"}:
        if not await _require_protection_admin(message):
            return True
        try:
            bot_member = await bot.get_chat_member(
                message.chat.id, (await bot.get_me()).id
            )
            if not getattr(bot_member, "can_delete_messages", False):
                await message.answer(
                    "يجب منح البوت صلاحية حذف الرسائل لتنفيذ قفل التاك."
                )
                return True
            enabled = command.startswith("قفل")
            db.set_chat_lock(message.chat.id, "mentions", enabled)
            await message.answer(
                "تم قفل التاك والمنشن." if enabled else "تم فتح التاك والمنشن."
            )
        except Exception as exc:
            logger.exception("تعذر تغيير قفل التاك في %s", message.chat.id)
            await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:250]}")
        return True

    if command == "تنزيل مشرف":
        if not await _require_protection_admin(message):
            return True
        target = (
            message.reply_to_message.from_user
            if message.reply_to_message
            else None
        )
        if target is None:
            await message.answer("نفذ الأمر بالرد على رسالة المشرف المطلوب تنزيله.")
            return True
        try:
            bot_id = (await bot.get_me()).id
            if target.id == bot_id:
                await message.answer("لا يمكن تنزيل رتبة البوت.")
                return True
            bot_member = await bot.get_chat_member(message.chat.id, bot_id)
            if not getattr(bot_member, "can_promote_members", False):
                await message.answer(
                    "يجب منح البوت صلاحية إضافة مشرفين لتنزيل رتبة المشرف."
                )
                return True
            target_member = await bot.get_chat_member(message.chat.id, target.id)
            target_status = getattr(
                target_member.status, "value", target_member.status
            )
            if target_status == "creator":
                await message.answer("لا يمكن تنزيل مالك المجموعة.")
                return True
            if target_status != "administrator":
                await message.answer("المستخدم ليس مشرفاً في المجموعة.")
                return True
            demoted = await bot.promote_chat_member(
                chat_id=message.chat.id,
                user_id=target.id,
                is_anonymous=False,
                can_manage_chat=False,
                can_delete_messages=False,
                can_manage_video_chats=False,
                can_restrict_members=False,
                can_promote_members=False,
                can_change_info=False,
                can_invite_users=False,
                can_post_stories=False,
                can_edit_stories=False,
                can_delete_stories=False,
                can_post_messages=False,
                can_edit_messages=False,
                can_pin_messages=False,
                can_manage_topics=False,
                can_manage_direct_messages=False,
                can_manage_tags=False,
                can_send_welcome_messages=False,
            )
            if not demoted:
                raise RuntimeError("لم تؤكد Telegram نجاح تنزيل رتبة المشرف.")
            db.forget_group_member("moderators", message.chat.id, target.id)
            await message.answer(f"تم تنزيل رتبة {target.full_name} من الإشراف.")
        except Exception as exc:
            logger.exception(
                "تعذر تنزيل المشرف %s في المجموعة %s",
                target.id,
                message.chat.id,
            )
            await message.answer(f"تعذر تنفيذ الأمر: {str(exc)[:250]}")
        return True

    flash_match = re.fullmatch(r"(قفل|فتح)\s+التفليش", command)
    if flash_match:
        if not await _require_protection_admin(message):
            return True
        enabled = flash_match.group(1) == "قفل"
        if enabled:
            try:
                bot_member = await bot.get_chat_member(
                    message.chat.id, (await bot.get_me()).id
                )
            except Exception:
                logger.exception("تعذر التحقق من صلاحيات البوت في %s", message.chat.id)
                await message.answer("تعذر التحقق من صلاحيات البوت في المجموعة.")
                return True
            if not getattr(bot_member, "can_promote_members", False):
                await message.answer(
                    "يجب منح البوت صلاحية إضافة مشرفين حتى يتمكن من تنزيل رتبة المخالف."
                )
                return True
        db.set_chat_lock(message.chat.id, "anti_flash", enabled)
        if enabled:
            await message.answer(
                "تم تفعيل مراقبة التفليش المستمرة. سيتم تنبيه المالك عند الطرد "
                "للمرة السادسة، وتنزيل رتبة المشرف عند الطرد للمرة الحادية عشرة. "
                "يجب إبقاء البوت مشرفاً مع صلاحية إضافة المشرفين."
            )
        else:
            await message.answer("تم إيقاف قفل التفليش.")
        return True

    lock_match = re.fullmatch(r"(قفل|فتح)\s+(.+)", command)
    if lock_match:
        category = PROTECTION_CATEGORIES.get(lock_match.group(2).strip())
        if not category:
            return False
        if not await _require_protection_admin(message):
            return True
        try:
            bot_member = await bot.get_chat_member(
                message.chat.id, (await bot.get_me()).id
            )
        except Exception:
            logger.exception("تعذر التحقق من صلاحيات البوت في %s", message.chat.id)
            await message.answer("تعذر التحقق من صلاحيات البوت في المجموعة.")
            return True
        if not getattr(bot_member, "can_delete_messages", False):
            await message.answer(
                "يجب منح البوت صلاحية حذف الرسائل حتى يتمكن من تطبيق أوامر الحماية."
            )
            return True
        key, label = category
        enabled = lock_match.group(1) == "قفل"
        db.set_chat_lock(message.chat.id, key, enabled)
        if key == "links":
            result = (
                "تم قفل الروابط، سيتم حذف جميع الروابط المرسلة."
                if enabled
                else "تم فتح ارسال الروابط."
            )
        elif key in {"stickers", "animations"}:
            note = " (تطبق المراقبة على الملصقات والصور المتحركة كلٌ حسب اختياره)"
            state = "قفل" if enabled else "فتح"
            result = f"تم {state} {label}{note}."
        else:
            state = "قفل" if enabled else "فتح"
            result = f"تم {state} {label}."
        await message.answer(result)
        return True

    if command not in {"ايدي", "id"}:
        return False
    if not await _require_protection_admin(message):
        return True
    target = (
        message.reply_to_message.from_user
        if message.reply_to_message and message.reply_to_message.from_user
        else message.from_user
    )
    if target is None:
        await message.answer("استخدم الأمر بالرد على رسالة العضو المطلوب.")
        return True
    try:
        member = await bot.get_chat_member(message.chat.id, target.id)
    except Exception:
        logger.exception("تعذر جلب معلومات العضو %s في %s", target.id, message.chat.id)
        await message.answer("تعذر جلب معلومات العضو. تحقق من صلاحيات البوت.")
        return True
    status = getattr(member.status, "value", member.status)
    role_names = {
        "creator": "مالك المجموعة",
        "administrator": "مشرف",
        "member": "عضو",
        "restricted": "مقيّد",
        "left": "غادر المجموعة",
        "kicked": "محظور",
    }
    member_rank = (
        getattr(member, "custom_title", None)
        or getattr(member, "tag", None)
        or role_names.get(str(status), "عضو")
    )
    status_message = await message.answer("جارٍ جلب معلومات العضو وعدّ رسائله...")
    try:
        if not userbot.is_connected():
            raise RuntimeError("حساب المساعد غير متصل حالياً.")
        if not await userbot.is_user_authorized():
            raise RuntimeError("جلسة حساب المساعد غير مصادق عليها.")
        telethon_user = await _resolve_telethon_user(message.chat.id, target)
        full_user = await userbot(GetFullUserRequest(telethon_user))
        bio = full_user.full_user.about or "لا يوجد"
        message_count = 0
        async for _ in userbot.iter_messages(
            message.chat.id,
            from_user=telethon_user,
        ):
            message_count += 1
        activity = "قوي" if message_count > 100 else "مطفي هذا"
        username = f"@{target.username}" if target.username else "لا يوجد"
        await status_message.edit_text(
            f"⌯ الاسم | {escape(target.full_name)}\n"
            f"⌯ اليوزر | {escape(username)}\n"
            f"⌯ الايدي | <code>{target.id}</code>\n"
            f"⌯ الرتبة | {escape(member_rank)}\n"
            f"⌯ تفاعله | {activity}\n"
            f"⌯ عدد رسائله | {message_count}\n"
            f"⌯ البايو | {escape(bio)}",
            parse_mode="HTML",
        )
    except Exception as exc:
        logger.exception(
            "تعذر جلب البايو أو إحصاء رسائل العضو %s في المجموعة %s",
            target.id,
            message.chat.id,
        )
        await status_message.edit_text(
            "تعذر جلب البايو وعدّ الرسائل. تأكد أن الحساب المساعد عضو في المجموعة "
            f"وأن لديه وصولاً إلى سجل الرسائل. التفاصيل: {escape(str(exc)[:250])}"
        )
    return True


def message_protection_categories(message: Message) -> set[str]:
    categories: set[str] = set()
    if message.sticker:
        categories.add("stickers")
    if message.animation:
        categories.add("animations")
    if message.photo or (
        message.document
        and (message.document.mime_type or "").casefold().startswith("image/")
    ):
        categories.add("photos")
    if message.video or message.video_note or (
        message.document
        and (message.document.mime_type or "").casefold().startswith("video/")
    ):
        categories.add("videos")
    if message.audio or message.voice or (
        message.document
        and (message.document.mime_type or "").casefold().startswith("audio/")
    ):
        categories.add("audio")
    entities = [*(message.entities or []), *(message.caption_entities or [])]
    entity_types = {
        getattr(entity.type, "value", entity.type) for entity in entities
    }
    if entity_types & {"url", "text_link"}:
        categories.add("links")
    if entity_types & {"mention", "text_mention"}:
        categories.add("mentions")
    message_content = message.text or message.caption or ""
    if re.search(
        r"(?i)(?:https?://|www\.|(?:t|telegram)\.me/|tg://)[^\s]+"
        r"|\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}"
        r"(?:/[^\s]*)?",
        message_content,
    ):
        categories.add("links")
    if re.search(r"(?<![\w.+-])@[A-Za-z0-9_]{5,32}\b", message_content):
        categories.add("mentions")
    return categories


async def enforce_message_protection(message: Message) -> bool:
    if message.chat.type not in {"group", "supergroup"} or not message.from_user:
        return False
    categories = message_protection_categories(message)
    locked = {
        category
        for category in categories
        if db.is_chat_lock_enabled(message.chat.id, category)
    }
    if not locked:
        return False
    try:
        if await is_group_admin(message.chat.id, message.from_user.id):
            return False
    except Exception:
        logger.exception(
            "تعذر التحقق من صلاحية مرسل الرسالة في المجموعة %s",
            message.chat.id,
        )
        return False
    if "mentions" in locked:
        try:
            await message.reply(
                "- ممنوع ارسال التاكات والمنشن بالمجموعه."
            )
        except Exception:
            logger.exception(
                "تعذر إرسال تنبيه منع التاك في المجموعة %s",
                message.chat.id,
            )
    try:
        await bot.delete_message(message.chat.id, message.message_id)
    except Exception:
        logger.exception(
            "تعذر حذف رسالة مخالفة لقفل %s في المجموعة %s",
            ", ".join(sorted(locked)),
            message.chat.id,
        )
    return True


def _lock_for(chat_id: int) -> asyncio.Lock:
    if chat_id not in chat_locks:
        chat_locks[chat_id] = asyncio.Lock()
    return chat_locks[chat_id]


def _elapsed(state: dict[str, Any]) -> float:
    if state["paused"]:
        return float(state["offset"])
    return float(state["offset"]) + max(0.0, asyncio.get_running_loop().time() - state["started_at"])


async def _finish_timer(chat_id: int, token: str) -> None:
    try:
        while True:
            state = players.get(chat_id)
            if not state or state["token"] != token:
                return
            if state["paused"]:
                await state["resume_event"].wait()
                continue
            duration = state["track"].get("duration")
            if not duration:
                return
            remaining = float(duration) - _elapsed(state)
            if remaining <= 0.2:
                break
            await asyncio.sleep(min(remaining, 2.0))
        state = players.get(chat_id)
        if state and state.get("token") == token and state.get("repeat_once"):
            await play_track(chat_id, state["track"], api=state.get("api"))
            return
        api = state.get("api") if state else None
        if not await advance_track(chat_id, api=api):
            await stop_chat(chat_id, remove_panel=True, api=api)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("تعذر الانتقال التلقائي في المجموعة %s", chat_id)


async def _update_panel(
    chat_id: int,
    track: dict[str, Any],
    paused: bool,
    *,
    api=None,
) -> None:
    state = players.get(chat_id)
    if not state or not state.get("panel_message_id"):
        return
    api = api or state.get("api") or bot
    username = (await api.get_me()).username
    markup = control_keyboard(username, paused=paused)
    try:
        await api.edit_message_caption(
            chat_id=chat_id,
            message_id=state["panel_message_id"],
            caption=control_caption(track),
            reply_markup=_to_ptb_markup(markup) if _is_ptb_api(api) else markup,
        )
    except Exception as exc:
        # قد تكون لوحة التحكم رسالة نصية عند عدم إعداد صورة التحكم.
        if "there is no caption" in str(exc).lower() or "message is not modified" in str(exc).lower():
            try:
                await api.edit_message_text(
                    chat_id=chat_id,
                    message_id=state["panel_message_id"],
                    text=control_caption(track),
                    reply_markup=_to_ptb_markup(markup) if _is_ptb_api(api) else markup,
                )
            except Exception:
                logger.debug("تعذر تحديث لوحة التحكم", exc_info=True)
        else:
            logger.debug("تعذر تحديث وصف لوحة التحكم", exc_info=True)


async def _send_panel(message, track: dict[str, Any], *, api=None) -> int:
    api = api or bot
    username = (await api.get_me()).username
    markup = control_keyboard(username)
    if _is_ptb_api(api):
        markup = _to_ptb_markup(markup)
    photo_path = db.get_setting("control_photo")
    if photo_path and Path(photo_path).is_file():
        if hasattr(message, "reply_photo"):
            sent = await message.reply_photo(
                photo=str(photo_path),
                caption=control_caption(track),
                reply_markup=markup,
            )
        else:
            sent = await message.answer_photo(
                photo=photo_path,
                caption=control_caption(track),
                reply_markup=markup,
            )
    else:
        if hasattr(message, "reply_text"):
            sent = await message.reply_text(
                control_caption(track),
                reply_markup=markup,
            )
        else:
            sent = await message.answer(
                control_caption(track),
                reply_markup=markup,
            )
    return sent.message_id


def _is_ptb_api(api) -> bool:
    return api.__class__.__module__.startswith("telegram.")


def _to_ptb_markup(markup: InlineKeyboardMarkup):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    text=button.text,
                    callback_data=button.callback_data,
                    url=button.url,
                    style=button.style,
                )
                for button in row
            ]
            for row in markup.inline_keyboard
        ]
    )


async def ensure_helper_in_group(chat_id: int, *, api=None) -> None:
    """Ensures the assistant joined without promoting it to an administrator."""
    api = api or bot
    if not config.HAS_HELPER_SESSION:
        raise RuntimeError(
            "لا تتوفر جلسة حساب مساعد لهذا البوت؛ أضف جلسة من إدارة الصانع لتفعيل المكالمات."
        )
    helper = await userbot.get_me()
    helper_permissions = None
    try:
        helper_permissions = await userbot.get_permissions(chat_id, helper.id)
    except Exception:
        helper_permissions = None

    if helper_permissions is None or helper_permissions.has_left:
        try:
            invite = await api.create_chat_invite_link(chat_id=chat_id)
        except Exception as exc:
            raise RuntimeError(
                "امنح البوت صلاحية دعوة المستخدمين حتى يضيف الحساب المساعد تلقائياً."
            ) from exc
        try:
            invite_hash = urlparse(invite.invite_link).path.rstrip("/").split("/")[-1]
            await userbot(ImportChatInviteRequest(invite_hash.lstrip("+")))
        except Exception as exc:
            text = str(exc).lower()
            if "already" not in text and "participant" not in text:
                raise RuntimeError(
                    "تعذر إدخال الحساب المساعد؛ تأكد من أن الحساب غير محظور."
                ) from exc


async def play_track(
    chat_id: int,
    track: dict[str, Any],
    message: Message | None = None,
    *,
    offset: int = 0,
    keep_paused: bool = False,
    api=None,
) -> None:
    api = api or bot
    lock = _lock_for(chat_id)
    async with lock:
        await ensure_helper_in_group(chat_id, api=api)
        stream_url = await get_stream_url(track)
        stream = MediaStream(
            stream_url,
            ffmpeg_parameters=f"-ss {max(0, int(offset))}" if offset else None,
        )
        await _require_call_py().play(chat_id, stream)
        previous = players.get(chat_id, {})
        panel_id = previous.get("panel_message_id")
        if not panel_id and message is not None:
            panel_id = await _send_panel(message, track, api=api)
        state: dict[str, Any] = {
            "track": track,
            "token": str(time.monotonic_ns()),
            "repeat_once": False,
            "offset": float(offset),
            "started_at": asyncio.get_running_loop().time(),
            "paused": False,
            "resume_event": asyncio.Event(),
            "panel_message_id": panel_id,
            "api": api,
        }
        state["resume_event"].set()
        players[chat_id] = state
        db.add_history(chat_id, track["title"], "تم التشغيل")
        if keep_paused:
            await _require_call_py().pause(chat_id)
            state["paused"] = True
            state["resume_event"].clear()
        state["timer_task"] = asyncio.create_task(
            _finish_timer(chat_id, state["token"]),
            name=f"track-timer-{chat_id}",
        )
        await _update_panel(chat_id, track, paused=keep_paused, api=api)


async def advance_track(
    chat_id: int, message: Message | None = None, *, api=None
) -> bool:
    api = api or (players.get(chat_id) or {}).get("api") or bot
    while track := db.dequeue(chat_id):
        try:
            await play_track(chat_id, track, message, api=api)
            return True
        except Exception:
            logger.exception("فشل تشغيل الأغنية التالية للمجموعة %s", chat_id)
            await api.send_message(
                chat_id,
                "تعذر تشغيل مقطع من قائمة الانتظار؛ سأحاول تشغيل المقطع التالي.",
            )
    return False


async def stop_chat(chat_id: int, *, remove_panel: bool, api=None) -> None:
    state = players.pop(chat_id, None)
    api = api or (state or {}).get("api") or bot
    if state and state.get("timer_task"):
        if state["timer_task"] is not asyncio.current_task():
            state["timer_task"].cancel()
    db.clear_queue(chat_id)
    try:
        if call_py is not None:
            await call_py.leave_call(chat_id)
    except Exception:
        logger.debug("لا توجد مكالمة لمغادرتها في %s", chat_id)
    if remove_panel and state and state.get("panel_message_id"):
        try:
            await api.delete_message(chat_id, state["panel_message_id"])
        except Exception:
            pass


def _is_owner(user_id: int | None) -> bool:
    return bool(config.OWNER_ID and user_id == config.OWNER_ID)


def _is_bot_admin(user_id: int | None) -> bool:
    return bool(user_id is not None and user_id in db.list_bot_admins())


async def can_open_admin_panel(message: Message) -> bool:
    user_id = message.from_user.id if message.from_user else None
    if message.chat.type == "private":
        return _is_bot_admin(user_id)
    if message.chat.type == "channel" and user_id is None:
        return bool(message.sender_chat and message.sender_chat.id == message.chat.id)
    return await is_group_admin(message.chat.id, user_id)


async def send_admin_panel(message: Message) -> None:
    photo_path = db.get_setting("start_photo")
    if photo_path and Path(photo_path).is_file():
        await message.answer_photo(
            photo=photo_path,
            caption=ADMIN_PANEL_TEXT,
            parse_mode="HTML",
            reply_markup=admin_panel_keyboard(),
        )
    else:
        await message.answer(
            ADMIN_PANEL_TEXT,
            parse_mode="HTML",
            reply_markup=admin_panel_keyboard(),
        )


def owner_admins_text() -> str:
    admins = db.list_bot_admin_profiles()
    if not admins:
        body = "لا يوجد ادمنيه مصرح لهم حالياً."
    else:
        lines = []
        for row in admins:
            user_id = int(row["user_id"])
            username = (
                f"@{escape(str(row['username']))}"
                if row["username"]
                else "غير متوفر"
            )
            lines.append(
                f'⌯︙ الادمن | <a href="tg://user?id={user_id}">'
                f'{escape(str(row["display_name"] or user_id))}</a>'
                f" | اليوزر: {username} | الايدي: <code>{user_id}</code>"
            )
        body = "\n".join(lines)
    return f"⌯︙ <b>الادمنيه المصرح لهم:</b>\n{body}"


async def owner_groups(api=None) -> list[tuple[int, str]]:
    api = api or bot
    groups: list[tuple[int, str]] = []
    for row in db.list_active_group_chats():
        chat_id = int(row["chat_id"])
        try:
            chat = await api.get_chat(chat_id)
            groups.append((chat_id, chat.title or str(chat_id)))
        except Exception:
            logger.exception("تعذر جلب اسم المجموعة %s", chat_id)
            groups.append((chat_id, str(chat_id)))
    return groups


async def owner_group_admins_text(chat_id: int, api=None) -> str:
    api = api or bot
    chat = await api.get_chat(chat_id)
    members = await api.get_chat_administrators(chat_id)
    lines = [f"⌯︙ <b>مشرفو {escape(chat.title or str(chat_id))}:</b>"]
    for member in members:
        user = member.user
        username = f"@{user.username}" if user.username else user.full_name
        role = "مالك" if getattr(member.status, "value", member.status) == "creator" else "مشرف"
        lines.append(f"⌯︙ {role} | {escape(username)}")
    return "\n".join(lines)


async def edit_owner_page(
    message: Message, text: str, markup: InlineKeyboardMarkup
) -> None:
    if message.photo:
        await message.edit_caption(
            caption=text, parse_mode="HTML", reply_markup=markup
        )
    else:
        await message.edit_text(text=text, parse_mode="HTML", reply_markup=markup)


async def save_replied_photo(message: Message, setting: str) -> None:
    if not _is_owner(message.from_user.id if message.from_user else None):
        await message.answer("هذا الأمر متاح للمطور فقط.")
        return
    reply = message.reply_to_message
    if not reply or not reply.photo:
        await message.answer("استخدم الأمر رداً على صورة.")
        return
    photo = reply.photo[-1]
    image_dir = Path(config.IMAGES_DIR)
    image_dir.mkdir(parents=True, exist_ok=True)
    destination = (image_dir / f"{setting}_{uuid4().hex}.jpg").resolve()
    with tempfile.NamedTemporaryFile(
        dir=image_dir,
        prefix=f".{setting}_",
        suffix=".tmp",
        delete=False,
    ) as temporary_file:
        temporary_path = Path(temporary_file.name)

    try:
        telegram_file = await bot.get_file(photo.file_id)
        await telegram_file.download_to_drive(custom_path=temporary_path)
        os.replace(temporary_path, destination)
        old_path = db.get_setting(setting)
        db.set_setting(setting, str(destination))
    except Exception:
        temporary_path.unlink(missing_ok=True)
        destination.unlink(missing_ok=True)
        raise

    if old_path:
        old_destination = Path(old_path).resolve()
    else:
        old_destination = None
    if old_destination and old_destination != destination:
        try:
            old_destination.unlink(missing_ok=True)
        except OSError:
            logger.warning("تعذر حذف الصورة القديمة %s", old_destination)
    await message.answer("تم حفظ الصورة بنجاح.")


def save_helper_session() -> None:
    """Persist a newly authenticated Telethon StringSession in the local env file."""
    env_path = config.ENV_FILE
    session_string = userbot.session.save()
    existing = env_path.read_text(encoding="utf-8") if env_path.exists() else ""
    lines = existing.splitlines()
    replacement = f"SESSION_STRING={session_string}"
    session_line_found = False
    updated_lines = []
    for line in lines:
        if re.match(r"^\s*SESSION_STRING\s*=", line):
            if not session_line_found:
                updated_lines.append(replacement)
                session_line_found = True
        else:
            updated_lines.append(line)
    if not session_line_found:
        if updated_lines and updated_lines[-1]:
            updated_lines.append("")
        updated_lines.append(replacement)
    contents = "\n".join(updated_lines) + "\n"
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=env_path.parent,
        prefix=f".{env_path.name}_",
        suffix=".tmp",
        delete=False,
    ) as temporary_file:
        temporary_path = Path(temporary_file.name)
        temporary_file.write(contents)
    try:
        os.replace(temporary_path, env_path)
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise


async def command_start(message: Message) -> None:
    if message.chat.type == "private" and message.from_user:
        db.record_user(message.from_user.id)
    username = (await bot.get_me()).username
    photo_path = db.get_setting("start_photo")
    if photo_path and Path(photo_path).is_file():
        await message.answer_photo(
            photo=photo_path,
            caption=START_TEXT,
            reply_markup=main_keyboard(username),
        )
    else:
        await message.answer(START_TEXT, reply_markup=main_keyboard(username))


async def callback_pages(call: CallbackQuery) -> None:
    username = (await bot.get_me()).username
    try:
        if call.data == "help":
            if call.message.photo:
                await call.message.edit_caption(
                    caption=SETTINGS_TEXT,
                    reply_markup=settings_keyboard(username),
                )
            else:
                await call.message.edit_text(
                    SETTINGS_TEXT,
                    reply_markup=settings_keyboard(username),
                )
        else:
            photo_path = db.get_setting("start_photo")
            if call.message.photo and photo_path and Path(photo_path).is_file():
                await call.message.edit_media(
                    media=InputMediaPhoto(media=photo_path, caption=START_TEXT),
                    reply_markup=main_keyboard(username),
                )
            elif call.message.photo:
                await call.message.edit_caption(
                    caption=START_TEXT,
                    reply_markup=main_keyboard(username),
                )
            else:
                await call.message.edit_text(
                    START_TEXT,
                    reply_markup=main_keyboard(username),
                )
        await call.answer()
    except Exception:
        await call.answer("تعذر تحديث القائمة. أرسل /start مجدداً.", show_alert=True)


async def callback_command_menu(call: CallbackQuery) -> None:
    if not call.message:
        await call.answer("تعذر العثور على القائمة.", show_alert=True)
        return
    page_data = {
        "commands_admins": ADMIN_COMMANDS_TEXT,
        "commands_users": USER_COMMANDS_TEXT,
        "commands_developers": DEVELOPER_COMMANDS_TEXT,
        "commands_owner": OWNER_COMMANDS_TEXT,
    }
    if call.data == "commands":
        text = "⌯︙ اوامر الميوزك بالاسفل ."
        markup = commands_keyboard()
        parse_mode = None
    else:
        text = page_data[call.data]
        markup = (
            owner_commands_keyboard()
            if call.data == "commands_owner"
            else command_page_keyboard()
        )
        parse_mode = "HTML"
    try:
        if call.message.photo:
            await call.message.edit_caption(
                caption=text, reply_markup=markup, parse_mode=parse_mode
            )
        else:
            await call.message.edit_text(
                text=text, reply_markup=markup, parse_mode=parse_mode
            )
        await call.answer()
    except Exception:
        logger.exception("تعذر عرض صفحة الأوامر %s", call.data)
        await call.answer("تعذر تحديث القائمة.", show_alert=True)


def install_music_ui_handlers_ptb(application) -> None:
    """Register PTB versions of the public start and help-menu handlers."""
    from telegram import InlineKeyboardButton as PTBInlineKeyboardButton
    from telegram import InlineKeyboardMarkup as PTBInlineKeyboardMarkup
    from telegram import InputMediaPhoto as PTBInputMediaPhoto
    from telegram.ext import CallbackQueryHandler, CommandHandler

    def convert_markup(markup: InlineKeyboardMarkup) -> PTBInlineKeyboardMarkup:
        return PTBInlineKeyboardMarkup(
            [
                [
                    PTBInlineKeyboardButton(
                        text=button.text,
                        callback_data=button.callback_data,
                        url=button.url,
                        style=button.style,
                    )
                    for button in row
                ]
                for row in markup.inline_keyboard
            ]
        )

    async def edit_page(message, text: str, markup: InlineKeyboardMarkup) -> None:
        converted_markup = convert_markup(markup)
        if message.photo:
            await message.edit_caption(
                caption=text,
                parse_mode="HTML",
                reply_markup=converted_markup,
            )
        else:
            await message.edit_text(
                text=text,
                parse_mode="HTML",
                reply_markup=converted_markup,
            )

    async def start(update, context) -> None:
        message = update.effective_message
        if message is None:
            return
        user = update.effective_user
        if message.chat.type == "private" and user is not None:
            db.record_user(user.id)
        username = (await context.bot.get_me()).username
        markup = convert_markup(main_keyboard(username))
        photo_path = db.get_setting("start_photo")
        if photo_path and Path(photo_path).is_file():
            await message.reply_photo(
                photo=str(photo_path),
                caption=START_TEXT,
                reply_markup=markup,
            )
        else:
            await message.reply_text(START_TEXT, reply_markup=markup)

    async def pages(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        username = (await context.bot.get_me()).username
        try:
            if call.data == "help":
                markup = convert_markup(settings_keyboard(username))
                if message.photo:
                    await message.edit_caption(
                        caption=SETTINGS_TEXT,
                        reply_markup=markup,
                    )
                else:
                    await message.edit_text(SETTINGS_TEXT, reply_markup=markup)
            else:
                photo_path = db.get_setting("start_photo")
                markup = convert_markup(main_keyboard(username))
                if message.photo and photo_path and Path(photo_path).is_file():
                    await message.edit_media(
                        media=PTBInputMediaPhoto(
                            media=str(photo_path),
                            caption=START_TEXT,
                        ),
                        reply_markup=markup,
                    )
                elif message.photo:
                    await message.edit_caption(
                        caption=START_TEXT,
                        reply_markup=markup,
                    )
                else:
                    await message.edit_text(START_TEXT, reply_markup=markup)
            await call.answer()
        except Exception:
            logger.exception("تعذر تحديث قائمة البوت")
            await call.answer("تعذر تحديث القائمة. أرسل /start مجدداً.", show_alert=True)

    async def command_menu(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        page_data = {
            "commands_admins": ADMIN_COMMANDS_TEXT,
            "commands_users": USER_COMMANDS_TEXT,
            "commands_developers": DEVELOPER_COMMANDS_TEXT,
            "commands_owner": OWNER_COMMANDS_TEXT,
        }
        if call.data == "commands":
            text = "⌯︙ اوامر الميوزك بالاسفل ."
            markup = commands_keyboard()
            parse_mode = None
        else:
            text = page_data[call.data]
            markup = (
                owner_commands_keyboard()
                if call.data == "commands_owner"
                else command_page_keyboard()
            )
            parse_mode = "HTML"
        try:
            converted_markup = convert_markup(markup)
            if message.photo:
                await message.edit_caption(
                    caption=text,
                    reply_markup=converted_markup,
                    parse_mode=parse_mode,
                )
            else:
                await message.edit_text(
                    text=text,
                    reply_markup=converted_markup,
                    parse_mode=parse_mode,
                )
            await call.answer()
        except Exception:
            logger.exception("تعذر عرض صفحة الأوامر %s", call.data)
            await call.answer("تعذر تحديث القائمة.", show_alert=True)

    async def owner_menu(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        if not _is_bot_admin(call.from_user.id):
            await call.answer("هذه الأوامر خاصة بمالك البوت.", show_alert=True)
            return
        try:
            if call.data == "owner_settings":
                await edit_page(message, ADMIN_PANEL_TEXT, admin_panel_keyboard())
            elif call.data == "owner_admins":
                await edit_page(
                    message,
                    owner_admins_text(),
                    owner_admins_keyboard(),
                )
            elif message.chat.type in {"group", "supergroup"}:
                await edit_page(
                    message,
                    await owner_group_admins_text(
                        message.chat.id,
                        api=context.bot,
                    ),
                    InlineKeyboardMarkup(
                        inline_keyboard=[
                            [
                                _button(
                                    "رجوع",
                                    style="danger",
                                    callback_data="commands_owner",
                                )
                            ]
                        ]
                    ),
                )
            else:
                groups = await owner_groups(api=context.bot)
                if not groups:
                    await edit_page(
                        message,
                        "لا توجد مجموعات مسجلة للبوت. استخدم أمر تفعيل داخل المجموعة.",
                        InlineKeyboardMarkup(
                            inline_keyboard=[
                                [
                                    _button(
                                        "رجوع",
                                        style="danger",
                                        callback_data="commands_owner",
                                    )
                                ]
                            ]
                        ),
                    )
                else:
                    await edit_page(
                        message,
                        "اختر المجموعة لعرض قائمة مشرفيها:",
                        owner_group_keyboard(groups),
                    )
            await call.answer()
        except Exception:
            logger.exception("تعذر تحديث قائمة مالك البوت: %s", call.data)
            await call.answer("تعذر تحديث القائمة.", show_alert=True)

    async def owner_group_admins(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        if not _is_bot_admin(call.from_user.id):
            await call.answer("هذا الأمر خاص بمالك البوت.", show_alert=True)
            return
        try:
            chat_id = int(call.data.partition(":")[2])
            await edit_page(
                message,
                await owner_group_admins_text(
                    chat_id,
                    api=context.bot,
                ),
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            _button(
                                "رجوع",
                                style="danger",
                                callback_data="owner_activate",
                            )
                        ]
                    ]
                ),
            )
            await call.answer()
        except Exception:
            logger.exception("تعذر عرض قائمة مشرفي المجموعة")
            await call.answer("تعذر جلب قائمة المشرفين.", show_alert=True)

    async def panel_allowed(message, user_id: int, api) -> bool:
        if message.chat.type == "private":
            return _is_bot_admin(user_id)
        return await is_group_admin(message.chat.id, user_id, api=api)

    async def admin_panel(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        try:
            if not await panel_allowed(message, call.from_user.id, context.bot):
                await call.answer(
                    "هذه اللوحة خاصة بالإدارة فقط ⚠️",
                    show_alert=True,
                )
                return
            if call.data == "admin_panel":
                text, markup = ADMIN_PANEL_TEXT, admin_panel_keyboard()
            elif call.data in ADMIN_PANEL_LIST_CATEGORIES:
                text, markup = await admin_panel_list_page(
                    call.data,
                    message.chat.id if message.chat.type != "private" else 0,
                    chat_title=message.chat.title,
                    page_size=(
                        ADMIN_LIST_PHOTO_PAGE_SIZE
                        if message.photo
                        else ADMIN_LIST_PAGE_SIZE
                    ),
                    allow_clear=message.chat.type in {"group", "supergroup"},
                    api=context.bot,
                )
            else:
                text = ADMIN_PANEL_SECTIONS[call.data]
                markup = admin_panel_section_keyboard()
            await edit_page(message, text, markup)
            await call.answer()
        except Exception:
            logger.exception("تعذر تحديث لوحة الإدارة")
            await call.answer("تعذر تحديث اللوحة.", show_alert=True)

    async def panel_list_page(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على القائمة.", show_alert=True)
            return
        try:
            if not await panel_allowed(message, call.from_user.id, context.bot):
                await call.answer(
                    "هذه القائمة خاصة بالإدارة فقط ⚠️",
                    show_alert=True,
                )
                return
            _, category, raw_offset = call.data.split(":", maxsplit=2)
            section = {
                value: key
                for key, value in ADMIN_PANEL_LIST_CATEGORIES.items()
            }.get(category)
            if section is None:
                raise ValueError("Unknown list category")
            text, markup = await admin_panel_list_page(
                section,
                message.chat.id if message.chat.type != "private" else 0,
                int(raw_offset),
                chat_title=message.chat.title,
                page_size=(
                    ADMIN_LIST_PHOTO_PAGE_SIZE
                    if message.photo
                    else ADMIN_LIST_PAGE_SIZE
                ),
                allow_clear=message.chat.type in {"group", "supergroup"},
                api=context.bot,
            )
            await edit_page(message, text, markup)
            await call.answer()
        except ValueError:
            await call.answer("بيانات صفحة القائمة غير صالحة.", show_alert=True)
        except Exception:
            logger.exception("تعذر تحديث صفحة قائمة الإدارة")
            await call.answer("تعذر تحديث القائمة.", show_alert=True)

    async def panel_clear_prompt(update, context) -> None:
        call = update.callback_query
        message = call.message
        category = call.data.partition(":")[2]
        if message is None or category not in {"muted", "restricted"}:
            await call.answer("طلب غير صالح.", show_alert=True)
            return
        if message.chat.type not in {"group", "supergroup"}:
            await call.answer(
                "استخدم هذا الزر من داخل المجموعة المعنية.",
                show_alert=True,
            )
            return
        try:
            if not await is_group_admin(
                message.chat.id,
                call.from_user.id,
                api=context.bot,
            ):
                await call.answer(
                    "هذه العملية خاصة بالإدارة والمشرفين.",
                    show_alert=True,
                )
                return
            confirmation = (
                "ـ سيتم الغاء جميع المكتومين، هل انت متأكد ؟"
                if category == "muted"
                else "ـ سيتم الغاء التقييد عن جميع المقيدين ، هل انت متأكد ؟"
            )
            await edit_page(
                message,
                confirmation,
                admin_panel_clear_confirmation_keyboard(category),
            )
            await call.answer()
        except Exception:
            logger.exception("تعذر عرض تأكيد مسح قائمة %s", category)
            await call.answer("تعذر عرض رسالة التأكيد.", show_alert=True)

    async def panel_clear_finish(update, context) -> None:
        call = update.callback_query
        message = call.message
        category = call.data.partition(":")[2]
        section = {
            "muted": "panel_muted",
            "restricted": "panel_restricted",
        }.get(category)
        if message is None or section is None:
            await call.answer("طلب غير صالح.", show_alert=True)
            return
        if message.chat.type not in {"group", "supergroup"}:
            await call.answer("القائمة غير مرتبطة بمجموعة.", show_alert=True)
            return
        try:
            if not await is_group_admin(
                message.chat.id,
                call.from_user.id,
                api=context.bot,
            ):
                await call.answer(
                    "هذه العملية خاصة بالإدارة والمشرفين.",
                    show_alert=True,
                )
                return
            if call.data.startswith("panel_clear_confirm:"):
                released, failed = await release_tracked_members(
                    category,
                    message.chat.id,
                    api=context.bot,
                )
            else:
                released = failed = None
            text, markup = await admin_panel_list_page(
                section,
                message.chat.id,
                chat_title=message.chat.title,
                page_size=(
                    ADMIN_LIST_PHOTO_PAGE_SIZE
                    if message.photo
                    else ADMIN_LIST_PAGE_SIZE
                ),
                allow_clear=True,
                api=context.bot,
            )
            await edit_page(message, text, markup)
            if released is None:
                await call.answer()
            else:
                await call.answer(
                    f"تم رفع القيود عن {released} عضو؛ تعذر رفعها عن {failed}.",
                    show_alert=bool(failed),
                )
        except Exception:
            logger.exception(
                "تعذر تنفيذ إجراء قائمة %s في %s",
                category,
                message.chat.id,
            )
            await call.answer("تعذر تنفيذ العملية.", show_alert=True)

    async def noop(update, context) -> None:
        await update.callback_query.answer()

    async def playback_controls(update, context) -> None:
        call = update.callback_query
        message = call.message
        if message is None:
            await call.answer("تعذر العثور على المجموعة.", show_alert=True)
            return
        chat_id = message.chat.id
        api = context.bot
        try:
            allowed = await is_group_admin(
                chat_id,
                call.from_user.id,
                api=api,
            )
        except Exception:
            logger.exception(
                "تعذر التحقق من صلاحيات لوحة التحكم في %s",
                chat_id,
            )
            await call.answer(
                "تعذر التحقق من صلاحياتك حالياً.",
                show_alert=True,
            )
            return
        if not allowed:
            await call.answer(
                "ـ عذراً هذا الامر يخص المشرفين فقط ⚠️",
                show_alert=True,
            )
            return

        action = call.data
        state = players.get(chat_id)
        if action == "ctrl_stop":
            await stop_chat(chat_id, remove_panel=True, api=api)
            await call.answer("تم إنهاء التشغيل وتفريغ قائمة الانتظار.")
            return
        if action == "ctrl_skip":
            if not await advance_track(chat_id, api=api):
                await stop_chat(chat_id, remove_panel=True, api=api)
                await call.answer(NO_QUEUE_TEXT, show_alert=True)
            else:
                await call.answer("تم تخطي المقطع الحالي.")
            return
        if not state:
            await call.answer("لا يوجد مقطع يعمل حالياً.", show_alert=True)
            return
        try:
            if action == "ctrl_pause":
                await _require_call_py().pause(chat_id)
                state["offset"] = _elapsed(state)
                state["paused"] = True
                state["resume_event"].clear()
                await _update_panel(
                    chat_id,
                    state["track"],
                    paused=True,
                    api=api,
                )
                await call.answer("تم إيقاف التشغيل مؤقتاً.")
            elif action == "ctrl_play":
                if state["paused"]:
                    await _require_call_py().resume(chat_id)
                    state["started_at"] = asyncio.get_running_loop().time()
                    state["paused"] = False
                    state["resume_event"].set()
                await _update_panel(
                    chat_id,
                    state["track"],
                    paused=False,
                    api=api,
                )
                await call.answer("تم استئناف التشغيل.")
            elif action in {"ctrl_forward", "ctrl_rewind"}:
                delta = 10 if action == "ctrl_forward" else -10
                target = max(0, int(_elapsed(state) + delta))
                duration = state["track"].get("duration")
                if duration:
                    target = min(target, max(0, int(duration) - 1))
                track = state["track"]
                was_paused = state["paused"]
                old_task = state.get("timer_task")
                if old_task:
                    old_task.cancel()
                await play_track(
                    chat_id,
                    track,
                    offset=target,
                    keep_paused=was_paused,
                    api=api,
                )
                await call.answer("تم تحريك المقطع.")
        except Exception as exc:
            logger.exception("تعذر تنفيذ تحكم %s في %s", action, chat_id)
            await call.answer(
                f"تعذر تنفيذ الأمر: {str(exc)[:150]}",
                show_alert=True,
            )

    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        CallbackQueryHandler(pages, pattern=r"^(?:help|home)$")
    )
    application.add_handler(
        CallbackQueryHandler(
            command_menu,
            pattern=r"^(?:commands|commands_admins|commands_users|"
            r"commands_developers|commands_owner)$",
        )
    )
    application.add_handler(
        CallbackQueryHandler(
            owner_menu,
            pattern=r"^(?:owner_settings|owner_activate|owner_admins)$",
        )
    )
    application.add_handler(
        CallbackQueryHandler(owner_group_admins, pattern=r"^owner_group:-?\d+$")
    )
    application.add_handler(
        CallbackQueryHandler(
            admin_panel,
            pattern=(
                r"^(?:admin_panel|panel_admins|panel_restricted|"
                r"panel_moderators|panel_muted|panel_mute_commands|"
                r"panel_promote_commands|panel_lock|panel_protection)$"
            ),
        )
    )
    application.add_handler(
        CallbackQueryHandler(panel_list_page, pattern=r"^panel_list:")
    )
    application.add_handler(
        CallbackQueryHandler(panel_clear_prompt, pattern=r"^panel_clear:")
    )
    application.add_handler(
        CallbackQueryHandler(
            panel_clear_finish,
            pattern=r"^panel_clear_(?:cancel|confirm):",
        )
    )
    application.add_handler(CallbackQueryHandler(noop, pattern=r"^noop$"))
    application.add_handler(
        CallbackQueryHandler(playback_controls, pattern=r"^ctrl_")
    )


async def callback_owner_commands(call: CallbackQuery) -> None:
    message = call.message
    if not message:
        await call.answer("تعذر العثور على القائمة.", show_alert=True)
        return
    if not _is_bot_admin(call.from_user.id):
        await call.answer("هذه الأوامر خاصة بمالك البوت.", show_alert=True)
        return

    if call.data == "owner_settings":
        try:
            await edit_owner_page(message, ADMIN_PANEL_TEXT, admin_panel_keyboard())
            await call.answer()
        except Exception:
            logger.exception("تعذر فتح إعدادات الإدارة")
            await call.answer("تعذر فتح قائمة الإدارة.", show_alert=True)
        return

    if call.data == "owner_admins":
        try:
            await edit_owner_page(
                message, owner_admins_text(), owner_admins_keyboard()
            )
            await call.answer()
        except Exception:
            logger.exception("تعذر عرض ادمنية البوت")
            await call.answer("تعذر عرض قائمة الادمنيه.", show_alert=True)
        return

    if call.data == "owner_add_admin":
        pending_admin_add[call.from_user.id] = (
            message.chat.id,
            message.message_id,
            bool(message.photo),
        )
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    _button(
                        "رجوع",
                        style="danger",
                        callback_data="owner_cancel_add_admin",
                    )
                ]
            ]
        )
        try:
            await edit_owner_page(
                message,
                "• ارسل ايدي المستخدم لاضافته ادمن بالبوت:",
                markup,
            )
            await call.answer()
        except Exception:
            pending_admin_add.pop(call.from_user.id, None)
            logger.exception("تعذر بدء إضافة ادمن")
            await call.answer("تعذر بدء إضافة الادمن.", show_alert=True)
        return

    if call.data == "owner_cancel_add_admin":
        pending_admin_add.pop(call.from_user.id, None)
        try:
            await edit_owner_page(
                message, owner_admins_text(), owner_admins_keyboard()
            )
            await call.answer()
        except Exception:
            logger.exception("تعذر الرجوع لقائمة الادمنيه")
            await call.answer("تعذر تحديث القائمة.", show_alert=True)
        return

    if message.chat.type in {"group", "supergroup"}:
        try:
            text = await owner_group_admins_text(message.chat.id)
            await edit_owner_page(
                message,
                text,
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [_button("رجوع", style="danger", callback_data="commands_owner")]
                    ]
                ),
            )
            await call.answer()
        except Exception:
            logger.exception("تعذر تحديث مشرفي المجموعة %s", message.chat.id)
            await call.answer("تعذر جلب قائمة المشرفين.", show_alert=True)
        return

    try:
        groups = await owner_groups()
        if not groups:
            await edit_owner_page(
                message,
                "لا توجد مجموعات مسجلة للبوت. استخدم أمر تفعيل داخل المجموعة.",
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [_button("رجوع", style="danger", callback_data="commands_owner")]
                    ]
                ),
            )
        else:
            await edit_owner_page(
                message,
                "اختر المجموعة لعرض قائمة مشرفيها:",
                owner_group_keyboard(groups),
            )
        await call.answer()
    except Exception:
        logger.exception("تعذر تحميل مجموعات المالك")
        await call.answer("تعذر تحميل قائمة المجموعات.", show_alert=True)


async def callback_owner_group_admins(call: CallbackQuery) -> None:
    message = call.message
    if not message:
        await call.answer("تعذر العثور على القائمة.", show_alert=True)
        return
    if not _is_bot_admin(call.from_user.id):
        await call.answer("هذا الأمر خاص بمالك البوت.", show_alert=True)
        return
    try:
        chat_id = int(call.data.partition(":")[2])
        text = await owner_group_admins_text(chat_id)
        await edit_owner_page(
            message,
            text,
            InlineKeyboardMarkup(
                inline_keyboard=[
                    [_button("رجوع", style="danger", callback_data="owner_activate")]
                ]
            ),
        )
        await call.answer()
    except Exception:
        logger.exception("تعذر عرض قائمة مشرفي المجموعة")
        await call.answer("تعذر جلب قائمة المشرفين.", show_alert=True)


async def callback_admin_panel(call: CallbackQuery) -> None:
    message = call.message
    if not message:
        await call.answer("تعذر العثور على القائمة.", show_alert=True)
        return
    try:
        if message.chat.type == "private":
            allowed = _is_bot_admin(call.from_user.id)
        else:
            allowed = await is_group_admin(message.chat.id, call.from_user.id)
    except Exception:
        logger.exception("تعذر التحقق من صلاحية لوحة الإدارة في %s", message.chat.id)
        await call.answer("تعذر التحقق من صلاحياتك حالياً.", show_alert=True)
        return
    if not allowed:
        await call.answer("هذه اللوحة خاصة بالإدارة فقط ⚠️", show_alert=True)
        return
    if call.data == "admin_panel":
        text = ADMIN_PANEL_TEXT
        markup = admin_panel_keyboard()
    elif call.data in ADMIN_PANEL_LIST_CATEGORIES:
        try:
            text, markup = await admin_panel_list_page(
                call.data,
                message.chat.id if message.chat.type != "private" else 0,
                chat_title=message.chat.title,
                page_size=(
                    ADMIN_LIST_PHOTO_PAGE_SIZE
                    if message.photo
                    else ADMIN_LIST_PAGE_SIZE
                ),
                allow_clear=(
                    message.chat.type in {"group", "supergroup"}
                ),
            )
        except Exception:
            logger.exception("تعذر تحميل بيانات قسم %s", call.data)
            await call.answer("تعذر تحميل بيانات القائمة.", show_alert=True)
            return
    else:
        text = ADMIN_PANEL_SECTIONS[call.data]
        markup = admin_panel_section_keyboard()
    try:
        if message.photo:
            await message.edit_caption(
                caption=text, parse_mode="HTML", reply_markup=markup
            )
        else:
            await message.edit_text(
                text=text, parse_mode="HTML", reply_markup=markup
            )
        await call.answer()
    except Exception:
        logger.exception("تعذر تحديث لوحة الإدارة")
        await call.answer("تعذر تحديث اللوحة.", show_alert=True)


async def callback_admin_panel_list_page(call: CallbackQuery) -> None:
    message = call.message
    if not message:
        await call.answer("تعذر العثور على القائمة.", show_alert=True)
        return
    try:
        if message.chat.type == "private":
            allowed = _is_bot_admin(call.from_user.id)
        else:
            allowed = await is_group_admin(message.chat.id, call.from_user.id)
    except Exception:
        logger.exception("تعذر التحقق من صلاحية قائمة الإدارة في %s", message.chat.id)
        await call.answer("تعذر التحقق من صلاحياتك حالياً.", show_alert=True)
        return
    if not allowed:
        await call.answer("هذه القائمة خاصة بالإدارة فقط ⚠️", show_alert=True)
        return
    try:
        _, category, raw_offset = call.data.split(":", maxsplit=2)
        section = {
            value: key for key, value in ADMIN_PANEL_LIST_CATEGORIES.items()
        }.get(category)
        if section is None:
            raise ValueError("Unknown list category")
        text, markup = await admin_panel_list_page(
            section,
            message.chat.id if message.chat.type != "private" else 0,
            int(raw_offset),
            chat_title=message.chat.title,
            page_size=(
                ADMIN_LIST_PHOTO_PAGE_SIZE
                if message.photo
                else ADMIN_LIST_PAGE_SIZE
            ),
            allow_clear=(
                message.chat.type in {"group", "supergroup"}
            ),
        )
        if message.photo:
            await message.edit_caption(
                caption=text, parse_mode="HTML", reply_markup=markup
            )
        else:
            await message.edit_text(
                text=text, parse_mode="HTML", reply_markup=markup
            )
        await call.answer()
    except ValueError:
        await call.answer("بيانات صفحة القائمة غير صالحة.", show_alert=True)
    except Exception:
        logger.exception("تعذر تحديث صفحة قائمة الإدارة")
        await call.answer("تعذر تحديث القائمة.", show_alert=True)


async def callback_admin_panel_clear_prompt(call: CallbackQuery) -> None:
    message = call.message
    category = call.data.partition(":")[2]
    if not message or category not in {"muted", "restricted"}:
        await call.answer("طلب غير صالح.", show_alert=True)
        return
    if message.chat.type not in {"group", "supergroup"}:
        await call.answer("استخدم هذا الزر من داخل المجموعة المعنية.", show_alert=True)
        return
    try:
        allowed = await is_group_admin(message.chat.id, call.from_user.id)
    except Exception:
        logger.exception("تعذر التحقق من صلاحية إلغاء القيود في %s", message.chat.id)
        await call.answer("تعذر التحقق من صلاحياتك حالياً.", show_alert=True)
        return
    if not allowed:
        await call.answer("هذه العملية خاصة بالإدارة والمشرفين.", show_alert=True)
        return
    if category == "muted":
        confirmation = "ـ سيتم الغاء جميع المكتومين، هل انت متأكد ؟"
    else:
        confirmation = "ـ سيتم الغاء التقييد عن جميع المقيدين ، هل انت متأكد ؟"
    try:
        markup = admin_panel_clear_confirmation_keyboard(category)
        if message.photo:
            await message.edit_caption(
                caption=confirmation, reply_markup=markup
            )
        else:
            await message.edit_text(confirmation, reply_markup=markup)
        await call.answer()
    except Exception:
        logger.exception("تعذر عرض تأكيد مسح قائمة %s", category)
        await call.answer("تعذر عرض رسالة التأكيد.", show_alert=True)


async def callback_admin_panel_clear_cancel(call: CallbackQuery) -> None:
    message = call.message
    category = call.data.partition(":")[2]
    section = {
        "muted": "panel_muted",
        "restricted": "panel_restricted",
    }.get(category)
    if not message or not section:
        await call.answer("طلب غير صالح.", show_alert=True)
        return
    if message.chat.type not in {"group", "supergroup"}:
        await call.answer("القائمة غير مرتبطة بمجموعة.", show_alert=True)
        return
    try:
        allowed = await is_group_admin(message.chat.id, call.from_user.id)
        if not allowed:
            await call.answer("هذه العملية خاصة بالإدارة والمشرفين.", show_alert=True)
            return
        text, markup = await admin_panel_list_page(
            section,
            message.chat.id,
            chat_title=message.chat.title,
            page_size=(
                ADMIN_LIST_PHOTO_PAGE_SIZE
                if message.photo
                else ADMIN_LIST_PAGE_SIZE
            ),
            allow_clear=True,
        )
        if message.photo:
            await message.edit_caption(
                caption=text, parse_mode="HTML", reply_markup=markup
            )
        else:
            await message.edit_text(
                text=text, parse_mode="HTML", reply_markup=markup
            )
        await call.answer()
    except Exception:
        logger.exception("تعذر الرجوع إلى قائمة %s", category)
        await call.answer("تعذر تحديث القائمة.", show_alert=True)


async def callback_admin_panel_clear_confirm(call: CallbackQuery) -> None:
    message = call.message
    category = call.data.partition(":")[2]
    section = {
        "muted": "panel_muted",
        "restricted": "panel_restricted",
    }.get(category)
    if not message or not section:
        await call.answer("طلب غير صالح.", show_alert=True)
        return
    if message.chat.type not in {"group", "supergroup"}:
        await call.answer("القائمة غير مرتبطة بمجموعة.", show_alert=True)
        return
    try:
        allowed = await is_group_admin(message.chat.id, call.from_user.id)
        if not allowed:
            await call.answer("هذه العملية خاصة بالإدارة والمشرفين.", show_alert=True)
            return
        released, failed = await release_tracked_members(category, message.chat.id)
        text, markup = await admin_panel_list_page(
            section,
            message.chat.id,
            chat_title=message.chat.title,
            page_size=(
                ADMIN_LIST_PHOTO_PAGE_SIZE
                if message.photo
                else ADMIN_LIST_PAGE_SIZE
            ),
            allow_clear=True,
        )
        if message.photo:
            await message.edit_caption(
                caption=text, parse_mode="HTML", reply_markup=markup
            )
        else:
            await message.edit_text(
                text=text, parse_mode="HTML", reply_markup=markup
            )
        await call.answer(
            f"تم رفع القيود عن {released} عضو؛ تعذر رفعها عن {failed}.",
            show_alert=bool(failed),
        )
    except Exception:
        logger.exception(
            "تعذر تنفيذ إلغاء الكل لقائمة %s في %s",
            category,
            message.chat.id,
        )
        await call.answer("تعذر تنفيذ العملية.", show_alert=True)


async def callback_noop(call: CallbackQuery) -> None:
    await call.answer()


async def callback_controls(call: CallbackQuery) -> None:
    if not call.message:
        await call.answer("تعذر العثور على المجموعة.", show_alert=True)
        return
    chat_id = call.message.chat.id
    try:
        allowed = await is_group_admin(chat_id, call.from_user.id)
    except Exception:
        logger.exception("تعذر التحقق من صلاحيات لوحة التحكم في %s", chat_id)
        await call.answer("تعذر التحقق من صلاحياتك حالياً.", show_alert=True)
        return
    if not allowed:
        await call.answer("ـ عذراً هذا الامر يخص المشرفين فقط ⚠️", show_alert=True)
        return
    action = call.data
    state = players.get(chat_id)
    if action == "ctrl_stop":
        await stop_chat(chat_id, remove_panel=True)
        await call.answer("تم إنهاء التشغيل وتفريغ قائمة الانتظار.")
        return
    if action == "ctrl_skip":
        if not await advance_track(chat_id):
            await stop_chat(chat_id, remove_panel=True)
            await call.answer(NO_QUEUE_TEXT, show_alert=True)
        else:
            await call.answer("تم تخطي المقطع الحالي.")
        return
    if not state:
        await call.answer("لا يوجد مقطع يعمل حالياً.", show_alert=True)
        return
    try:
        if action == "ctrl_pause":
            await _require_call_py().pause(chat_id)
            state["offset"] = _elapsed(state)
            state["paused"] = True
            state["resume_event"].clear()
            await _update_panel(chat_id, state["track"], paused=True)
            await call.answer("تم إيقاف التشغيل مؤقتاً.")
        elif action == "ctrl_play":
            if state["paused"]:
                await _require_call_py().resume(chat_id)
                state["started_at"] = asyncio.get_running_loop().time()
                state["paused"] = False
                state["resume_event"].set()
            await _update_panel(chat_id, state["track"], paused=False)
            await call.answer("تم استئناف التشغيل.")
        elif action in {"ctrl_forward", "ctrl_rewind"}:
            delta = 10 if action == "ctrl_forward" else -10
            target = max(0, int(_elapsed(state) + delta))
            duration = state["track"].get("duration")
            if duration:
                target = min(target, max(0, int(duration) - 1))
            track = state["track"]
            was_paused = state["paused"]
            old_task = state.get("timer_task")
            if old_task:
                old_task.cancel()
            await play_track(chat_id, track, offset=target, keep_paused=was_paused)
            await call.answer("تم تحريك المقطع.")
    except Exception as exc:
        logger.exception("تعذر تنفيذ تحكم %s في %s", action, chat_id)
        await call.answer(f"تعذر تنفيذ الأمر: {str(exc)[:150]}", show_alert=True)


async def command_text(message: Message) -> None:
    text = (message.text or "").strip()
    normalized = re.sub(r"\s+", " ", text)
    chat_id = message.chat.id
    lower = normalized.casefold()

    if message.chat.type in {"group", "supergroup", "channel"}:
        db.record_chat(chat_id, message.chat.type)
    elif message.chat.type == "private" and message.from_user:
        db.record_user(message.from_user.id)

    sender_id = message.from_user.id if message.from_user else None
    pending = pending_admin_add.get(sender_id) if sender_id is not None else None
    if pending:
        if not _is_owner(sender_id):
            pending_admin_add.pop(sender_id, None)
            await message.answer("إضافة الادمن متاحة لمالك البوت فقط.")
            return
        if not re.fullmatch(r"\d+", normalized):
            await message.answer("أرسل ايدي المستخدم كأرقام فقط، أو اضغط رجوع.")
            return
        admin_id = int(normalized)
        if admin_id <= 0:
            await message.answer("ايدي المستخدم غير صالح.")
            return
        display_name = None
        username = None
        try:
            profile = await bot.get_chat(admin_id)
            display_name = " ".join(
                part
                for part in (profile.first_name, profile.last_name)
                if part
            ) or None
            username = profile.username
        except Exception:
            logger.info(
                "تم حفظ ادمن %s بالمعرّف فقط؛ تعذر جلب بياناته مسبقاً.",
                admin_id,
            )
        db.add_bot_admin(
            admin_id,
            sender_id,
            display_name=display_name,
            username=username,
        )
        pending_admin_add.pop(sender_id, None)
        owner_chat_id, owner_message_id, owner_message_has_photo = pending
        try:
            if owner_message_has_photo:
                await bot.edit_message_caption(
                    chat_id=owner_chat_id,
                    message_id=owner_message_id,
                    caption=owner_admins_text(),
                    parse_mode="HTML",
                    reply_markup=owner_admins_keyboard(),
                )
            else:
                await bot.edit_message_text(
                    chat_id=owner_chat_id,
                    message_id=owner_message_id,
                    text=owner_admins_text(),
                    parse_mode="HTML",
                    reply_markup=owner_admins_keyboard(),
                )
        except Exception:
            logger.exception("تعذر تحديث قائمة الادمنيه بعد الإضافة")
        await message.answer("تمت إضافة المستخدم إلى قائمة ادمنية البوت.")
        return

    if re.match(r"/?تنزيل\s+ادمن(?:@\w+)?(?:\s|$)", normalized):
        if not _is_owner(sender_id):
            await message.answer("تنزيل ادمنية البوت متاح لمالك البوت فقط.")
            return
        remove_admin_match = re.fullmatch(
            r"/?تنزيل\s+ادمن(?:@\w+)?\s*\+?\s*(\d+)",
            normalized,
        )
        if not remove_admin_match:
            await message.answer("استخدم الأمر هكذا: تنزيل ادمن + ايدي المستخدم.")
            return
        admin_id = int(remove_admin_match.group(1))
        if admin_id <= 0:
            await message.answer("ايدي المستخدم غير صالح.")
            return
        if admin_id == config.OWNER_ID:
            await message.answer("لا يمكن تنزيل مالك البوت من قائمة الإدارة.")
            return
        if not db.remove_bot_admin(admin_id):
            await message.answer("هذا المستخدم غير موجود في قائمة ادمنية البوت.")
            return
        await message.answer(
            f"تم تنزيل الادمن وإزالته من إدارة البوت. الايدي: <code>{admin_id}</code>",
            parse_mode="HTML",
        )
        return

    if await enforce_message_protection(message):
        return
    if await handle_promotion_command(message, normalized):
        return
    if await handle_moderation_command(message, normalized):
        return
    if await handle_protection_command(message, normalized):
        return

    if re.fullmatch(r"/?(?:لوحة|ادارة|إدارة)(?:@\w+)?", normalized):
        try:
            allowed = await can_open_admin_panel(message)
        except Exception:
            logger.exception("تعذر التحقق من صلاحية فتح اللوحة في %s", chat_id)
            await message.answer("تعذر التحقق من صلاحياتك حالياً. حاول مرة أخرى.")
            return
        if not allowed:
            await message.answer("ـ عذراً هذا الامر يخص المشرفين فقط ⚠️")
            return
        await send_admin_panel(message)
        return

    if lower in {
        "الضبط", "تفعيل", "الادمنيه", "الادمنية", "الإدمنيه", "الإدمنية"
    }:
        if not _is_bot_admin(sender_id):
            await message.answer("هذا الأمر متاح لادمنية البوت فقط.")
            return
        if lower == "الضبط":
            await send_admin_panel(message)
            return
        if lower in {"الادمنيه", "الادمنية", "الإدمنيه", "الإدمنية"}:
            await message.answer(
                owner_admins_text(),
                parse_mode="HTML",
                reply_markup=owner_admins_keyboard(),
            )
            return
        if message.chat.type in {"group", "supergroup"}:
            try:
                await message.answer(
                    await owner_group_admins_text(chat_id),
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup(
                        inline_keyboard=[
                            [_button("رجوع", style="danger", callback_data="commands_owner")]
                        ]
                    ),
                )
            except Exception:
                logger.exception("تعذر جلب مشرفي المجموعة %s", chat_id)
                await message.answer("تعذر جلب قائمة المشرفين.")
            return
        groups = await owner_groups()
        if not groups:
            await message.answer("لا توجد مجموعات مسجلة للبوت.")
        else:
            await message.answer(
                "اختر المجموعة لعرض قائمة مشرفيها:",
                reply_markup=owner_group_keyboard(groups),
            )
        return

    if lower in {
        "الاحصائيات",
        "الإحصائيات",
        "احصائيات",
        "إحصائيات",
        "/stats",
        "/الاحصائيات",
    }:
        if not _is_owner(message.from_user.id if message.from_user else None):
            await message.answer("هذا الأمر متاح للمطور فقط.")
            return
        if message.chat.type != "private":
            await message.answer("أرسل أمر الإحصائيات في المحادثة الخاصة مع البوت.")
            return
        users, channels, groups = db.get_statistics()
        await message.answer(
            f"- عدد الأعضاء في البوت: {users}\n"
            f"- عدد القنوات التي تم إضافة البوت بها: {channels}\n"
            f"- عدد المجموعات التي تم إضافة البوت إليها: {groups}"
        )
        return

    if lower.startswith("اضف صورة") or lower.startswith("اضف صوره"):
        await save_replied_photo(message, "start_photo")
        return
    if lower in {".صورة", ".صوره"}:
        await save_replied_photo(message, "control_photo")
        return
    if lower in {"الاوامر", "الاعدادات", "الإعدادات", "اعدادات", "settings"}:
        username = (await bot.get_me()).username
        await message.answer(SETTINGS_TEXT, reply_markup=settings_keyboard(username))
        return
    if lower in {"الانتظار", "queue"}:
        current = players.get(chat_id)
        queued = db.list_queue(chat_id)
        if not current and not queued:
            await message.answer("قائمة الانتظار فارغة حالياً.")
            return
        lines = ["⌯︙ قائمة التشغيل:"]
        if current:
            lines.append(f"▶️ يعمل الآن: {current['track']['title']}")
        lines.extend(
            f"{index}. {track['title']}" for index, track in enumerate(queued, start=1)
        )
        await message.answer("\n".join(lines)[:4000])
        return
    if lower in {"بنك", "ping"}:
        started = perf_counter()
        status = await message.answer("• يتم فحص سرعة الاستجابة.. ⌛️")
        elapsed_ms = (perf_counter() - started) * 1000
        await status.edit_text(f"• سرعة استجابة البوت ({elapsed_ms:.0f} ms ⚡️).")
        return

    admin_only_exact = {
        "ايقاف", "إيقاف", "توقف", "pause", "وقف",
        "استئناف", "تشغيل", "resume",
        "انهاء", "إنهاء", "ايقاف التشغيل", "إيقاف التشغيل", "stop",
        "تخطي", "skip", "تكرار", "كتم", "الغاء_الكتم", "إلغاء_الكتم",
    }
    if lower in admin_only_exact or re.match(
        r"^(?:تقديم|ارجع|حذف)\s+\d+$", lower
    ):
        if not await require_group_admin(message):
            return
    if lower in {"ايقاف", "إيقاف", "توقف", "pause", "وقف"}:
        state = players.get(chat_id)
        if not state:
            await message.answer("لا يوجد مقطع يعمل حالياً.")
            return
        try:
            await _require_call_py().pause(chat_id)
            state["offset"] = _elapsed(state)
            state["paused"] = True
            state["resume_event"].clear()
            await _update_panel(chat_id, state["track"], paused=True)
            await message.answer("تم إيقاف التشغيل مؤقتاً.")
        except Exception as exc:
            await message.answer(f"تعذر الإيقاف المؤقت: {exc}")
        return
    if lower in {"استئناف", "تشغيل", "resume"}:
        state = players.get(chat_id)
        if not state:
            await message.answer("لا يوجد مقطع متوقف لاستئنافه.")
            return
        try:
            await _require_call_py().resume(chat_id)
            state["started_at"] = asyncio.get_running_loop().time()
            state["paused"] = False
            state["resume_event"].set()
            await _update_panel(chat_id, state["track"], paused=False)
            await message.answer("تم استئناف التشغيل.")
        except Exception as exc:
            await message.answer(f"تعذر استئناف التشغيل: {exc}")
        return
    if lower == "تكرار":
        state = players.get(chat_id)
        if not state:
            await message.answer("لا يوجد مقطع يعمل حالياً.")
        else:
            state["repeat_once"] = True
            await message.answer("سيتم تكرار المقطع الحالي مرة واحدة بعد انتهائه.")
        return
    seek_match = re.match(r"^(تقديم|ارجع)\s+(\d+)$", lower)
    if seek_match:
        state = players.get(chat_id)
        if not state:
            await message.answer("لا يوجد مقطع يعمل حالياً.")
            return
        target = int(_elapsed(state)) + (
            int(seek_match.group(2)) if seek_match.group(1) == "تقديم"
            else -int(seek_match.group(2))
        )
        duration = state["track"].get("duration")
        target = max(0, target)
        if duration:
            target = min(target, max(0, int(duration) - 1))
        old_task = state.get("timer_task")
        if old_task:
            old_task.cancel()
        try:
            await play_track(
                chat_id, state["track"], offset=target,
                keep_paused=bool(state["paused"]),
            )
            await message.answer("تم تحريك المقطع إلى الوقت المطلوب.")
        except Exception as exc:
            logger.exception("تعذر تحريك المقطع في المجموعة %s", chat_id)
            await message.answer(f"تعذر تحريك المقطع: {str(exc)[:300]}")
        return
    delete_match = re.match(r"^حذف\s+(\d+)$", lower)
    if delete_match:
        if db.remove_queue_item(chat_id, int(delete_match.group(1))):
            await message.answer("تم حذف المقطع من قائمة الانتظار.")
        else:
            await message.answer("رقم المقطع غير موجود في قائمة الانتظار.")
        return
    if lower in {"كتم", "الغاء_الكتم", "إلغاء_الكتم"}:
        try:
            if lower == "كتم":
                await _require_call_py().mute(chat_id)
                await message.answer("تم كتم صوت البوت في المكالمة.")
            else:
                await _require_call_py().unmute(chat_id)
                await message.answer("تم إلغاء كتم الصوت.")
        except Exception as exc:
            logger.exception("تعذر تغيير كتم الصوت في المجموعة %s", chat_id)
            await message.answer(f"تعذر تغيير كتم الصوت: {str(exc)[:300]}")
        return
    if lower in {"انهاء", "إنهاء", "ايقاف التشغيل", "إيقاف التشغيل", "stop"}:
        await stop_chat(chat_id, remove_panel=True)
        await message.answer("تم إيقاف التشغيل وتفريغ قائمة الانتظار بالكامل.")
        return
    if lower in {"تخطي", "skip"}:
        if not await advance_track(chat_id, message):
            await stop_chat(chat_id, remove_panel=True)
            await message.answer(NO_QUEUE_TEXT)
        return
    if lower in {"السجل", "history"}:
        rows = db.get_history(chat_id)
        queued = db.list_queue(chat_id)
        if not rows and not queued:
            await message.answer("سجل التشغيل وقائمة الانتظار فارغان حالياً.")
            return
        lines = ["📜 سجل تشغيل الأغاني:"]
        lines.extend(f"• {row['title']} ({row['action']})" for row in rows)
        if queued:
            lines.extend(["", "⏭ قائمة الانتظار:"])
            lines.extend(f"• {item['title']}" for item in queued)
        await message.answer("\n".join(lines)[:4000])
        return
    if lower in {"اصلاح", "إصلاح", "fix"}:
        await stop_chat(chat_id, remove_panel=True)
        db.clear_history(chat_id)
        await message.answer("تم تنظيف السجل وإصلاح الحالة المؤقتة.")
        return

    play_match = re.match(r"^(?:شغل|تشغيل|play)\s+(.+)$", normalized, flags=re.IGNORECASE)
    add_match = re.match(r"^(?:اضافة|إضافة|اضف|add)\s+(.+)$", normalized, flags=re.IGNORECASE)
    youtube_match = re.match(r"^(?:يوت|يوتيوب)\s+(.+)$", normalized, flags=re.IGNORECASE)
    query = play_match.group(1).strip() if play_match else None
    enqueue_only = False
    if add_match:
        query = add_match.group(1).strip()
        enqueue_only = True
    if youtube_match:
        query = youtube_match.group(1).strip()
        if len(query) > 500:
            await message.answer("الطلب طويل جداً. أرسل اسم المقطع بشكل أقصر.")
            return
        status = await message.answer("• يتم البحث عن المقطع.. ⌛")
        try:
            track = await resolve_track(query)
            if not track:
                await status.edit_text("لم يتم العثور على المقطع.")
                return
            track = await cache_track(track)
            await status.delete()
            await message.answer_audio(
                audio=track["media_path"],
                title=track["title"],
                caption=(
                    f"• تم تشغيل {track['title']}، مدة التشغيل "
                    f"{track.get('duration_text') or 'غير معروف'}."
                ),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "سورس كريفن",
                                url="https://t.me/a_zi63",
                                style="success",
                            )
                        ]
                    ]
                ),
            )
        except Exception as exc:
            logger.exception("تعذر إرسال الوسائط للمجموعة %s", chat_id)
            try:
                await status.edit_text(f"تعذر تجهيز المقطع: {str(exc)[:500]}")
            except Exception:
                await message.answer(f"تعذر تجهيز المقطع: {str(exc)[:500]}")
        return
    if not query:
        return
    if (play_match or add_match) and not config.HAS_HELPER_SESSION:
        await message.answer(
            "لا تتوفر جلسة حساب مساعد لهذا البوت؛ أضف جلسة من إدارة الصانع "
            "لتفعيل أوامر التشغيل في المكالمات."
        )
        return
    if play_match:
        if message.chat.type not in {"group", "supergroup"}:
            await message.answer(
                'ـ هذا الامر يخص المشرفين فقط, لكن يمكنك استخدام امر "يوت + اسم الاغنيه"'
            )
            return
        try:
            is_admin = await is_group_admin(
                chat_id, message.from_user.id if message.from_user else None
            )
        except Exception:
            logger.exception(
                "تعذر التحقق من صلاحية التشغيل في المجموعة %s", chat_id
            )
            await message.answer("تعذر التحقق من صلاحياتك حالياً. حاول مرة أخرى.")
            return
        if not is_admin:
            await message.answer(
                'ـ هذا الامر يخص المشرفين فقط, لكن يمكنك استخدام امر "يوت + اسم الاغنيه"'
            )
            return
    if len(query) > 500:
        await message.answer("الطلب طويل جداً. أرسل اسم الأغنية أو الرابط بشكل أقصر.")
        return

    status = await message.answer("• يتم البحث عبر محرك 𝐄𝐈𝐓𝐇𝐄𝐑 ♪ …")
    try:
        track = await resolve_track(query)
        if not track:
            await status.edit_text("لم يتم العثور على المقطع. تحقق من الاسم أو الرابط.")
            return
        track["requested_by"] = message.from_user.id if message.from_user else None
        if enqueue_only or chat_id in players:
            if db.queue_size(chat_id) >= config.MAX_QUEUE_SIZE:
                await status.edit_text("وصلت قائمة الانتظار إلى الحد الأقصى.")
                return
            await status.edit_text("جارٍ تجهيز الملف الصوتي وإضافته إلى قائمة الانتظار... ♫")
            track = await cache_track(track)
            db.enqueue(chat_id, track)
            db.add_history(chat_id, track["title"], "أُضيف إلى الانتظار")
            await status.edit_text(
                f"تم إضافة: {track['title']} إلى قائمة الانتظار بنجاح ♫\n"
                f"عدد المقاطع المنتظرة: {db.queue_size(chat_id)}"
            )
            return
        await status.delete()
        await play_track(chat_id, track, message)
    except Exception as exc:
        logger.exception("فشل طلب تشغيل في المجموعة %s", chat_id)
        error_text = str(exc)
        if (
            "admin privileges are required" in error_text.lower()
            or "CreateGroupCallRequest" in error_text
        ):
            error_text = (
                "ابدأ مكالمة صوتية في المجموعة بواسطة مشرف أولاً؛ "
                "الحساب المساعد لا يحتاج إلى صلاحية مشرف، وسينضم للبث تلقائياً."
            )
        try:
            await status.edit_text(f"تعذر تشغيل المقطع: {error_text[:700]}")
        except Exception:
            await message.answer(f"تعذر تشغيل المقطع: {error_text[:700]}")


async def protect_non_text_group_messages(message: Message) -> None:
    await enforce_message_protection(message)


async def record_channel_post(message: Message) -> None:
    db.record_chat(message.chat.id, "channel")
    text = (message.text or "").strip()
    if re.fullmatch(r"/?(?:لوحة|ادارة|إدارة)(?:@\w+)?", text):
        await command_text(message)


async def notify_owner_about_flash(chat_id: int, text: str) -> None:
    if not config.OWNER_ID:
        logger.error("تعذر إرسال تنبيه التفليش: OWNER_ID غير مضبوط.")
        return
    try:
        await bot.send_message(config.OWNER_ID, text)
    except Exception:
        logger.exception("تعذر إرسال تنبيه التفليش إلى المالك")
        try:
            await bot.send_message(
                chat_id,
                "تعذر إرسال تنبيه التفليش إلى المالك في الخاص. "
                "تأكد أن المالك بدأ محادثة خاصة مع البوت.",
            )
        except Exception:
            logger.exception("تعذر إرسال تنبيه بديل في المجموعة %s", chat_id)


async def monitor_admin_kicks(update: ChatMemberUpdated) -> None:
    if update.chat.type in {"group", "supergroup", "channel"}:
        new_status = getattr(
            update.new_chat_member.status, "value", update.new_chat_member.status
        )
        if new_status not in {"administrator", "creator"}:
            db.remove_chat_bot_admin(update.chat.id, update.new_chat_member.user.id)

    if (
        update.chat.type not in {"group", "supergroup"}
        or not db.is_chat_lock_enabled(update.chat.id, "anti_flash")
    ):
        return
    old_status = getattr(
        update.old_chat_member.status, "value", update.old_chat_member.status
    )
    new_status = getattr(
        update.new_chat_member.status, "value", update.new_chat_member.status
    )
    actor = update.from_user
    target = update.new_chat_member.user
    if (
        new_status != "kicked"
        or old_status in {"kicked", "left"}
        or actor.id == target.id
        or _is_owner(actor.id)
    ):
        return
    try:
        actor_member = await bot.get_chat_member(update.chat.id, actor.id)
    except Exception:
        logger.exception(
            "تعذر التحقق من منفذ الطرد %s في المجموعة %s",
            actor.id,
            update.chat.id,
        )
        return
    actor_status = getattr(actor_member.status, "value", actor_member.status)
    if actor_status != "administrator":
        return

    kick_count = db.record_flash_kick(update.chat.id, actor.id)
    actor_name = f"@{actor.username}" if actor.username else actor.full_name
    chat_name = update.chat.title or str(update.chat.id)
    if kick_count == FLASH_KICK_ALERT_THRESHOLD + 1:
        await notify_owner_about_flash(
            update.chat.id,
            f"ـ تنبيه، قام المشرف ({actor_name}) بطرد ({kick_count} اعضاء) "
            f"من المجموعة ({chat_name}). سيتم تنزيل رتبته اذا تجاوز عدد المطرودين "
            f"اكثر من {FLASH_KICK_DEMOTION_THRESHOLD} اعضاء.",
        )
    if kick_count <= FLASH_KICK_DEMOTION_THRESHOLD:
        return

    try:
        demoted = await bot.promote_chat_member(
            chat_id=update.chat.id,
            user_id=actor.id,
            is_anonymous=False,
            can_manage_chat=False,
            can_delete_messages=False,
            can_manage_video_chats=False,
            can_restrict_members=False,
            can_promote_members=False,
            can_change_info=False,
            can_invite_users=False,
            can_post_stories=False,
            can_edit_stories=False,
            can_delete_stories=False,
            can_post_messages=False,
            can_edit_messages=False,
            can_pin_messages=False,
            can_manage_topics=False,
            can_manage_direct_messages=False,
            can_manage_tags=False,
            can_send_welcome_messages=False,
        )
        if not demoted:
            raise RuntimeError("لم تؤكد Telegram نجاح تنزيل رتبة المشرف.")
    except Exception:
        logger.exception(
            "تعذر تنزيل رتبة المشرف %s بعد %s حالات طرد في %s",
            actor.id,
            kick_count,
            update.chat.id,
        )
        await notify_owner_about_flash(
            update.chat.id,
            f"تعذر تنزيل رتبة المشرف {actor_name} بعد طرد {kick_count} أعضاء "
            f"من المجموعة {chat_name}. تحقق من صلاحيات البوت.",
        )
        return
    await notify_owner_about_flash(
        update.chat.id,
        f"ـ تم تنزيل رتبة المشرف ({actor_name}) من المجموعة ({chat_name}) "
        f"بعد طرد {kick_count} عضواً.",
    )


async def bot_added_to_group(update: ChatMemberUpdated) -> None:
    if update.chat.type not in {"group", "supergroup", "channel"}:
        return
    new_status = getattr(update.new_chat_member.status, "value", update.new_chat_member.status)
    db.record_chat(
        update.chat.id,
        update.chat.type,
        active=new_status not in {"left", "kicked"},
    )
    if new_status != "administrator":
        return
    if config.HAS_HELPER_SESSION:
        try:
            await ensure_helper_in_group(update.chat.id)
        except Exception as exc:
            logger.exception("تعذر تفعيل البوت تلقائياً في الدردشة %s", update.chat.id)
            await bot.send_message(
                update.chat.id,
                f"تعذر التفعيل التلقائي: {exc}",
            )
            return

    elevated_actor = None
    actor = update.from_user
    member = update.new_chat_member
    if (
        actor
        and not actor.is_bot
        and _has_full_bot_admin_rights(update.chat.type, member)
    ):
        try:
            actor_member = await bot.get_chat_member(update.chat.id, actor.id)
            actor_status = getattr(
                actor_member.status, "value", actor_member.status
            )
        except Exception:
            logger.exception(
                "تعذر التحقق من مشرف المجموعة الذي رفع البوت %s في %s",
                actor.id,
                update.chat.id,
            )
        else:
            if actor_status in {"administrator", "creator"}:
                db.add_chat_bot_admin(
                    update.chat.id,
                    actor.id,
                    actor.id,
                    display_name=actor.full_name,
                    username=actor.username,
                )
                elevated_actor = actor

    if elevated_actor:
        actor_label = (
            f"@{escape(elevated_actor.username)}"
            if elevated_actor.username
            else (
                f'<a href="tg://user?id={elevated_actor.id}">'
                f"{escape(elevated_actor.full_name)}</a>"
            )
        )
        await bot.send_message(
            update.chat.id,
            f"- المستخدم {actor_label} تم رفعه مطور وتحديث قائمة الادمن.",
            parse_mode="HTML",
        )

    await bot.send_message(
        update.chat.id,
        (
            "تم تفعيل البوت تلقائياً وإضافة الحساب المساعد. "
            "ابدأ مكالمة صوتية بواسطة مشرف، ثم أرسل: شغل + اسم الأغنية ♫"
            if config.HAS_HELPER_SESSION
            else "تم تفعيل البوت تلقائياً. أضف جلسة حساب مساعد من إدارة الصانع "
            "لتفعيل تشغيل الموسيقى في المكالمات."
        ),
    )


def install_music_handlers_ptb(application: Application) -> None:
    async def start(update: Update, context) -> None:
        message = update.effective_message
        if message is not None:
            await command_start(PTBMessageAdapter(message))

    async def text_message(update: Update, context) -> None:
        message = update.effective_message
        if message is not None:
            await command_text(PTBMessageAdapter(message))

    async def group_media(update: Update, context) -> None:
        message = update.effective_message
        if message is not None:
            await protect_non_text_group_messages(PTBMessageAdapter(message))

    async def channel_post(update: Update, context) -> None:
        message = update.channel_post
        if message is not None:
            await record_channel_post(PTBMessageAdapter(message))

    async def chat_member_update(update: Update, context) -> None:
        if update.chat_member is not None:
            await monitor_admin_kicks(update.chat_member)

    async def bot_member_update(update: Update, context) -> None:
        if update.my_chat_member is not None:
            await bot_added_to_group(update.my_chat_member)

    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        MessageHandler(filters.TEXT, text_message)
    )
    application.add_handler(
        MessageHandler(
            filters.ChatType.GROUPS & ~filters.TEXT,
            group_media,
        )
    )
    application.add_handler(
        MessageHandler(filters.UpdateType.CHANNEL_POST, channel_post)
    )
    application.add_handler(
        ChatMemberHandler(
            chat_member_update,
            ChatMemberHandler.CHAT_MEMBER,
        )
    )
    application.add_handler(
        ChatMemberHandler(
            bot_member_update,
            ChatMemberHandler.MY_CHAT_MEMBER,
        )
    )
    callback_handlers = (
        (callback_pages, r"^(?:help|home)$"),
        (
            callback_command_menu,
            r"^(?:commands|commands_admins|commands_users|"
            r"commands_developers|commands_owner)$",
        ),
        (
            callback_owner_commands,
            r"^(?:owner_settings|owner_activate|owner_admins|"
            r"owner_add_admin|owner_cancel_add_admin)$",
        ),
        (callback_owner_group_admins, r"^owner_group:-?\d+$"),
        (
            callback_admin_panel,
            r"^(?:admin_panel|"
            + "|".join(re.escape(key) for key in ADMIN_PANEL_SECTIONS)
            + r")$",
        ),
        (callback_admin_panel_list_page, r"^panel_list:"),
        (callback_admin_panel_clear_prompt, r"^panel_clear:"),
        (callback_admin_panel_clear_cancel, r"^panel_clear_cancel:"),
        (callback_admin_panel_clear_confirm, r"^panel_clear_confirm:"),
        (callback_noop, r"^noop$"),
        (callback_controls, r"^ctrl_"),
    )
    for callback, pattern in callback_handlers:
        async def dispatch_callback(
            update: Update,
            context,
            handler=callback,
        ) -> None:
            if update.callback_query is not None:
                await handler(update.callback_query)

        application.add_handler(
            CallbackQueryHandler(dispatch_callback, pattern=pattern)
        )


async def main() -> None:
    global call_py
    factory_database = None
    application = Application.builder().bot(bot).build()
    install_music_handlers_ptb(application)
    application_initialized = False
    polling_started = False
    try:
        if os.getenv("BOT_TIER") == "free":
            database_url = os.getenv("FACTORY_DATABASE_URL", "").strip()
            bot_id = os.getenv("BOT_ID", "").strip()
            if not database_url or not bot_id.isdigit():
                raise RuntimeError(
                    "Factory free-tier integration is missing its database URL or bot ID."
                )
            from database.connection import Database
            from factory_integration import install_free_tier_features_ptb

            factory_database = Database(database_url)
            install_free_tier_features_ptb(
                application,
                factory_database,
                int(bot_id),
            )
        if config.HAS_HELPER_SESSION:
            await userbot.connect()
            if not await userbot.is_user_authorized():
                if os.getenv("BOT_CONFIG_PATH"):
                    raise RuntimeError(
                        "The factory-provided Telethon session is not authorized. "
                        "Replace the assistant session in the factory settings."
                    )
                logger.warning(
                    "جلسة الحساب المساعد غير مصادق عليها؛ "
                    "سجّل الدخول مرة واحدة لحفظ جلسة صالحة."
                )
                await userbot.start()
                save_helper_session()
                logger.info("تم حفظ جلسة الحساب المساعد في ملف البيئة.")
            else:
                logger.info("تم تحميل جلسة الحساب المساعد من ملف البيئة.")
            call_py = PyTgCalls(userbot)
            await call_py.start()
            logger.info("بدأ الحساب المساعد ومحرك PyTgCalls")
        else:
            logger.info(
                "لا توجد جلسة حساب مساعد؛ سيعمل البوت وتبقى أوامر المكالمات معطلة."
            )
        await application.initialize()
        application_initialized = True
        await application.start()
        await application.updater.start_polling(
            allowed_updates=[
                "message",
                "callback_query",
                "channel_post",
                "chat_member",
                "my_chat_member",
            ]
        )
        polling_started = True
        await asyncio.Event().wait()
    finally:
        if polling_started:
            await application.updater.stop()
        if application.running:
            await application.stop()
        if application_initialized:
            await application.shutdown()
        for state in list(players.values()):
            timer = state.get("timer_task")
            if timer:
                timer.cancel()
        if userbot.is_connected():
            try:
                await userbot.disconnect()
            except Exception:
                logger.exception("تعذر فصل الحساب المساعد بشكل نظيف")
        if factory_database:
            await factory_database.close()
        db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("تم إيقاف البوت")
