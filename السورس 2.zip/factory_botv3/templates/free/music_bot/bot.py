"""Template entry point used by the bot factory."""

import asyncio

from music import main


if __name__ == "__main__":
    asyncio.run(main())
