"""Per-instance configuration for the music bot template."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / ".env"
load_dotenv(ENV_FILE, override=False)


def _required(name: str, *aliases: str) -> str:
    for candidate in (name, *aliases):
        value = os.getenv(candidate, "").strip()
        if value:
            return value
    names = ", ".join((name, *aliases))
    raise RuntimeError(f"Required environment variable is missing: {names}")


API_ID = int(_required("TELEGRAM_API_ID", "API_ID"))
if API_ID <= 0:
    raise RuntimeError("TELEGRAM_API_ID must be positive.")
API_HASH = _required("TELEGRAM_API_HASH", "API_HASH")
BOT_TOKEN = _required("BOT_TOKEN")
SESSION_STRING = (
    os.getenv("TELETHON_SESSION", "").strip()
    or os.getenv("SESSION_STRING", "").strip()
)
HAS_HELPER_SESSION = bool(SESSION_STRING)
OWNER_ID = int(os.getenv("BOT_OWNER_ID", os.getenv("OWNER_ID", "0")) or "0")
DEVELOPER_USERNAME = (
    os.getenv("FACTORY_DEVELOPER_CHANNEL", "ss_rssb").strip().lstrip("@")
)
SOURCE_CHANNEL = (
    os.getenv("FACTORY_UPDATES_CHANNEL", "a_zi63").strip().lstrip("@")
)
DATABASE_PATH = str(ROOT / "data" / "music_bot.sqlite3")
IMAGES_DIR = str(ROOT / "data" / "images")
CACHE_DIR = str(ROOT / "data" / "cache")
YT_DLP_COOKIEFILE = os.getenv("YT_DLP_COOKIEFILE", "").strip() or None
MAX_QUEUE_SIZE = 50
