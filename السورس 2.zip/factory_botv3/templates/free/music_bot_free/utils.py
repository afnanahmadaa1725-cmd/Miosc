"""أدوات آمنة لأسماء ملفات الوسائط في القالب المجاني."""

from pathlib import Path


def safe_filename(name: str, user_id: int) -> str:
    cleaned = Path(name).name.replace("\x00", "").strip()
    return f"{user_id}_{cleaned or 'audio.bin'}"
