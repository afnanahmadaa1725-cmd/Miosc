import asyncio
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, call, patch

from core.process_manager import ProcessManager, YOUTUBE_REQUIREMENT
from database.connection import Database
from database.models import BotRecord, User


class ProcessManagerRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def test_cookiefile_is_available_only_to_music_bot_templates(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            cookiefile = Path(temporary_directory) / "cookies.txt"
            cookiefile.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
            manager = object.__new__(ProcessManager)
            manager.youtube_cookies_file = cookiefile

            self.assertEqual(
                cookiefile, manager._youtube_cookiefile_for_template("music_bot")
            )
            self.assertIsNone(
                manager._youtube_cookiefile_for_template("uploaded_template")
            )

    async def test_configured_missing_cookiefile_fails_for_music_templates(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            manager = object.__new__(ProcessManager)
            manager.youtube_cookies_file = Path(temporary_directory) / "cookies.txt"

            with self.assertRaisesRegex(FileNotFoundError, "ملف كوكيز YouTube"):
                manager._youtube_cookiefile_for_template("music_bot")

    async def test_uses_factory_python_without_creating_a_virtual_environment(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            folder = Path(temporary_directory)
            manager = object.__new__(ProcessManager)
            with patch.object(
                ProcessManager,
                "_factory_runtime_satisfies_requirements",
                return_value=True,
            ):
                interpreter = await manager._prepare_environment(folder)

            self.assertEqual(Path(sys.executable), interpreter)
            self.assertFalse((folder / ".venv").exists())

    async def test_music_bot_preparation_bootstraps_youtube_runtime(self):
        manager = object.__new__(ProcessManager)
        manager._ensure_youtube_runtime = AsyncMock()
        with patch.object(
            ProcessManager,
            "_factory_runtime_satisfies_requirements",
            return_value=True,
        ):
            await manager._prepare_environment(Path("."), "music_bot")

        manager._ensure_youtube_runtime.assert_awaited_once_with()

    async def test_other_templates_do_not_bootstrap_youtube_runtime(self):
        manager = object.__new__(ProcessManager)
        manager._ensure_youtube_runtime = AsyncMock()
        with patch.object(
            ProcessManager,
            "_factory_runtime_satisfies_requirements",
            return_value=True,
        ):
            await manager._prepare_environment(Path("."), "uploaded_template")

        manager._ensure_youtube_runtime.assert_not_awaited()

    async def test_missing_youtube_runtime_triggers_pip_upgrade(self):
        manager = object.__new__(ProcessManager)
        manager._youtube_dependencies_lock = asyncio.Lock()
        process = AsyncMock()
        process.returncode = 0
        process.communicate.return_value = (b"installed", None)
        with (
            patch.object(
                ProcessManager,
                "_youtube_runtime_satisfies_requirements",
                side_effect=(False, True),
            ),
            patch(
                "core.process_manager.asyncio.create_subprocess_exec",
                new=AsyncMock(return_value=process),
            ) as install,
        ):
            await manager._ensure_youtube_runtime()

        install.assert_awaited_once_with(
            sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade",
            YOUTUBE_REQUIREMENT,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

    async def test_reports_missing_shared_runtime_dependencies(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            manager = object.__new__(ProcessManager)
            with patch.object(
                ProcessManager,
                "_factory_runtime_satisfies_requirements",
                return_value=False,
            ):
                with self.assertRaisesRegex(RuntimeError, "اعتماديات القالب"):
                    await manager._prepare_environment(Path(temporary_directory))

    async def test_restarts_only_enabled_running_bots_in_requested_tier(self):
        database = Database("sqlite+aiosqlite:///:memory:")
        await database.initialize()
        try:
            async with database.session() as session:
                session.add(User(telegram_id=101))
                await session.flush()
                running_free = BotRecord(
                    owner_id=101,
                    voice_account_id=1,
                    token_hash="free-running",
                    encrypted_token="",
                    encrypted_voice_session="",
                    username="free_running",
                    tier="free",
                    template_name="music_bot",
                    data_path="generated_bots_data/bot_free_running",
                    status="running",
                    enabled=True,
                )
                stopped_free = BotRecord(
                    owner_id=101,
                    voice_account_id=2,
                    token_hash="free-stopped",
                    encrypted_token="",
                    encrypted_voice_session="",
                    username="free_stopped",
                    tier="free",
                    template_name="music_bot",
                    data_path="generated_bots_data/bot_free_stopped",
                    status="stopped",
                    enabled=True,
                )
                running_paid = BotRecord(
                    owner_id=101,
                    voice_account_id=3,
                    token_hash="paid-running",
                    encrypted_token="",
                    encrypted_voice_session="",
                    username="paid_running",
                    tier="paid",
                    template_name="music_bot",
                    data_path="generated_bots_data/bot_paid_running",
                    status="running",
                    enabled=True,
                )
                session.add_all((running_free, stopped_free, running_paid))
                await session.commit()

            manager = object.__new__(ProcessManager)
            manager.database = database
            manager.restart_bot = AsyncMock(return_value=True)

            restarted, failed = await manager.restart_running_bots_for_tier("free")

            self.assertEqual([running_free.id], restarted)
            self.assertEqual([], failed)
            manager.restart_bot.assert_has_awaits([call(running_free.id)])
        finally:
            await database.close()


if __name__ == "__main__":
    unittest.main()
