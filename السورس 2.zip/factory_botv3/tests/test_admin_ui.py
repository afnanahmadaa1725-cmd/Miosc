import unittest
from types import SimpleNamespace

from admin_panel.keyboards import admin_dashboard_keyboard
from core.ui import edit_callback_panel, edit_tracked_panel


class AdminDashboardKeyboardTests(unittest.TestCase):
    def test_dashboard_groups_requested_actions_in_two_button_rows(self):
        rows = [
            [button.callback_data for button in row]
            for row in admin_dashboard_keyboard().inline_keyboard
        ]

        self.assertIn(["admin:stars_balance", "admin:subs"], rows)
        self.assertIn(["admin:broadcast", "admin:factory_broadcast"], rows)
        self.assertIn(["admin:all:stop", "admin:delete"], rows)
        self.assertIn(["admin:sessions", "admin:stats"], rows)
        self.assertNotIn("admin:upload", [button for row in rows for button in row])
        self.assertTrue(all(len(row) <= 2 for row in rows))


class TelegramBadRequest(Exception):
    __module__ = "telegram.error"


class FakeBot:
    def __init__(self):
        self.caption_edits = []
        self.sent_messages = []

    async def edit_message_caption(self, **kwargs):
        self.caption_edits.append(kwargs)

    async def send_message(self, **kwargs):
        message = SimpleNamespace(
            chat=SimpleNamespace(id=kwargs["chat_id"]),
            message_id=99,
            photo=None,
            animation=None,
        )
        self.sent_messages.append(kwargs)
        return message


class FakeMediaMessage:
    def __init__(self, bot):
        self.bot = bot
        self.chat = SimpleNamespace(id=22)
        self.message_id = 7
        self.photo = [object()]
        self.animation = None
        self.caption_edits = []

    async def edit_caption(self, **kwargs):
        self.caption_edits.append(kwargs)

    async def delete(self):
        raise AssertionError("The existing panel must not be deleted.")


class AdminPanelEditingTests(unittest.IsolatedAsyncioTestCase):
    async def test_callback_edits_media_caption_in_place(self):
        bot = FakeBot()
        message = FakeMediaMessage(bot)
        state = {}
        callback = SimpleNamespace(message=message, bot=bot)

        await edit_callback_panel(
            callback, "لوحة الإدارة", reply_markup=None, state=state
        )

        self.assertEqual(1, len(message.caption_edits))
        self.assertEqual([], bot.sent_messages)
        self.assertEqual(7, state["panel_message_id"])
        self.assertTrue(state["panel_media"])

    async def test_tracked_media_panel_is_edited_without_deleting_it(self):
        bot = FakeBot()
        message = SimpleNamespace(bot=bot)
        state = {
            "panel_chat_id": 22,
            "panel_message_id": 7,
            "panel_media": True,
        }

        await edit_tracked_panel(message, state, "تم التحديث.")

        self.assertEqual(
            [{"chat_id": 22, "message_id": 7, "caption": "تم التحديث.", "reply_markup": None}],
            bot.caption_edits,
        )
        self.assertEqual([], bot.sent_messages)

    async def test_long_media_caption_falls_back_without_removing_original(self):
        bot = FakeBot()
        message = FakeMediaMessage(bot)
        state = {}
        callback = SimpleNamespace(message=message, bot=bot)

        async def reject_long_caption(**kwargs):
            raise TelegramBadRequest("Caption is too long")

        message.edit_caption = reject_long_caption
        await edit_callback_panel(
            callback, "x" * 1100, reply_markup=None, state=state
        )

        self.assertEqual(1, len(bot.sent_messages))
        self.assertEqual(7, message.message_id)
        self.assertEqual(99, state["panel_message_id"])
        self.assertFalse(state["panel_media"])


if __name__ == "__main__":
    unittest.main()
