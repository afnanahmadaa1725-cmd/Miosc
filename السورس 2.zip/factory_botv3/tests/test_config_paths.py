import os
import unittest
from pathlib import Path
from unittest.mock import patch

from config import PROJECT_ROOT, _project_database_url, _project_path, load_settings
from core.fernet_compat import Fernet
from sqlalchemy.engine import make_url


class ProjectPathTests(unittest.TestCase):
    def test_project_paths_are_anchored_to_the_project_not_the_current_directory(self):
        with patch.dict(os.environ, {"TEST_DATA_DIR": "data\\bots"}):
            path = _project_path("TEST_DATA_DIR", "generated_bots_data")

        self.assertEqual(PROJECT_ROOT / "data" / "bots", path)
        self.assertTrue(path.is_relative_to(PROJECT_ROOT))

    def test_absolute_sqlite_config_is_normalized_to_a_project_relative_filename(self):
        url = _project_database_url("sqlite+aiosqlite:///C:/old/location/factory.sqlite3")
        database_path = Path(make_url(url).database)

        self.assertEqual(PROJECT_ROOT / "factory.sqlite3", database_path)
        self.assertTrue(database_path.is_relative_to(PROJECT_ROOT))

    def test_youtube_cookiefile_is_read_from_factory_environment_and_project_relative(self):
        environment = {
            "FACTORY_BOT_TOKEN": "bot-token",
            "FACTORY_ADMIN_IDS": "1",
            "FACTORY_FERNET_KEY": Fernet.generate_key().decode("ascii"),
            "TELEGRAM_API_ID": "1",
            "TELEGRAM_API_HASH": "api-hash",
            "FACTORY_YT_DLP_COOKIEFILE": "cookies.txt",
        }
        with patch.dict(os.environ, environment, clear=True):
            settings = load_settings()

        self.assertEqual(PROJECT_ROOT / "cookies.txt", settings.youtube_cookies_file)

    def test_youtube_cookiefile_is_optional(self):
        environment = {
            "FACTORY_BOT_TOKEN": "bot-token",
            "FACTORY_ADMIN_IDS": "1",
            "FACTORY_FERNET_KEY": Fernet.generate_key().decode("ascii"),
            "TELEGRAM_API_ID": "1",
            "TELEGRAM_API_HASH": "api-hash",
        }
        with patch.dict(os.environ, environment, clear=True):
            settings = load_settings()

        self.assertIsNone(settings.youtube_cookies_file)


if __name__ == "__main__":
    unittest.main()
