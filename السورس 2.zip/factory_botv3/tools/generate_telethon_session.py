"""إنشاء StringSession محلياً لإضافتها لاحقاً من لوحة إدارة المصنع."""

from __future__ import annotations

import asyncio
import getpass
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.sessions import StringSession

ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / ".env"


async def main() -> None:
    load_dotenv(ENV_PATH)
    api_id_text = os.environ.get("TELEGRAM_API_ID", "")
    api_hash = os.environ.get("TELEGRAM_API_HASH", "")
    if not api_id_text.isdigit() or not api_hash:
        raise RuntimeError("اضبط TELEGRAM_API_ID وTELEGRAM_API_HASH في .env أولاً.")

    phone = input("رقم الهاتف مع رمز الدولة: ").strip()
    client = TelegramClient(StringSession(), int(api_id_text), api_hash)
    await client.connect()
    try:
        sent = await client.send_code_request(phone)
        code = getpass.getpass("رمز الدخول (لن يظهر على الشاشة): ").strip()
        try:
            await client.sign_in(phone=phone, code=code, phone_code_hash=sent.phone_code_hash)
        except SessionPasswordNeededError:
            password = getpass.getpass("كلمة مرور التحقق بخطوتين: ")
            await client.sign_in(password=password)
        if not await client.is_user_authorized():
            raise RuntimeError("لم يتم تأكيد تسجيل الدخول.")
        session_string = client.session.save()
        print(
            "\nأضف الجلسة من لوحة الإدارة في محادثة خاصة مع بوت المصنع. "
            "لا تحفظها في ملف أو تشاركها."
        )
        print(session_string)
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
