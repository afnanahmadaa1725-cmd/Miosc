"""نقطة تشغيل بوت المصنع الرئيسي."""

from __future__ import annotations

import asyncio
import hashlib
import html
import logging
import re
import uuid
from pathlib import Path

from telegram import (
    CallbackQuery,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)
from telegram.ext import Application
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from admin_panel.admin_handlers import create_router as create_admin_router
from admin_panel.keyboards import (
    admin_back_keyboard,
    make_keyboard,
    payment_detail_keyboard,
    payment_back_keyboard,
    payment_menu_keyboard,
    section_keyboard,
    start_keyboard,
    StyledInlineKeyboardButton as InlineKeyboardButton,
    template_keyboard,
)
from config import PROJECT_ROOT, Settings, load_settings
from core.fernet_compat import Fernet
from core.process_manager import ProcessManager
from core.ptb_compat import (
    Bot,
    Command,
    CommandStart,
    Dispatcher,
    FSInputFile,
    F,
    FSMContext,
    Router,
    State,
    StatesGroup,
    TelegramAPIError,
    TelegramUnauthorizedError,
)
from core.subscription_worker import run_subscription_check_worker
from core.template_loader import TemplateLoader
from core.ui import edit_callback_panel, edit_tracked_panel, remember_panel
from database.connection import Database
from database.models import (
    BotRecord,
    BroadcastConsent,
    FactoryAdmin,
    FactoryBotManager,
    PaidGrant,
    PaymentMethod,
    PaymentRequest,
    StarPayment,
    User,
    utc_now,
)

TOKEN_PATTERN = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{20,}$")
TOKEN_VALIDATION_TIMEOUT_SECONDS = 5
logger = logging.getLogger(__name__)


async def _verify_bot_token(token: str):
    candidate = Bot(token=token)

    async def verify():
        await candidate.initialize()
        return await candidate.get_me()

    try:
        return await asyncio.wait_for(
            verify(), timeout=TOKEN_VALIDATION_TIMEOUT_SECONDS
        )
    finally:
        await candidate.shutdown()


class CreateBot(StatesGroup):
    token = State()


class PaymentFlow(StatesGroup):
    asiacell_amount = State()
    receipt = State()


_creation_expiry_tasks: dict[int, asyncio.Task[None]] = {}
FACTORY_PANEL_ASSETS = Path(__file__).resolve().parent / "assets" / "factory_panel"


def register_handlers(
    dispatcher: Dispatcher,
    database: Database,
    loader: TemplateLoader,
    manager: ProcessManager,
    settings: Settings,
) -> None:
    router = Router(name="factory")

    async def ensure_user(user_id: int) -> None:
        async with database.session() as session:
            user = await session.scalar(select(User).where(User.telegram_id == user_id))
            if user is None:
                session.add(User(telegram_id=user_id))
                await session.commit()

    async def expire_creation(
        state: FSMContext, chat_id: int, user_id: int, flow_id: str, bot: Bot
    ) -> None:
        try:
            await asyncio.sleep(180)
            data = await state.get_data()
            if data.get("flow_id") == flow_id and await state.get_state() == CreateBot.token.state:
                await state.clear()
                try:
                    await bot.send_message(
                        chat_id,
                        "انتهت مهلة انتظار التوكن (3 دقائق). ابدأ من جديد عبر «اصنع بوتك».",
                    )
                except TelegramAPIError:
                    logger.exception(
                        "تعذر إرسال إشعار انتهاء مهلة الإنشاء إلى المستخدم %s",
                        user_id,
                    )
        except asyncio.CancelledError:
            raise
        finally:
            task = _creation_expiry_tasks.get(user_id)
            if task is asyncio.current_task():
                _creation_expiry_tasks.pop(user_id, None)

    def schedule_creation_expiry(
        state: FSMContext, chat_id: int, user_id: int, flow_id: str, bot: Bot
    ) -> None:
        old_task = _creation_expiry_tasks.pop(user_id, None)
        if old_task:
            old_task.cancel()
        _creation_expiry_tasks[user_id] = asyncio.create_task(
            expire_creation(state, chat_id, user_id, flow_id, bot)
        )

    def cancel_creation_expiry(user_id: int) -> None:
        task = _creation_expiry_tasks.pop(user_id, None)
        if task:
            task.cancel()

    def home_panel_text(user_name: str) -> str:
        return (
            f"◉ أهلاً بك {html.escape(user_name or 'صديقنا')} في بوت صانع بوتات ميوزك\n\n"
            "◉ بوتات حماية وميوزك وتشغيل أغاني بالمكالمات بنظام تحكم سلس ومتكامل\n\n"
            "◉ يمكنك صناعة بوتك الخاص من أحد الأزرار بالأسفل\n"
            "<blockquote>touch me, touch the world</blockquote>"
        )

    def home_panel_keyboard(user_id: int) -> InlineKeyboardMarkup:
        return start_keyboard(
            is_admin=settings.is_admin(user_id),
            developer_channel=settings.developer_channel,
            factory_updates_channel=settings.factory_updates_channel,
        )

    async def send_home_panel(
        bot: Bot,
        chat_id: int,
        user_id: int,
        user_name: str,
        state: FSMContext,
    ) -> Message:
        text = home_panel_text(user_name)
        keyboard = home_panel_keyboard(user_id)
        photo = FACTORY_PANEL_ASSETS / "factory_panel.jpg"
        animation_gif = FACTORY_PANEL_ASSETS / "factory_panel.gif"
        animation_mp4 = FACTORY_PANEL_ASSETS / "factory_panel.mp4"
        if photo.is_file():
            panel = await bot.send_photo(
                chat_id,
                FSInputFile(photo),
                caption=text,
                reply_markup=keyboard,
                parse_mode="HTML",
            )
        elif animation_gif.is_file() or animation_mp4.is_file():
            animation = animation_gif if animation_gif.is_file() else animation_mp4
            panel = await bot.send_animation(
                chat_id,
                FSInputFile(animation),
                caption=text,
                reply_markup=keyboard,
                parse_mode="HTML",
            )
        else:
            panel = await bot.send_message(
                chat_id,
                text,
                reply_markup=keyboard,
                parse_mode="HTML",
            )
        await remember_panel(state, panel)
        return panel

    @router.message(CommandStart())
    async def start(message: Message, state: FSMContext) -> None:
        await state.clear()
        cancel_creation_expiry(message.from_user.id)
        await ensure_user(message.from_user.id)
        await send_home_panel(
            message.bot,
            message.chat.id,
            message.from_user.id,
            message.from_user.full_name or "صديقنا",
            state,
        )

    @router.message(F.text.regexp(r"^/?صورة(?:@[A-Za-z0-9_]+)?$"))
    async def set_factory_panel_image(message: Message) -> None:
        if not message.from_user or not settings.is_admin(message.from_user.id):
            return
        source = message.reply_to_message
        if source is None:
            await message.answer("استخدم «صورة» بالرد على صورة أو GIF متحرك.")
            return
        is_animation = source.animation is not None
        if source.animation:
            media = source.animation
        elif source.photo:
            media = source.photo[-1]
        elif source.document and source.document.mime_type == "image/gif":
            media = source.document
            is_animation = True
        else:
            await message.answer("الرد يجب أن يكون على صورة أو GIF متحرك.")
            return
        if media.file_size and media.file_size > 50 * 1024 * 1024:
            await message.answer("حجم الملف يتجاوز الحد المسموح (50 ميجابايت).")
            return
        try:
            telegram_file = await message.bot.get_file(media.file_id)
            if not telegram_file.file_path:
                raise RuntimeError("لم يُرجع تيليجرام مسار الملف.")
            if is_animation:
                extension = Path(telegram_file.file_path).suffix.lower()
                if extension not in {".gif", ".mp4"}:
                    extension = ".gif" if source.document else ".mp4"
                filename = f"factory_panel{extension}"
            else:
                filename = "factory_panel.jpg"
            FACTORY_PANEL_ASSETS.mkdir(parents=True, exist_ok=True)
            destination = FACTORY_PANEL_ASSETS / filename
            temporary = FACTORY_PANEL_ASSETS / f".upload-{uuid.uuid4().hex}{Path(filename).suffix}"
            try:
                await telegram_file.download_to_drive(custom_path=temporary)
                if not temporary.is_file() or temporary.stat().st_size == 0:
                    raise RuntimeError("الملف المُنزّل فارغ.")
                temporary.replace(destination)
            finally:
                temporary.unlink(missing_ok=True)
            for old_name in ("factory_panel.jpg", "factory_panel.gif", "factory_panel.mp4"):
                old_path = FACTORY_PANEL_ASSETS / old_name
                if old_path != destination:
                    old_path.unlink(missing_ok=True)
        except (OSError, RuntimeError, TelegramAPIError):
            logger.exception("تعذر حفظ صورة لوحة الصانع من رسالة الإدارة")
            await message.answer("تعذر حفظ الصورة أو GIF؛ حاول مرة أخرى.")
            return
        await message.answer("تم حفظ الوسائط وتحديث صورة لوحة الصانع الرئيسية.")

    @router.message(Command("broadcast_optin"))
    async def broadcast_opt_in(message: Message) -> None:
        await ensure_user(message.from_user.id)
        async with database.session() as session:
            consent = await session.scalar(
                select(BroadcastConsent).where(
                    BroadcastConsent.user_id == message.from_user.id
                )
            )
            if consent is None:
                session.add(
                    BroadcastConsent(user_id=message.from_user.id, opted_in=True)
                )
            else:
                consent.opted_in = True
                consent.updated_at = utc_now()
            await session.commit()
        await message.answer("تم تفعيل رسائل الإدارة الاختيارية. للإلغاء استخدم /broadcast_optout.")

    @router.message(Command("broadcast_optout"))
    async def broadcast_opt_out(message: Message) -> None:
        async with database.session() as session:
            consent = await session.scalar(
                select(BroadcastConsent).where(
                    BroadcastConsent.user_id == message.from_user.id
                )
            )
            if consent:
                consent.opted_in = False
                consent.updated_at = utc_now()
                await session.commit()
        await message.answer("تم إلغاء موافقتك على الرسائل الإذاعية.")

    @router.callback_query(F.data == "nav:home")
    async def back_home(callback: CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        cancel_creation_expiry(callback.from_user.id)
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                home_panel_text(callback.from_user.full_name or "صديقنا"),
                reply_markup=home_panel_keyboard(callback.from_user.id),
                parse_mode="HTML",
                state=state,
            )

    @router.callback_query(F.data == "factory:make")
    async def open_make_menu(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                "◈ من هنا يمكنك اختيار نوع قالب البوت لصناعته\n"
                "◈ اختر أحد الأقسام لصناعة بوتك",
                reply_markup=make_keyboard(),
                state=state,
            )

    @router.callback_query(F.data == "nav:make")
    async def back_to_make_menu(callback: CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        cancel_creation_expiry(callback.from_user.id)
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                "◈ من هنا يمكنك اختيار نوع قالب البوت لصناعته\n"
                "◈ اختر أحد الأقسام لصناعة بوتك",
                reply_markup=make_keyboard(),
                state=state,
            )

    @router.callback_query(F.data.startswith("create:"))
    async def select_tier(callback: CallbackQuery, state: FSMContext) -> None:
        tier = (callback.data or "").split(":", maxsplit=1)[1]
        if tier not in ("free", "paid"):
            await callback.answer("اختيار غير صالح.", show_alert=True)
            return
        await ensure_user(callback.from_user.id)
        if tier == "paid":
            async with database.session() as session:
                grant = await session.scalar(
                    select(PaidGrant).where(PaidGrant.user_id == callback.from_user.id)
                )
            if grant is None:
                await callback.answer()
                if callback.message:
                    await edit_callback_panel(
                        callback,
                        "▣ من هنا يمكنك صنع بوت ميوزك مدفوع\n"
                        "▣ بوتات القسم المدفوع مستقلة عن قنوات الاشتراك الإجباري "
                        "وإذاعات الإدارة\n"
                        "▣ تحكم كامل ومستقر لبوتك.\n"
                        "▣ قم بإكمال الاشتراك ثم اختر قالباً لصناعة البوت.",
                        reply_markup=section_keyboard(include_payment=True),
                        state=state,
                    )
                return
        available = loader.list_templates(tier)
        if not available:
            await callback.answer("لا يوجد قالب متاح حالياً.", show_alert=True)
            return
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                (
                    "▣ من هنا يمكنك صنع بوت ميوزك مجاني بسهولة\n"
                    "▣ يحتوي بوت القسم المجاني على قنوات الاشتراك الإجباري "
                    "وإذاعات إدارة المصنع\n"
                    "▣ تحكم كامل ومستقر لبوتك.\n"
                    "▣ قم بإرسال توكن البوت من @Botfather لصناعة البوت."
                    if tier == "free"
                    else
                    "▣ من هنا يمكنك صنع بوت ميوزك مدفوع\n"
                    "▣ بوت القسم المدفوع خالٍ من قنوات الاشتراك الإجباري "
                    "وإذاعات الإدارة\n"
                    "▣ تحكم كامل ومستقر لبوتك.\n"
                    "▣ قم بإرسال توكن البوت من @Botfather لصناعة البوت."
                ),
                reply_markup=template_keyboard(available),
                state=state,
            )

    @router.callback_query(F.data == "payment:menu")
    async def open_payment_menu(
        callback: CallbackQuery, state: FSMContext
    ) -> None:
        await state.clear()
        async with database.session() as session:
            methods = (
                await session.execute(
                    select(PaymentMethod).where(
                        PaymentMethod.enabled.is_(True),
                        PaymentMethod.kind.in_(
                            ("visa", "binance", "stars", "asiacell", "agent")
                        ),
                    )
                )
            ).scalars().all()
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                "• لتفعيل اشتراكك بالصانع اختر إحدى طرق الدفع ثم توجّه إلى تأكيد العملية ⚉",
                reply_markup=payment_menu_keyboard(methods),
                state=state,
            )

    @router.callback_query(F.data.startswith("paykind:"))
    async def show_payment_details(
        callback: CallbackQuery, state: FSMContext
    ) -> None:
        kind = (callback.data or "").partition(":")[2]
        if kind not in {"visa", "binance", "stars", "asiacell", "agent"}:
            await callback.answer("طريقة الدفع غير صالحة.", show_alert=True)
            return
        async with database.session() as session:
            method = await session.scalar(
                select(PaymentMethod).where(
                    PaymentMethod.kind == kind, PaymentMethod.enabled.is_(True)
                ).order_by(PaymentMethod.id.desc()).limit(1)
            )
        if method is None:
            await callback.answer("لم تُضف تفاصيل طريقة الدفع بعد.", show_alert=True)
            return
        if kind == "agent" and method.payload.startswith("https://"):
            await callback.answer("استخدم رابط الوكيل لإكمال الدفع.")
            return
        details = method.payload or "لا توجد تفاصيل إضافية."
        if kind == "stars":
            details = (
                f"قيمة الاشتراك: {method.stars_amount} نجمة.\n{details}".strip()
            )
        elif kind == "asiacell":
            details = (
                "• لتفعيل اشتراكك حوّل المبلغ إلى رقم آسياسيل الموضح أدناه.\n"
                "• الحد الأدنى 1000 دينار، دون كسور.\n\n"
                f"{details}"
            )
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                details,
                reply_markup=payment_detail_keyboard(kind),
                state=state,
            )

    @router.callback_query(F.data == "payamount:asiacell")
    async def request_asiacell_amount(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await state.set_state(PaymentFlow.asiacell_amount)
        if callback.message:
            await edit_callback_panel(
                callback,
                "• اكتب المبلغ المراد شحنه، الحد الأدنى 1000 دينار وبدون كسور:",
                reply_markup=payment_back_keyboard(),
                state=state,
            )

    @router.message(PaymentFlow.asiacell_amount)
    async def receive_asiacell_amount(message: Message, state: FSMContext) -> None:
        value = (message.text or "").strip()
        if value == "/cancel":
            await edit_tracked_panel(message, state, "تم إلغاء طلب الدفع.")
            await state.clear()
            return
        if not value.isascii() or not value.isdigit() or int(value) < 1000:
            await edit_tracked_panel(
                message,
                state,
                "ـ خطأ، القيمة المدخلة غير صحيحة. أعد المحاولة ⚠️",
                payment_back_keyboard(),
            )
            return
        await state.update_data(
            payment_kind="asiacell", payment_amount=int(value)
        )
        async with database.session() as session:
            method = await session.scalar(
                select(PaymentMethod).where(
                    PaymentMethod.kind == "asiacell",
                    PaymentMethod.enabled.is_(True),
                ).order_by(PaymentMethod.id.desc()).limit(1)
            )
        details = method.payload if method else ""
        await edit_tracked_panel(
            message,
            state,
            f"• تم استلام المبلغ: {int(value)} دينار.\n"
            f"حوّل المبلغ إلى الرقم المسجل ثم اضغط تأكيد الدفع.\n{details}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🟢 تأكيد الدفع ✓",
                            callback_data="payconfirm:asiacell",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="🔴 رجوع ◄", callback_data="payment:menu"
                        )
                    ],
                ]
            ),
        )

    @router.callback_query(F.data.startswith("payconfirm:"))
    async def confirm_payment_method(
        callback: CallbackQuery, state: FSMContext
    ) -> None:
        kind = (callback.data or "").partition(":")[2]
        if kind == "stars":
            async with database.session() as session:
                method = await session.scalar(
                    select(PaymentMethod).where(
                        PaymentMethod.kind == "stars",
                        PaymentMethod.enabled.is_(True),
                    ).order_by(PaymentMethod.id.desc()).limit(1)
                )
            if method is None or not method.stars_amount:
                await callback.answer("دفع النجوم غير مهيأ حالياً.", show_alert=True)
                return
            await callback.answer()
            await callback.bot.send_invoice(
                chat_id=callback.from_user.id,
                title=method.title[:32],
                description="تفعيل الوصول إلى القوالب المدفوعة.",
                payload=f"paid:{method.id}:{callback.from_user.id}",
                provider_token="",
                currency="XTR",
                prices=[
                    LabeledPrice(
                        label=method.title[:32], amount=method.stars_amount
                    )
                ],
            )
            return
        if kind not in {"visa", "binance", "asiacell"}:
            await callback.answer("طريقة الدفع غير مدعومة.", show_alert=True)
            return
        current_data = await state.get_data()
        amount = (
            current_data.get("payment_amount")
            if kind == "asiacell"
            and current_data.get("payment_kind") == "asiacell"
            else None
        )
        await state.set_state(PaymentFlow.receipt)
        await state.update_data(payment_kind=kind, payment_amount=amount)
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                "• يرجى إرسال صورة وصل الدفع لتحويلها إلى الإدارة للتأكيد."
                + (
                    f"\n• المبلغ: {amount} دينار."
                    if kind == "asiacell" and amount
                    else ""
                ),
                reply_markup=payment_back_keyboard(),
                state=state,
            )

    @router.message(PaymentFlow.receipt, F.photo)
    async def receive_payment_receipt(message: Message, state: FSMContext, bot: Bot) -> None:
        if not message.from_user:
            return
        data = await state.get_data()
        kind = data.get("payment_kind")
        if kind not in {"visa", "binance", "asiacell"}:
            await edit_tracked_panel(message, state, "انتهت جلسة الدفع؛ ابدأ من جديد.")
            await state.clear()
            return
        async with database.session() as session:
            pending = await session.scalar(
                select(PaymentRequest.id).where(
                    PaymentRequest.user_id == message.from_user.id,
                    PaymentRequest.status == "pending",
                )
            )
            if pending:
                await edit_tracked_panel(
                    message, state, "لديك طلب دفع قيد المراجعة بالفعل."
                )
                await state.clear()
                return
            request = PaymentRequest(
                user_id=message.from_user.id,
                method_kind=kind,
                amount=data.get("payment_amount"),
                receipt_file_id=message.photo[-1].file_id,
                status="pending",
            )
            session.add(request)
            await session.flush()
            request_id = request.id
            created_at = request.created_at
            await session.commit()
        user = message.from_user
        username = f"@{user.username}" if user.username else "غير محدد"
        caption = (
            f"طلب دفع #{request_id}\n"
            f"• اسم الحساب: {user.full_name}\n"
            f"• اسم المستخدم: {username}\n"
            f"• ايدي المستخدم: {user.id}\n"
            f"• تاريخ العملية: {created_at:%Y-%m-%d %H:%M UTC}\n"
            f"• الطريقة: {kind}\n"
            + (
                f"• المبلغ: {data['payment_amount']} دينار"
                if data.get("payment_amount")
                else ""
            )
        )
        review_keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🟢 تأكيد ✓",
                        callback_data=f"review:approve:{request_id}",
                    ),
                    InlineKeyboardButton(
                        text="🔴 رفض ✘",
                        callback_data=f"review:reject:{request_id}",
                    ),
                ]
            ]
        )
        delivery_errors = []
        for admin_id in settings.all_admin_ids:
            try:
                await bot.send_photo(
                    chat_id=admin_id,
                    photo=message.photo[-1].file_id,
                    caption=caption,
                    reply_markup=review_keyboard,
                )
            except TelegramAPIError as error:
                logger.exception("تعذر إرسال طلب الدفع %s للإدارة", request_id)
                delivery_errors.append(str(error))
        await edit_tracked_panel(
            message,
            state,
            "تم استلام وصل الدفع وإرساله إلى الإدارة للمراجعة."
            if not delivery_errors
            else "تم استلام الوصل، لكن تعذر إشعار بعض المشرفين. تواصل مع الإدارة."
        )
        await state.clear()

    @router.message(PaymentFlow.receipt)
    async def require_receipt_photo(message: Message, state: FSMContext) -> None:
        if (message.text or "").strip() == "/cancel":
            await edit_tracked_panel(message, state, "تم إلغاء طلب الدفع.")
            await state.clear()
            return
        await edit_tracked_panel(
            message,
            state,
            "أرسل صورة واضحة لوصل الدفع لإكمال الطلب.",
            payment_back_keyboard(),
        )

    @router.callback_query(F.data.startswith("template:"))
    async def select_template(callback: CallbackQuery, state: FSMContext) -> None:
        parts = (callback.data or "").split(":", maxsplit=2)
        if len(parts) != 3 or parts[1] not in ("free", "paid"):
            await callback.answer("اختيار قالب غير صالح.", show_alert=True)
            return
        tier, template_name = parts[1], parts[2]
        if tier == "paid":
            async with database.session() as session:
                grant = await session.scalar(
                    select(PaidGrant).where(PaidGrant.user_id == callback.from_user.id)
                )
            if grant is None:
                await callback.answer("أكمل الدفع للقسم المدفوع أولاً.", show_alert=True)
                return
        try:
            template = loader.get(tier, template_name)
        except FileNotFoundError:
            await callback.answer("لم يعد هذا القالب متاحاً.", show_alert=True)
            return
        await state.set_state(CreateBot.token)
        flow_id = uuid.uuid4().hex
        await state.update_data(
            tier=tier, template_name=template.name, flow_id=flow_id
        )
        await callback.answer()
        if callback.message:
            await edit_callback_panel(
                callback,
                "أرسل توكن البوت من @Botfather لصناعة البوت. "
                "سيُحذف التوكن من المحادثة بعد استلامه. لديك 3 دقائق.",
                reply_markup=section_keyboard(),
                state=state,
            )
            schedule_creation_expiry(
                state,
                callback.message.chat.id,
                callback.from_user.id,
                flow_id,
                callback.bot,
            )

    @router.callback_query(F.data.startswith("pay:"))
    async def start_payment(callback: CallbackQuery) -> None:
        value = (callback.data or "").partition(":")[2]
        if not value.isdigit():
            await callback.answer("اختيار الدفع غير صالح.", show_alert=True)
            return
        async with database.session() as session:
            method = await session.get(PaymentMethod, int(value))
            grant = await session.scalar(
                select(PaidGrant).where(PaidGrant.user_id == callback.from_user.id)
            )
        if grant:
            await callback.answer("القسم المدفوع مفعّل بالفعل.")
            return
        if method is None or not method.enabled:
            await callback.answer("وسيلة الدفع غير متاحة.", show_alert=True)
            return
        if method.kind != "stars" or not method.stars_amount:
            await callback.answer(
                "أكمل الدفع عبر الرابط ثم تواصل مع الإدارة لتأكيده.",
                show_alert=True,
            )
            return
        await callback.answer()
        await callback.bot.send_invoice(
            chat_id=callback.from_user.id,
            title=method.title[:32],
            description="تفعيل الوصول إلى قوالب البوتات المدفوعة.",
            payload=f"paid:{method.id}:{callback.from_user.id}",
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice(label=method.title[:32], amount=method.stars_amount)],
        )

    @router.pre_checkout_query()
    async def approve_star_payment(query: PreCheckoutQuery) -> None:
        payload = query.invoice_payload.split(":")
        valid = (
            len(payload) == 3
            and payload[0] == "paid"
            and payload[2].isdigit()
            and int(payload[2]) == query.from_user.id
            and query.currency == "XTR"
        )
        if valid and payload[1].isdigit():
            async with database.session() as session:
                method = await session.get(PaymentMethod, int(payload[1]))
                valid = bool(
                    method
                    and method.enabled
                    and method.kind == "stars"
                    and method.stars_amount == query.total_amount
                )
        await query.answer(
            ok=valid,
            error_message=None if valid else "وسيلة الدفع أو المبلغ غير صالح.",
        )

    @router.message(F.successful_payment)
    async def confirm_star_payment(message: Message, state: FSMContext) -> None:
        payment = message.successful_payment
        if payment is None or not message.from_user:
            return
        payload = payment.invoice_payload.split(":")
        if len(payload) != 3 or payload[0] != "paid" or not payload[2].isdigit():
            await message.answer("تعذر مطابقة إيصال الدفع.")
            return
        if int(payload[2]) != message.from_user.id or payment.currency != "XTR":
            await message.answer("بيانات إيصال الدفع غير مطابقة.")
            return
        async with database.session() as session:
            method = await session.get(PaymentMethod, int(payload[1])) if payload[1].isdigit() else None
            if (
                method is None
                or method.kind != "stars"
                or method.stars_amount != payment.total_amount
            ):
                await message.answer("لم يتم تأكيد مبلغ عملية الدفع.")
                return
            recorded_payment = await session.scalar(
                select(StarPayment.id).where(
                    StarPayment.telegram_charge_id
                    == payment.telegram_payment_charge_id
                )
            )
            if recorded_payment is None:
                session.add(
                    StarPayment(
                        telegram_charge_id=payment.telegram_payment_charge_id,
                        user_id=message.from_user.id,
                        amount=payment.total_amount,
                        currency=payment.currency,
                        invoice_payload=payment.invoice_payload,
                    )
                )
            grant = await session.scalar(
                select(PaidGrant).where(PaidGrant.user_id == message.from_user.id)
            )
            if grant is None:
                session.add(PaidGrant(user_id=message.from_user.id))
            await session.commit()
        await edit_tracked_panel(
            message,
            state,
            "• تم تأكيد الدفع وتفعيل القسم المدفوع بنجاح.",
            InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🟢 متابعة للقوالب المدفوعة",
                            callback_data="create:paid",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="🔴 رجوع ◄", callback_data="nav:make"
                        )
                    ],
                ]
            ),
        )

    @router.message(Command("cancel"))
    async def cancel_creation(message: Message, state: FSMContext) -> None:
        current_state = await state.get_state()
        keyboard = (
            admin_back_keyboard()
            if current_state and current_state.startswith("AdminState:")
            else section_keyboard()
        )
        await edit_tracked_panel(
            message, state, "تم إلغاء العملية.", keyboard
        )
        await state.clear()
        if message.from_user:
            cancel_creation_expiry(message.from_user.id)

    @router.message(CreateBot.token)
    async def receive_bot_token(message: Message, state: FSMContext) -> None:
        token = (message.text or "").strip()
        if not token:
            await edit_tracked_panel(
                message,
                state,
                "أرسل التوكن كنص أو ألغِ العملية عبر /cancel.",
                section_keyboard(),
            )
            return
        try:
            await message.delete()
        except TelegramAPIError:
            await edit_tracked_panel(
                message,
                state,
                "تعذر حذف التوكن من المحادثة، لذلك أُلغيت العملية ولم يُحفظ. "
                "تحقق من صلاحية الحذف ثم أعد المحاولة.",
            )
            await state.clear()
            return
        if not TOKEN_PATTERN.fullmatch(token):
            await edit_tracked_panel(
                message,
                state,
                "◐ فشل التحقق من التوكن أو حدث خطأ ✘، تأكد من صحته من @Botfather "
                "أو أعد إصداره ثم أرسله خلال مهلة الانتظار.",
                section_keyboard(),
            )
            return
        cancel_creation_expiry(message.from_user.id)
        digest = hashlib.sha256(token.encode()).hexdigest()
        async with database.session() as session:
            exists = await session.scalar(
                select(BotRecord.id).where(BotRecord.token_hash == digest)
            )
        if exists:
            await edit_tracked_panel(message, state, "هذا التوكن مستخدم مسبقاً.")
            await state.clear()
            return
        await edit_tracked_panel(
            message,
            state,
            "❀ جارِ التحقق من التوكن المدخل، يرجى الانتظار .. ♫",
            section_keyboard(),
        )
        data = await state.get_data()
        tier = data.get("tier")
        template_name = data.get("template_name")
        if tier not in ("free", "paid") or not template_name:
            await edit_tracked_panel(
                message, state, "انتهت جلسة الإنشاء؛ ابدأ من /start."
            )
            await state.clear()
            return
        try:
            bot_identity = await _verify_bot_token(token)
        except TelegramUnauthorizedError:
            await edit_tracked_panel(
                message,
                state,
                "◐ فشل التحقق من التوكن أو حدث خطأ ✘، تأكد من صحة التوكن من "
                "@Botfather أو قم بإعادة إصداره ثم أعد إرساله.",
                section_keyboard(),
            )
            flow_id = (await state.get_data()).get("flow_id")
            if flow_id:
                schedule_creation_expiry(
                    state,
                    message.chat.id,
                    message.from_user.id,
                    flow_id,
                    message.bot,
                )
            return
        except asyncio.TimeoutError:
            await edit_tracked_panel(
                message,
                state,
                "استغرق اتصال التحقق أكثر من 5 ثوانٍ؛ أعد المحاولة بعد التأكد من اتصال الخادم.",
                section_keyboard(),
            )
            flow_id = (await state.get_data()).get("flow_id")
            if flow_id:
                schedule_creation_expiry(
                    state,
                    message.chat.id,
                    message.from_user.id,
                    flow_id,
                    message.bot,
                )
            return
        except TelegramAPIError:
            await edit_tracked_panel(
                message,
                state,
                "تعذر الاتصال بواجهة تيليجرام للتحقق من التوكن؛ حاول لاحقاً.",
                section_keyboard(),
            )
            flow_id = (await state.get_data()).get("flow_id")
            if flow_id:
                schedule_creation_expiry(
                    state,
                    message.chat.id,
                    message.from_user.id,
                    flow_id,
                    message.bot,
                )
            return
        await edit_tracked_panel(
            message,
            state,
            "◍ تم التحقق من التوكن ✓، جارِ إعداد البوت ... يرجى الانتظار.",
            section_keyboard(),
        )
        cipher = Fernet(settings.fernet_key.encode())
        encrypted = cipher.encrypt(token.encode()).decode()
        template = loader.get(tier, template_name)
        user_id = message.from_user.id
        await edit_tracked_panel(
            message,
            state,
            "جارٍ تجهيز بيئة المشروع وتشغيل البوت؛ قد يستغرق ذلك عدة دقائق.",
            section_keyboard(),
        )
        bot_id: int | None = None
        voice_session = ""
        try:
            async with database.session() as session:
                record = BotRecord(
                    owner_id=user_id,
                    voice_account_id=bot_identity.id,
                    token_hash=digest,
                    encrypted_token=encrypted,
                    encrypted_voice_session="",
                    username=bot_identity.username or str(bot_identity.id),
                    tier=tier,
                    template_name=template_name,
                    data_path=(settings.data_dir / f"bot_{digest}")
                    .relative_to(PROJECT_ROOT)
                    .as_posix(),
                    status="starting",
                    enabled=True,
                )
                session.add(record)
                await session.flush()
                bot_id = record.id
                await session.commit()
            async with database.session() as session:
                record = await session.get(BotRecord, bot_id)
                if record is None:
                    raise RuntimeError("تعذر العثور على سجل البوت بعد إنشائه.")
                await manager.create_and_start(record, template, token, voice_session)
        except IntegrityError:
            await edit_tracked_panel(message, state, "هذا التوكن مسجل مسبقاً.")
            await state.clear()
            return
        except Exception as error:
            logger.exception(
                "تعذر إنشاء البوت للمستخدم %s باستخدام القالب %s:%s",
                user_id,
                tier,
                template_name,
            )
            if bot_id is not None:
                try:
                    async with database.session() as session:
                        record = await session.get(BotRecord, bot_id)
                        if record:
                            record.status = "error"
                            record.pid = None
                            record.enabled = False
                            await session.commit()
                except Exception:
                    logger.exception(
                        "تعذر تحديث حالة البوت %s بعد فشل الإنشاء", bot_id
                    )
            error_message = str(error).strip() or "خطأ غير معروف."
            await edit_tracked_panel(
                message,
                state,
                "تعذر تجهيز البوت وتشغيله.\n"
                f"التفاصيل: {error_message[:1500]}\n"
                "يمكن للإدارة مراجعة سجل الأخطاء والمحاولة مجدداً.",
                section_keyboard(),
            )
            await state.clear()
            return
        await edit_tracked_panel(
            message,
            state,
            f"◐ تم إعداد وتشغيل البوت @{bot_identity.username or bot_identity.id} ✓.",
            section_keyboard(),
        )
        await state.clear()

    dispatcher.include_router(router)
    dispatcher.include_router(create_admin_router(database, loader, settings, manager))


async def run() -> None:
    settings = load_settings()
    Path(settings.logs_dir).mkdir(parents=True, exist_ok=True)
    database = Database(settings.database_url)
    await database.initialize()
    async with database.session() as session:
        managed_admin_ids = (
            await session.execute(select(FactoryAdmin.user_id))
        ).scalars().all()
        managed_bot_admin_ids = (
            await session.execute(select(FactoryBotManager.user_id))
        ).scalars().all()
    settings.managed_admin_ids.update(managed_admin_ids)
    settings.managed_bot_admin_ids.update(managed_bot_admin_ids)
    loader = TemplateLoader(settings.templates_dir)
    manager = ProcessManager(
        database=database,
        loader=loader,
        data_dir=settings.data_dir,
        logs_dir=settings.logs_dir,
        youtube_cookies_file=settings.youtube_cookies_file,
        fernet_key=settings.fernet_key,
        telegram_api_id=settings.telegram_api_id,
        telegram_api_hash=settings.telegram_api_hash,
        database_url=settings.database_url,
    )
    bot = Bot(settings.bot_token)
    application = Application.builder().bot(bot).build()
    dispatcher = Dispatcher(application)
    subscription_worker: asyncio.Task[None] | None = None
    application_initialized = False
    application_started = False
    polling_started = False
    try:
        await manager.start_all()
        register_handlers(dispatcher, database, loader, manager, settings)
        try:
            await application.initialize()
        except TelegramUnauthorizedError:
            raise RuntimeError(
                "Telegram rejected FACTORY_BOT_TOKEN. Replace it in the local "
                ".env file and restart the factory."
            ) from None
        application_initialized = True
        await application.start()
        application_started = True
        if application.updater is None:
            raise RuntimeError("PTB Application was created without an Updater.")
        await application.updater.start_polling()
        polling_started = True
        subscription_worker = asyncio.create_task(
            run_subscription_check_worker(database, bot),
            name="factory-subscription-checks",
        )
        await asyncio.Event().wait()
    finally:
        if subscription_worker:
            subscription_worker.cancel()
            try:
                await subscription_worker
            except asyncio.CancelledError:
                pass
        if polling_started and application.updater is not None:
            await application.updater.stop()
        if application_started:
            await application.stop()
        await manager.stop_all()
        if application_initialized:
            await application.shutdown()
        await database.close()


if __name__ == "__main__":
    asyncio.run(run())
