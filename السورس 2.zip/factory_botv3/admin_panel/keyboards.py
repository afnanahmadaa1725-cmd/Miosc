"""لوحات المستخدم والإدارة داخل بوت المصنع."""

from telegram import InlineKeyboardButton as TelegramInlineKeyboardButton
from telegram import InlineKeyboardMarkup
from urllib.parse import urlsplit

from core.template_loader import TemplateInfo
from database.models import PaymentMethod


class StyledInlineKeyboardButton(TelegramInlineKeyboardButton):
    def __init__(self, **data):
        text = data.get("text", "")
        color_markers = {
            "\U0001f7e2": "success",
            "\U0001f534": "danger",
            "\U0001f535": "primary",
        }
        for marker, style in color_markers.items():
            if text.startswith(marker):
                text = text[len(marker):].lstrip()
                data["text"] = text
                data.setdefault("style", style)
                break
        if "style" not in data:
            data["style"] = "primary"
        super().__init__(**data)


InlineKeyboardButton = StyledInlineKeyboardButton


def _channel_url(channel: str) -> str:
    value = channel.strip()
    if value.startswith(("https://t.me/", "http://t.me/")):
        return value
    return f"https://t.me/{value.lstrip('@')}"


def start_keyboard(
    is_admin: bool = False,
    developer_channel: str = "ss_rssb",
    factory_updates_channel: str = "a_zi63",
) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text="🟢 اصنع بوتك ✦", callback_data="factory:make"
            )
        ],
        [
            InlineKeyboardButton(
                text="🔵 المطور ✮", url=_channel_url(developer_channel)
            ),
            InlineKeyboardButton(
                text="🔵 تحديثات المصنع",
                url=_channel_url(factory_updates_channel),
            ),
        ],
    ]
    if is_admin:
        rows.append(
            [InlineKeyboardButton(text="🔴 لوحة الإدارة ❑", callback_data="admin:open")]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def make_keyboard(paid_available: bool = True) -> InlineKeyboardMarkup:
    rows = []
    if paid_available:
        rows.append(
            [
                InlineKeyboardButton(
                    text="🔵 القسم المدفوع ✿", callback_data="create:paid"
                ),
                InlineKeyboardButton(
                    text="🟢 القسم المجاني ✸", callback_data="create:free"
                ),
            ]
        )
    else:
        rows.append(
            [
                InlineKeyboardButton(
                    text="🟢 القسم المجاني ✸", callback_data="create:free"
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def section_keyboard(include_payment: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if include_payment:
        rows.append(
            [InlineKeyboardButton(text="🔵 اشتراك ✰", callback_data="payment:menu")]
        )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:make")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_menu_keyboard(methods: list[PaymentMethod]) -> InlineKeyboardMarkup:
    methods_by_kind: dict[str, PaymentMethod] = {}
    for method in methods:
        if method.enabled and (
            method.kind not in methods_by_kind
            or (method.id or 0) > (methods_by_kind[method.kind].id or 0)
        ):
            methods_by_kind[method.kind] = method
    rows = []
    cards = []
    for kind, title, emoji in (
        ("visa", "VISA/Master Card", "🟢"),
        ("binance", "Binance ID", "🟢"),
        ("stars", "نجوم ✰", "🔵"),
        ("asiacell", "اسياسيل", "🔵"),
    ):
        cards.append(
            InlineKeyboardButton(
                text=f"{emoji} {title}", callback_data=f"paykind:{kind}"
            )
        )
    if cards:
        rows.extend([cards[index : index + 2] for index in range(0, len(cards), 2)])
    agent = methods_by_kind.get("agent")
    agent_url = urlsplit(agent.payload) if agent else None
    if (
        agent_url
        and agent_url.scheme == "https"
        and agent_url.netloc
    ):
        target = agent.payload
    elif agent and agent.payload.startswith("@"):
        target = f"https://t.me/{agent.payload[1:]}"
    else:
        target = ""
    if target:
        rows.append(
            [InlineKeyboardButton(text="🔴 شحن عبر الوكيل", url=target)]
        )
    else:
        rows.append(
            [
                InlineKeyboardButton(
                    text="🔴 شحن عبر الوكيل", callback_data="paykind:agent"
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:make")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_detail_keyboard(kind: str) -> InlineKeyboardMarkup:
    rows = []
    if kind == "stars":
        rows.append(
            [
                InlineKeyboardButton(
                    text="🔵 الدفع عبر نجوم ✰", callback_data="payconfirm:stars"
                )
            ]
        )
    elif kind == "asiacell":
        rows.append(
            [
                InlineKeyboardButton(
                    text="🔵 إدخال مبلغ", callback_data="payamount:asiacell"
                )
            ]
        )
    elif kind != "agent":
        rows.append(
            [
                InlineKeyboardButton(
                    text="🟢 تأكيد الدفع ✓", callback_data=f"payconfirm:{kind}"
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="payment:menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_back_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="payment:menu")]
        ]
    )


def admin_dashboard_keyboard(
    has_running_bots: bool = True,
    *,
    is_owner: bool = True,
    can_manage_bots: bool = True,
) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="🔴 الإعدادات ⚙️", callback_data="admin:settings")]
    ]
    management_buttons = []
    if can_manage_bots:
        management_buttons.append(
            InlineKeyboardButton(text="🔵 البوتات 🤖", callback_data="admin:bots")
        )
    if is_owner:
        management_buttons.append(
            InlineKeyboardButton(text="🔵 القوالب ⎘", callback_data="admin:templates")
        )
    if management_buttons:
        rows.append(management_buttons)
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    text="🟢 رصيد البوت بالنجوم",
                    callback_data="admin:stars_balance",
                ),
                InlineKeyboardButton(
                    text="🔵 اشتراك إجباري ❖", callback_data="admin:subs"
                ),
            ],
            [
                InlineKeyboardButton(text="🔴 إذاعة ♽", callback_data="admin:broadcast"),
                InlineKeyboardButton(
                    text="🟢 اذاعة للصانع",
                    callback_data="admin:factory_broadcast",
                ),
            ],
        ]
    )
    if can_manage_bots:
        management_actions = [
            InlineKeyboardButton(
                text="🔴 إيقاف الكل ▢" if has_running_bots else "🟢 تشغيل الكل ▣",
                callback_data=f"admin:all:{'stop' if has_running_bots else 'start'}",
            )
        ]
        if is_owner:
            management_actions.append(
                InlineKeyboardButton(text="🔴 حذف ⌦", callback_data="admin:delete")
            )
        rows.append(management_actions)
    elif is_owner:
        rows.append(
            [InlineKeyboardButton(text="🔴 حذف ⌦", callback_data="admin:delete")]
        )
    rows.append(
        [
            InlineKeyboardButton(
                text="🟢 جلسة مساعد ♫",
                callback_data="admin:sessions",
            ),
            InlineKeyboardButton(
                text="🔴 الإحصائيات",
                callback_data="admin:stats",
            ),
        ]
    )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_settings_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text="🔴 طرق الدفع", callback_data="admin:payment_settings"
            ),
            InlineKeyboardButton(
                text="🔴 حالة البوتات", callback_data="admin:bots"
            ),
        ]
    ]
    rows.append(
        [
            InlineKeyboardButton(
                text="🔵 الادمنيه", callback_data="admin:admins"
            )
        ]
    )
    rows.append(
        [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")]
    )
    return InlineKeyboardMarkup(
        inline_keyboard=rows
    )


def admin_admins_keyboard(can_manage: bool) -> InlineKeyboardMarkup:
    rows = []
    if can_manage:
        rows.extend(
            [
                [
                    InlineKeyboardButton(
                        text="🔵 اضافة ادمن", callback_data="admin:admin_add"
                    ),
                    InlineKeyboardButton(
                        text="🔴 تنزيل ادمن", callback_data="admin:admin_remove"
                    ),
                ]
            ]
        )
    rows.append(
        [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:settings")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_remove_list_keyboard(admins: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"🔴 {label}"[:64],
                callback_data=f"admin:admin_remove_select:{user_id}",
            )
        ]
        for user_id, label in admins
    ]
    rows.append(
        [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:admins")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_remove_confirm_keyboard(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🟢 تاكيد",
                    callback_data=f"admin:admin_remove_confirm:{user_id}",
                ),
                InlineKeyboardButton(
                    text="🔴 الغاء", callback_data="admin:admins"
                ),
            ]
        ]
    )


def admin_add_permissions_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🟢 نعم", callback_data="admin:admin_add_confirm:yes"
                ),
                InlineKeyboardButton(
                    text="🔴 لا", callback_data="admin:admin_add_confirm:no"
                ),
            ]
        ]
    )


def admin_payment_settings_keyboard() -> InlineKeyboardMarkup:
    kinds = (
        ("visa", "VISA/Master Card"),
        ("binance", "Binance ID"),
        ("stars", "نجوم ✰"),
        ("asiacell", "اسياسيل"),
        ("agent", "الوكيل"),
    )
    rows = [
        [
            InlineKeyboardButton(
                text=f"🔵 {title}", callback_data=f"admin:payment_edit:{kind}"
            )
        ]
        for kind, title in kinds
    ]
    rows.append(
        [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:settings")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_back_keyboard(target: str = "admin:open") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data=target)]
        ]
    )


def admin_bot_list_keyboard(
    bots: list[tuple[int, str, bool]], page: int = 0, page_size: int = 8
) -> InlineKeyboardMarkup:
    start = page * page_size
    current = bots[start : start + page_size]
    rows = [
        [
            InlineKeyboardButton(
                text=f"{'🟢' if running else '🔴'} @{username[:38]} ({bot_id})",
                callback_data=f"admin:bot:{bot_id}:{page}",
            )
        ]
        for bot_id, username, running in current
    ]
    if page > 0 or start + page_size < len(bots):
        controls = []
        if page > 0:
            controls.append(
                InlineKeyboardButton(
                    text="🔴 Back ◄", callback_data=f"admin:bots:{page - 1}"
                )
            )
        if start + page_size < len(bots):
            controls.append(
                InlineKeyboardButton(
                    text="🟢 Next ►", callback_data=f"admin:bots:{page + 1}"
                )
            )
        rows.append(controls)
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_bot_detail_keyboard(
    bot_id: int,
    page: int,
    is_running: bool,
    can_delete: bool,
) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text="🔴 إيقاف ▢" if is_running else "🟢 تشغيل ▣",
                callback_data=f"admin:bottoggle:{bot_id}:{page}",
            )
        ]
    ]
    if can_delete:
        rows.append(
            [
                InlineKeyboardButton(
                    text="🔴 حذف البوت وبياناته",
                    callback_data=f"admin:botdelete_confirm:{bot_id}:{page}",
                )
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                text="🔴 رجوع ◄",
                callback_data=f"admin:bots:{page}",
            )
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_template_list_keyboard(
    templates: list[TemplateInfo],
) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"🔵 {item.tier}:{item.name}",
                callback_data=f"admin:t:{item.tier}:{item.name}",
            )
        ]
        for item in templates
    ]
    rows.extend(
        [
            [InlineKeyboardButton(text="🔴 حذف قالب ⌦", callback_data="admin:delete")],
            [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def template_keyboard(templates: list[TemplateInfo]) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=item.name,
                callback_data=f"template:{item.tier}:{item.name}",
            )
        ]
        for item in templates
    ]
    if templates and templates[0].tier == "paid":
        rows.append(
            [InlineKeyboardButton(text="🔵 اشتراك ✰", callback_data="payment:menu")]
        )
    rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:make")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_keyboard(methods: list[PaymentMethod]) -> InlineKeyboardMarkup:
    buttons: list[list[InlineKeyboardButton]] = []
    for method in methods:
        if method.kind == "stars":
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"🔵 {method.title[:36]} — {method.stars_amount} نجمة",
                        callback_data=f"pay:{method.id}",
                    )
                ]
            )
        elif method.payload.startswith("https://"):
            buttons.append(
                [InlineKeyboardButton(text=f"🟢 {method.title[:55]}", url=method.payload)]
            )
    buttons.append(
        [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="nav:make")]
    )
    return InlineKeyboardMarkup(inline_keyboard=buttons)
