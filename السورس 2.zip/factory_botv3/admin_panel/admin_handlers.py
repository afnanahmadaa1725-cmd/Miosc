"""أوامر إدارة القوالب وقنوات الاشتراك والإذاعات."""

from __future__ import annotations

import logging
import re
import shlex
import tempfile
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

from telegram import CallbackQuery, InlineKeyboardMarkup, Message
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from telethon import TelegramClient
from telethon.sessions import StringSession

from config import Settings
from core.fernet_compat import Fernet, InvalidToken
from core.ptb_compat import (
    Bot,
    Command,
    F,
    FSMContext,
    Router,
    State,
    StatesGroup,
    TelegramAPIError,
)
from admin_panel.keyboards import (
    admin_add_permissions_keyboard,
    admin_admins_keyboard,
    admin_back_keyboard,
    admin_bot_detail_keyboard,
    admin_bot_list_keyboard,
    admin_dashboard_keyboard,
    admin_payment_settings_keyboard,
    admin_remove_confirm_keyboard,
    admin_remove_list_keyboard,
    admin_settings_keyboard,
    admin_template_list_keyboard,
    StyledInlineKeyboardButton as InlineKeyboardButton,
)
from core.broadcast import broadcast_factory_users, broadcast_free_users
from core.process_manager import ProcessManager
from core.template_loader import MAX_ARCHIVE_BYTES, MAX_FILE_BYTES, TemplateLoader
from core.ui import edit_callback_panel, edit_tracked_panel, remember_panel
from database.connection import Database
from database.models import (
    AssistantSession,
    BotRecord,
    ForcedSub,
    FactoryAdmin,
    FactoryBotManager,
    PaidGrant,
    PaymentMethod,
    PaymentRequest,
    StarPayment,
    User,
    utc_now,
)

logger = logging.getLogger(__name__)
CHAT_ID_PATTERN = re.compile(r"^(?:-100\d+|-?\d+|@[A-Za-z0-9_]{5,32})$")


class AdminState(StatesGroup):
    broadcast_message = State()
    factory_broadcast_message = State()
    payment_details = State()
    add_admin_id = State()
    admin_add_confirmation = State()
    add_subscription = State()
    upload_template = State()
    assistant_session = State()


def is_admin(user_id: int, settings: Settings) -> bool:
    return settings.is_admin(user_id)


def is_factory_owner(user_id: int, settings: Settings) -> bool:
    return user_id in settings.admin_ids


def has_bot_management(user_id: int, settings: Settings) -> bool:
    return settings.can_manage_bots(user_id)


async def _factory_bot_is_channel_admin(bot: Bot, chat_id: int) -> bool:
    bot_id = (await bot.get_me()).id
    member = await bot.get_chat_member(chat_id, bot_id)
    status = getattr(member.status, "value", member.status)
    return status in {"administrator", "creator"}


def setup_admin_handlers(
    database: Database,
    loader: TemplateLoader,
    settings: Settings,
    manager: ProcessManager,
) -> Router:
    router = Router(name="admin")
    admin_panels: dict[tuple[int, int], tuple[int, bool]] = {}

    async def edit_admin_menu(
        callback: CallbackQuery,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        panel = await edit_callback_panel(callback, text, reply_markup)
        if panel is not None and callback.message is not None:
            admin_panels[(callback.from_user.id, callback.message.chat.id)] = (
                panel.message_id,
                bool(panel.photo or panel.animation),
            )

    async def show_admin_list(
        message: Message,
        state: FSMContext,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        data = await state.get_data()
        chat_id = data.get("panel_chat_id")
        message_id = data.get("panel_message_id")
        panel_media = data.get("panel_media")
        cached_panel = admin_panels.get((message.from_user.id, message.chat.id))
        if cached_panel is not None and (
            not isinstance(message_id, int) or cached_panel[0] > message_id
        ):
            chat_id = message.chat.id
            message_id, panel_media = cached_panel
            await state.update_data(
                panel_chat_id=chat_id,
                panel_message_id=message_id,
                panel_media=panel_media,
            )
        if isinstance(chat_id, int) and isinstance(message_id, int):
            await edit_tracked_panel(message, state, text, reply_markup)
            data = await state.get_data()
            admin_panels[(message.from_user.id, message.chat.id)] = (
                data["panel_message_id"],
                bool(data.get("panel_media")),
            )
            return
        panel = await message.answer(text, reply_markup=reply_markup)
        await remember_panel(state, panel)
        admin_panels[(message.from_user.id, message.chat.id)] = (
            panel.message_id,
            bool(panel.photo or panel.animation),
        )

    async def restart_free_bots_for_subscription_change() -> str:
        restarted, failed = await manager.restart_running_bots_for_tier("free")
        result = ""
        if restarted:
            result += (
                "\nأعيد تشغيل البوتات المجانية النشطة لتطبيق التغيير: "
                + ", ".join(map(str, restarted))
                + "."
            )
        if failed:
            result += (
                "\nتعذر إعادة تشغيل البوتات التالية؛ ستطبق القنوات عند تشغيلها "
                "بعد مراجعة سجلاتها: "
                + ", ".join(map(str, failed))
                + "."
            )
        if not restarted and not failed:
            result = "\nستطبق القنوات مباشرة عند استخدام البوت أو تشغيله."
        return result

    async def current_dashboard_keyboard(user_id: int) -> InlineKeyboardMarkup:
        async with database.session() as session:
            running = await session.scalar(
                select(BotRecord.id)
                .where(BotRecord.status == "running")
                .limit(1)
            )
        return admin_dashboard_keyboard(
            has_running_bots=running is not None,
            is_owner=user_id in settings.admin_ids,
            can_manage_bots=settings.can_manage_bots(user_id),
        )

    async def assistant_sessions_keyboard() -> tuple[str, InlineKeyboardMarkup]:
        async with database.session() as session:
            accounts = (
                await session.execute(
                    select(AssistantSession, BotRecord)
                    .outerjoin(
                        BotRecord,
                        AssistantSession.assigned_bot_id == BotRecord.id,
                    )
                    .order_by(AssistantSession.id)
                    .limit(40)
                )
            ).all()
            total = await session.scalar(select(func.count(AssistantSession.id)))
            available = await session.scalar(
                select(func.count(AssistantSession.id)).where(
                    AssistantSession.assigned_bot_id.is_(None)
                )
            )
        rows = []
        for account, record in accounts:
            assignment = (
                f"البوت #{record.id} @{record.username}"
                if record
                else "متاحة لبوت جديد"
            )
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"🔵 حساب {account.telegram_id} — {assignment}"[:60],
                        callback_data=f"admin:session_replace:{account.id}",
                    )
                ]
            )
        rows.append(
            [
                InlineKeyboardButton(
                    text="🟢 إضافة جلسة حساب مساعد",
                    callback_data="admin:session_add",
                )
            ]
        )
        rows.append(
            [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")]
        )
        text = (
            f"• جلسات الحسابات المساعدة: {total or 0}\n"
            f"• الجلسات المتاحة لبوتات جديدة: {available}\n"
            "• كل جلسة تُخصص لبوت واحد فقط ولا تُشارك مع غيره.\n"
            "• اختر حساباً لاستبدال جلسته؛ يعاد تشغيل البوت العامل لتطبيق التغيير."
        )
        if total and total > len(accounts):
            text += "\n• تُعرض أول 40 جلسة فقط."
        return text, InlineKeyboardMarkup(inline_keyboard=rows)

    async def factory_admins_panel(
        can_manage: bool,
    ) -> tuple[str, InlineKeyboardMarkup, list[tuple[int, str]]]:
        async with database.session() as session:
            admins = (
                await session.execute(
                    select(FactoryAdmin).order_by(
                        FactoryAdmin.created_at, FactoryAdmin.user_id
                    )
                )
            ).scalars().all()
            bot_manager_ids = set(
                (
                    await session.execute(
                        select(FactoryBotManager.user_id)
                    )
                ).scalars().all()
            )
        removable = [
            (
                admin.user_id,
                (
                    f"@{admin.username}" if admin.username else str(admin.user_id)
                )
                + (
                    " | تحكم بالبوتات"
                    if admin.user_id in bot_manager_ids
                    else " | أدمن محدود"
                ),
            )
            for admin in admins
        ]
        lines = ["- الادمنيه المرفوعين :", "ــــــــــــــــــــــــــــ"]
        if removable:
            lines.extend(
                f"{index}- الادمن | {label}"
                for index, (_, label) in enumerate(removable, start=1)
            )
        else:
            lines.append("لا يوجد ادمنيه مرفوعون حالياً.")
        return (
            "\n".join(lines),
            admin_admins_keyboard(can_manage),
            removable,
        )

    @router.message(Command("admin"))
    async def admin_help(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        help_lines = [
            "◐ لوحة إدارة بوت الصانع الرئيسية",
            "◐ من هنا يمكنك إدارة إعدادات البوت",
            "اختر القسم المطلوب، أو استخدم الأوامر التالية:",
        ]
        if has_bot_management(message.from_user.id, settings):
            help_lines.extend(
                [
                    "/bots - عرض البوتات وحالاتها",
                    "/stopbot <id> و/startbot <id> - إيقاف أو تشغيل بوت",
                ]
            )
        if is_factory_owner(message.from_user.id, settings):
            help_lines.extend(
                [
                    "/templates - عرض القوالب",
                    "/deletetemplate <free|paid:name> - حذف قالب",
                    "رفع ZIP أو ملف .py مع وصف free:name أو paid:name لإضافة قالب.",
                ]
            )
        help_lines.extend(
            [
                "/addsub <chat_id|@channel> <invite_link> - إضافة اشتراك إجباري",
                "/delsub <chat_id|@channel> - حذف قناة",
                "/broadcast - بدء إذاعة اختيارية لمستخدمي المجاني",
                "زر «اذاعة للصانع» - إرسال محتوى لمستخدمي الصانع الموافقين على الإذاعة",
                "/payments و/paymentadd و/paymentdel - إدارة وسائل الدفع",
                "/grantpaid <user_id> - تفعيل الدفع اليدوي بعد التحقق",
            ]
        )
        await show_admin_list(
            message,
            state,
            "\n".join(help_lines),
            await current_dashboard_keyboard(message.from_user.id),
        )

    @router.callback_query(F.data.startswith("admin:"))
    async def open_admin_section(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id, settings):
            await callback.answer("هذه اللوحة خاصة بالإدارة.", show_alert=True)
            return
        parts = (callback.data or "").split(":")
        action = parts[1] if len(parts) > 1 else ""
        owner_only_actions = {
            "admin_add",
            "admin_remove",
            "admin_remove_select",
            "admin_remove_confirm",
            "admin_add_confirm",
            "templates",
            "t",
            "d",
            "x",
            "delete",
            "upload",
            "botdelete",
            "botdelete_confirm",
        }
        if action in owner_only_actions and callback.from_user.id not in settings.admin_ids:
            await callback.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط.",
                show_alert=True,
            )
            return
        if action in {"bots", "bot", "bottoggle", "all"} and not settings.can_manage_bots(
            callback.from_user.id
        ):
            await callback.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط.",
                show_alert=True,
            )
            return
        await callback.answer()
        if action == "open":
            await state.clear()
            await edit_admin_menu(
                callback,
                "◐ لوحة إدارة بوت الصانع الرئيسية\n◐ من هنا يمكنك إدارة إعدادات البوت",
                await current_dashboard_keyboard(callback.from_user.id),
            )
            return
        if action == "settings":
            await state.clear()
            await edit_admin_menu(
                callback,
                "• لوحة الإعدادات، من هنا يمكنك تعديل قسم الخدمات والدفع:",
                admin_settings_keyboard(),
            )
            return
        if action == "admins":
            await state.clear()
            text, markup, _ = await factory_admins_panel(
                can_manage=callback.from_user.id in settings.admin_ids
            )
            await edit_admin_menu(callback, text, markup)
            return
        if action == "admin_add":
            await state.set_state(AdminState.add_admin_id)
            if callback.message:
                await remember_panel(state, callback.message)
                await edit_admin_menu(
                    callback,
                    "- ارسل ايدي المستخدم لرفعه ادمن تحكم بالصانع:\n"
                    "أرسل /cancel للإلغاء.",
                    admin_back_keyboard("admin:admins"),
                )
            return
        if (
            action == "admin_add_confirm"
            and len(parts) == 3
            and parts[2] in {"yes", "no"}
        ):
            data = await state.get_data()
            target_id = data.get("pending_admin_id")
            if (
                await state.get_state() != AdminState.admin_add_confirmation.state
                or not isinstance(target_id, int)
                or target_id <= 0
            ):
                await state.clear()
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "انتهت جلسة إضافة الأدمن؛ أعد المحاولة.",
                        admin_back_keyboard("admin:admins"),
                    )
                return
            username = data.get("pending_admin_username")
            can_manage_bots = parts[2] == "yes"
            async with database.session() as session:
                existing = await session.get(FactoryAdmin, target_id)
                if existing is not None:
                    await state.clear()
                    if callback.message:
                        await edit_admin_menu(
                            callback,
                            "هذا المستخدم أدمن بالفعل؛ لم يتم تغيير صلاحياته.",
                            admin_back_keyboard("admin:admins"),
                        )
                    return
                existing = FactoryAdmin(
                    user_id=target_id,
                    username=username,
                    granted_by=callback.from_user.id,
                )
                session.add(existing)
                await session.flush()
                if can_manage_bots:
                    bot_manager = await session.get(FactoryBotManager, target_id)
                    if bot_manager is None:
                        session.add(
                            FactoryBotManager(
                                user_id=target_id,
                                granted_by=callback.from_user.id,
                            )
                        )
                else:
                    bot_manager = await session.get(FactoryBotManager, target_id)
                    if bot_manager is not None:
                        await session.delete(bot_manager)
                try:
                    await session.commit()
                except IntegrityError:
                    await session.rollback()
                    logger.exception(
                        "تعذر حفظ صلاحيات الأدمن %s", target_id
                    )
                    await state.clear()
                    if callback.message:
                        await edit_admin_menu(
                            callback,
                            "تعذر حفظ الأدمن؛ أعد المحاولة.",
                            admin_back_keyboard("admin:admins"),
                        )
                    return
            settings.managed_admin_ids.add(target_id)
            if can_manage_bots:
                settings.managed_bot_admin_ids.add(target_id)
            else:
                settings.managed_bot_admin_ids.discard(target_id)
            await state.clear()
            list_text, markup, _ = await factory_admins_panel(can_manage=True)
            permission_text = (
                "مع صلاحية تشغيل وإيقاف البوتات المصنوعة فقط."
                if can_manage_bots
                else "دون صلاحية إدارة البوتات المصنوعة."
            )
            target_label = f"@{username}" if username else str(target_id)
            if callback.message:
                await edit_admin_menu(
                    callback,
                    f"تم رفع المستخدم {target_label} أدمنًا للصانع {permission_text}\n\n{list_text}",
                    markup,
                )
            return
        if action == "admin_remove":
            await state.clear()
            _, _, removable = await factory_admins_panel(can_manage=True)
            if not removable:
                await edit_admin_menu(
                    callback,
                    "لا يوجد أدمنية مرفوعون لتنزيلهم.",
                    admin_back_keyboard("admin:admins"),
                )
                return
            await edit_admin_menu(
                callback,
                "- اختر الادمن المراد تنزيله:",
                admin_remove_list_keyboard(removable),
            )
            return
        if (
            action == "admin_remove_select"
            and len(parts) == 3
            and parts[2].isdigit()
        ):
            target_id = int(parts[2])
            async with database.session() as session:
                target = await session.get(FactoryAdmin, target_id)
            if target is None:
                await edit_admin_menu(
                    callback,
                    "هذا المستخدم ليس ضمن الأدمنية المرفوعين.",
                    admin_back_keyboard("admin:admins"),
                )
                return
            username = f"@{target.username}" if target.username else str(target_id)
            await edit_admin_menu(
                callback,
                f"- سيتم تنزيل المستخدم {username} من الادمنيه هل انت متاكد ؟",
                admin_remove_confirm_keyboard(target_id),
            )
            return
        if (
            action == "admin_remove_confirm"
            and len(parts) == 3
            and parts[2].isdigit()
        ):
            target_id = int(parts[2])
            async with database.session() as session:
                target = await session.get(FactoryAdmin, target_id)
                if target is not None:
                    bot_manager = await session.get(FactoryBotManager, target_id)
                    if bot_manager is not None:
                        await session.delete(bot_manager)
                    await session.delete(target)
                    await session.commit()
            if target is None:
                await edit_admin_menu(
                    callback,
                    "هذا المستخدم ليس ضمن الأدمنية المرفوعين.",
                    admin_back_keyboard("admin:admins"),
                )
                return
            settings.managed_admin_ids.discard(target_id)
            settings.managed_bot_admin_ids.discard(target_id)
            await edit_admin_menu(
                callback,
                f"تم تنزيل المستخدم {f'@{target.username}' if target.username else target_id} من أدمنية الصانع.",
                admin_back_keyboard("admin:admins"),
            )
            return
        if action == "payment_settings":
            await state.clear()
            await edit_admin_menu(
                callback,
                "اختر طريقة الدفع لتحديث تفاصيلها:",
                admin_payment_settings_keyboard(),
            )
            return
        if action == "payment_confirm":
            data = await state.get_data()
            kind = data.get("payment_kind")
            allowed = {
                "visa": "VISA/Master Card",
                "binance": "Binance ID",
                "stars": "نجوم",
                "asiacell": "اسياسيل",
                "agent": "شحن عبر الوكيل",
            }
            if kind not in allowed or not isinstance(data.get("payment_payload"), str):
                await state.clear()
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "انتهت جلسة تعديل الدفع؛ أعد المحاولة.",
                        admin_back_keyboard("admin:payment_settings"),
                    )
                return
            async with database.session() as session:
                method = await session.scalar(
                    select(PaymentMethod)
                    .where(PaymentMethod.kind == kind)
                    .order_by(PaymentMethod.id.desc())
                    .limit(1)
                )
                if method is None:
                    method = PaymentMethod(
                        title=allowed[kind],
                        kind=kind,
                        payload=data["payment_payload"],
                        stars_amount=data.get("payment_stars_amount"),
                        enabled=True,
                    )
                    session.add(method)
                else:
                    method.title = allowed[kind]
                    method.payload = data["payment_payload"]
                    method.stars_amount = data.get("payment_stars_amount")
                    method.enabled = True
                await session.commit()
            await state.clear()
            if callback.message:
                await edit_admin_menu(
                    callback,
                    f"تم حفظ تفاصيل {allowed[kind]} وتحديثها للمستخدمين.",
                    admin_payment_settings_keyboard(),
                )
            return
        if action == "payment_redo":
            data = await state.get_data()
            kind = data.get("payment_kind", "")
            await state.set_state(AdminState.payment_details)
            await state.update_data(payment_payload=None, payment_stars_amount=None)
            if callback.message:
                await remember_panel(state, callback.message)
                await edit_admin_menu(
                    callback,
                    f"ـ قم بتعديل تفاصيل طريقة الدفع ({kind}) أو أرسل تفاصيل جديدة.",
                    admin_back_keyboard("admin:payment_settings"),
                )
            return
        if action == "payment_edit" and len(parts) == 3:
            kind = parts[2]
            if kind not in {"visa", "binance", "stars", "asiacell", "agent"}:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "وسيلة الدفع غير معروفة.",
                        admin_back_keyboard("admin:payment_settings"),
                    )
                return
            await state.set_state(AdminState.payment_details)
            await state.update_data(
                payment_kind=kind,
                payment_payload=None,
                payment_stars_amount=None,
            )
            if callback.message:
                await remember_panel(state, callback.message)
                example = (
                    "أرسل عدد النجوم في السطر الأول، ثم تفاصيل الدفع اختيارياً في الأسطر التالية."
                    if kind == "stars"
                    else "أرسل تفاصيل الدفع التي ستظهر للمستخدم. للوكيل أرسل رابط HTTPS أو تفاصيل التواصل."
                )
                await edit_admin_menu(
                    callback,
                    f"ـ قم بتعديل وإضافة تفاصيل طريقة الدفع ({kind}):\n{example}\n"
                    "أرسل /cancel للإلغاء.",
                    admin_back_keyboard("admin:payment_settings"),
                )
            return
        if action == "bots":
            page = int(parts[2]) if len(parts) == 3 and parts[2].isdigit() else 0
            async with database.session() as session:
                records = (
                    await session.execute(select(BotRecord).order_by(BotRecord.id))
                ).scalars().all()
            bots = [
                (record.id, record.username, record.enabled and record.status == "running")
                for record in records
            ]
            await edit_admin_menu(
                callback,
                f"• البوتات المصنوعة الحالية ({len(bots)}):",
                admin_bot_list_keyboard(bots, page),
            )
            return
        if action == "bot" and len(parts) in {3, 4} and parts[2].isdigit():
            bot_id = int(parts[2])
            page = int(parts[3]) if len(parts) == 4 and parts[3].isdigit() else 0
            async with database.session() as session:
                record = await session.get(BotRecord, bot_id)
            if record is None:
                if callback.message:
                    await edit_admin_menu(
                        callback, "البوت غير موجود.", admin_back_keyboard("admin:bots")
                    )
                return
            owner_name = str(record.owner_id)
            try:
                owner = await callback.bot.get_chat(record.owner_id)
                owner_name = owner.full_name or owner_name
                if owner.username:
                    owner_name += f" (@{owner.username})"
            except TelegramAPIError:
                logger.exception("تعذر جلب بيانات مالك البوت %s", record.owner_id)
            created = record.created_at.strftime("%Y-%m-%d %H:%M UTC")
            text = (
                f"• البوت @{record.username}\n"
                f"• الحالة: {'يعمل ✓' if record.status == 'running' else 'متوقف ✘'}\n"
                f"• القسم: {record.tier}\n"
                f"• القالب: {record.template_name}\n"
                f"• تاريخ الإنشاء: {created}\n"
                f"• المستخدم: {owner_name}"
            )
            markup = admin_bot_detail_keyboard(
                bot_id,
                page,
                is_running=record.status == "running",
                can_delete=callback.from_user.id in settings.admin_ids,
            )
            await edit_admin_menu(callback, text, markup)
            return
        if action == "bottoggle" and len(parts) in {3, 4} and parts[2].isdigit():
            bot_id = int(parts[2])
            page = int(parts[3]) if len(parts) == 4 and parts[3].isdigit() else 0
            async with database.session() as session:
                record = await session.get(BotRecord, bot_id)
                should_start = bool(record and record.status != "running")
            if record is None:
                if callback.message:
                    await edit_admin_menu(
                        callback, "البوت غير موجود.", admin_back_keyboard("admin:bots")
                    )
                return
            try:
                if should_start:
                    await manager.start_stored_bot(bot_id)
                else:
                    await manager.stop_bot(bot_id)
            except Exception as error:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        f"تعذر تحديث حالة البوت: {error}",
                        admin_back_keyboard(f"admin:bot:{bot_id}:{page}"),
                    )
                return
            async with database.session() as session:
                updated = await session.get(BotRecord, bot_id)
            if updated:
                try:
                    owner = await callback.bot.get_chat(updated.owner_id)
                    owner_name = owner.full_name or str(updated.owner_id)
                    if owner.username:
                        owner_name += f" (@{owner.username})"
                except TelegramAPIError:
                    logger.exception(
                        "تعذر جلب بيانات مالك البوت %s", updated.owner_id
                    )
                    owner_name = str(updated.owner_id)
                await edit_admin_menu(
                    callback,
                    f"• البوت @{updated.username}\n"
                    f"• الحالة: {'يعمل ✓' if updated.status == 'running' else 'متوقف ✘'}\n"
                    f"• القسم: {updated.tier}\n"
                    f"• القالب: {updated.template_name}\n"
                    f"• المستخدم: {owner_name}",
                    admin_bot_detail_keyboard(
                        bot_id,
                        page,
                        is_running=updated.status == "running",
                        can_delete=callback.from_user.id in settings.admin_ids,
                    ),
                )
            return
        if (
            action == "botdelete_confirm"
            and len(parts) == 4
            and parts[2].isdigit()
        ):
            bot_id = int(parts[2])
            page = int(parts[3]) if parts[3].isdigit() else 0
            async with database.session() as session:
                record = await session.get(BotRecord, bot_id)
            if record is None:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "البوت غير موجود.",
                        admin_back_keyboard(f"admin:bots:{page}"),
                    )
                return
            await edit_admin_menu(
                callback,
                f"هل تريد حذف البوت @{record.username} وبياناته نهائيًا؟ "
                "سيتم إيقافه وتحرير جلسة الحساب المساعد لاستخدامها لبوت آخر.",
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🔴 تأكيد الحذف",
                                callback_data=f"admin:botdelete:{bot_id}:{page}",
                            ),
                            InlineKeyboardButton(
                                text="🟢 إلغاء",
                                callback_data=f"admin:bot:{bot_id}:{page}",
                            ),
                        ]
                    ]
                ),
            )
            return
        if action == "botdelete" and len(parts) == 4 and parts[2].isdigit():
            bot_id = int(parts[2])
            page = int(parts[3]) if parts[3].isdigit() else 0
            try:
                await manager.delete_bot(bot_id)
            except LookupError:
                await edit_admin_menu(
                    callback,
                    "البوت غير موجود أو حُذف مسبقًا.",
                    admin_back_keyboard(f"admin:bots:{page}"),
                )
                return
            except Exception as error:
                logger.exception("تعذر حذف البوت %s من لوحة الإدارة", bot_id)
                await edit_admin_menu(
                    callback,
                    f"تعذر إكمال حذف البوت: {error}",
                    admin_back_keyboard(f"admin:bot:{bot_id}:{page}"),
                )
                return
            async with database.session() as session:
                records = (
                    await session.execute(select(BotRecord).order_by(BotRecord.id))
                ).scalars().all()
            bots = [
                (record.id, record.username, record.enabled and record.status == "running")
                for record in records
            ]
            await edit_admin_menu(
                callback,
                "تم إيقاف البوت وحذف بياناته وتحرير جلسة الحساب المساعد.",
                admin_bot_list_keyboard(bots, page),
            )
            return
        if action == "all" and len(parts) == 3 and parts[2] in {"start", "stop"}:
            try:
                if parts[2] == "stop":
                    await manager.stop_all_bots()
                    text = "تم إيقاف جميع البوتات مع الاحتفاظ ببياناتها."
                else:
                    await manager.start_all_bots()
                    text = "تم تشغيل البوتات."
            except Exception as error:
                text = f"تعذر إكمال العملية: {error}"
            await edit_admin_menu(
                callback, text, await current_dashboard_keyboard(callback.from_user.id)
            )
            return
        if action == "stats":
            async with database.session() as session:
                users_count = await session.scalar(select(func.count(User.id)))
                bots_count = await session.scalar(select(func.count(BotRecord.id)))
            await edit_admin_menu(
                callback,
                f"- عدد مستخدمين البوت الحالي : {users_count or 0}\n"
                f"- عدد البوتات المصنوعة : {bots_count or 0}",
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🔴 احصائيات المشتركين",
                                callback_data="admin:subscriber_stats",
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                text="🔴 رجوع ◄",
                                callback_data="admin:open",
                            )
                        ],
                    ]
                ),
            )
            return
        if action == "subscriber_stats":
            async with database.session() as session:
                channels = (
                    await session.execute(
                        select(ForcedSub).order_by(ForcedSub.id)
                    )
                ).scalars().all()

            lines = ["- مشتركين قنوات الاجباري :"]
            if not channels:
                lines.append("لا توجد قنوات اشتراك إجباري مضافة.")
            for channel in channels:
                chat_id: int | str = (
                    int(channel.chat_id)
                    if channel.chat_id.lstrip("-").isdigit()
                    else channel.chat_id
                )
                title = channel.title or channel.chat_id
                try:
                    member_count = await callback.bot.get_chat_member_count(chat_id)
                except TelegramAPIError:
                    logger.exception(
                        "تعذر جلب عدد أعضاء قناة الاشتراك الإجباري %s",
                        channel.chat_id,
                    )
                    lines.append(f"- {title} : تعذر جلب العدد")
                else:
                    lines.append(f"- {title} : {member_count}")

            await edit_admin_menu(
                callback,
                "\n".join(lines),
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🔴 تحديث الإحصائيات",
                                callback_data="admin:subscriber_stats",
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                text="🔴 رجوع ◄",
                                callback_data="admin:stats",
                            )
                        ],
                    ]
                ),
            )
            return
        if action == "stars_balance":
            try:
                balance = await callback.bot.get_my_star_balance()
                transactions = await callback.bot.get_star_transactions(limit=10)
            except TelegramAPIError:
                logger.exception("تعذر جلب رصيد ومعاملات نجوم بوت الصانع")
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "تعذر جلب رصيد النجوم من Telegram. تحقق من اتصال البوت ثم حاول مجددًا.",
                        admin_back_keyboard("admin:open"),
                    )
                return

            async with database.session() as session:
                total_payments = await session.scalar(
                    select(func.count(StarPayment.id))
                )
                total_stars = await session.scalar(
                    select(func.coalesce(func.sum(StarPayment.amount), 0))
                )
                recent_payments = (
                    await session.execute(
                        select(StarPayment)
                        .order_by(StarPayment.created_at.desc())
                        .limit(5)
                    )
                ).scalars().all()

            lines = [
                f"• الرصيد الحالي في Telegram: {balance.amount} نجمة",
                "• سجل مدفوعات النجوم الناجحة المسجلة في المصنع:",
                f"  عدد العمليات: {total_payments or 0}",
                f"  إجمالي المدفوعات المسجلة: {total_stars or 0} نجمة",
            ]
            for payment in recent_payments:
                lines.append(
                    f"  دفع {payment.amount} نجمة من المستخدم {payment.user_id} "
                    f"— {payment.created_at.strftime('%Y-%m-%d %H:%M UTC')}"
                )

            lines.append("• آخر معاملات Telegram:")
            if transactions.transactions:
                for transaction in transactions.transactions[:10]:
                    direction = (
                        "سحب/صادر"
                        if transaction.amount < 0
                        or getattr(transaction.receiver, "type", None) == "fragment"
                        or getattr(transaction.source, "type", None) == "fragment"
                        else "وارد"
                    )
                    partner = transaction.receiver or transaction.source
                    partner_type = getattr(partner, "type", None)
                    if partner_type == "fragment":
                        withdrawal_state = getattr(partner, "withdrawal_state", None)
                        transaction_state = getattr(withdrawal_state, "type", None)
                        detail = (
                            f" ({transaction_state})" if transaction_state else ""
                        )
                    elif partner_type == "user":
                        user = getattr(partner, "user", None)
                        detail = (
                            f" (المستخدم {user.id})" if user is not None else ""
                        )
                    else:
                        detail = f" ({partner_type})" if partner_type else ""
                    lines.append(
                        f"  {direction}: {transaction.amount} نجمة{detail} — "
                        f"{transaction.date.strftime('%Y-%m-%d %H:%M UTC')}"
                    )
            else:
                lines.append("  لا توجد معاملات مسجلة في Telegram.")

            markup = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🟢 التوجه الى منصه السحب",
                            url="https://fragment.com/",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="🔵 تحديث الرصيد",
                            callback_data="admin:stars_balance",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="🔴 رجوع ◄",
                            callback_data="admin:open",
                        )
                    ],
                ]
            )
            await edit_admin_menu(callback, "\n".join(lines), markup)
            return
        if action == "templates":
            templates_list = loader.list_templates()
            await edit_admin_menu(
                callback,
                "• قائمة القوالب المرفوعة بالصانع:",
                admin_template_list_keyboard(templates_list),
            )
            return
        if action == "t" and len(parts) == 4:
            tier, name = parts[2], parts[3]
            try:
                template = loader.get(tier, name)
            except (FileNotFoundError, ValueError):
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "القالب غير موجود.",
                        admin_back_keyboard("admin:templates"),
                    )
                return
            created = template.path.stat().st_ctime
            from datetime import datetime, timezone

            uploaded_at = datetime.fromtimestamp(created, timezone.utc).strftime(
                "%Y-%m-%d %H:%M UTC"
            )
            markup = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🔴 حذف القالب ⌦",
                            callback_data=f"admin:d:{tier}:{name}",
                        )
                    ],
                    [InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:templates")],
                ]
            )
            await edit_admin_menu(
                callback,
                f"• نوع القالب: {tier}\n• تاريخ الرفع: {uploaded_at}",
                markup,
            )
            return
        if action == "d" and len(parts) == 4:
            tier, name = parts[2], parts[3]
            markup = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🟢 تأكيد وحذف ✓",
                            callback_data=f"admin:x:{tier}:{name}",
                        ),
                        InlineKeyboardButton(
                            text="🔴 إلغاء ✘", callback_data="admin:templates"
                        ),
                    ]
                ]
            )
            await edit_admin_menu(
                callback, "ـ سيتم حذف بيانات القالب، هل أنت متأكد؟", markup
            )
            return
        if action == "x" and len(parts) == 4:
            tier, name = parts[2], parts[3]
            async with database.session() as session:
                in_use = await session.scalar(
                    select(BotRecord.id)
                    .where(
                        BotRecord.tier == tier,
                        BotRecord.template_name == name,
                        BotRecord.enabled.is_(True),
                    )
                    .limit(1)
                )
            if in_use:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "لا يمكن حذف قالب تستخدمه بوتات مفعلة.",
                        admin_back_keyboard("admin:templates"),
                    )
                return
            try:
                loader.delete(tier, name)
            except (ValueError, FileNotFoundError) as error:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        f"تعذر حذف القالب: {error}",
                        admin_back_keyboard("admin:templates"),
                    )
                return
            await edit_admin_menu(
                callback,
                "تم حذف القالب.",
                admin_back_keyboard("admin:templates"),
            )
            return
        if action == "delete":
            templates_list = loader.list_templates()
            rows = [
                [
                    InlineKeyboardButton(
                        text=f"🔴 {item.tier}:{item.name}",
                        callback_data=f"admin:d:{item.tier}:{item.name}",
                    )
                ]
                for item in templates_list
            ]
            rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")])
            await edit_admin_menu(
                callback,
                "اختر القالب الذي تريد حذفه:",
                InlineKeyboardMarkup(inline_keyboard=rows),
            )
            return
        if action == "subs":
            await state.clear()
            async with database.session() as session:
                channels = (
                    await session.execute(select(ForcedSub).order_by(ForcedSub.id))
                ).scalars().all()
            rows = [
                [
                    InlineKeyboardButton(
                        text=f"🔴 حذف {(channel.title or channel.chat_id)[:52]}",
                        callback_data=f"admin:subdel:{channel.id}",
                    )
                ]
                for channel in channels
            ]
            rows.append(
                [InlineKeyboardButton(text="🔵 إضافة قناة", callback_data="admin:subadd")]
            )
            rows.append([InlineKeyboardButton(text="🔴 رجوع ◄", callback_data="admin:open")])
            body = "• قسم الاشتراك الإجباري\n• أضف قناة لتطبيقها على القوالب المجانية فقط."
            await edit_admin_menu(
                callback, body, InlineKeyboardMarkup(inline_keyboard=rows)
            )
            return
        if action == "subadd":
            await state.set_state(AdminState.add_subscription)
            if callback.message:
                await remember_panel(state, callback.message)
            await edit_admin_menu(
                callback,
                "ـ أرسل رابط القناة أو يوزرها العام، مثال @channel أو https://t.me/channel",
                admin_back_keyboard("admin:subs"),
            )
            return
        if action == "subdel" and len(parts) == 3 and parts[2].isdigit():
            async with database.session() as session:
                channel = await session.get(ForcedSub, int(parts[2]))
                if channel:
                    await session.delete(channel)
                    await session.commit()
            restart_message = await restart_free_bots_for_subscription_change()
            await edit_admin_menu(
                callback,
                "تم حذف قناة الاشتراك." + restart_message,
                admin_back_keyboard("admin:subs"),
            )
            return
        if action == "upload":
            await state.set_state(AdminState.upload_template)
            if callback.message:
                await remember_panel(state, callback.message)
            await edit_admin_menu(
                callback,
                "ارفع ملف ZIP أو .py وأرفق وصفاً بالصيغة free:name أو paid:name. "
                "ارفع الملفات الموثوقة فقط.",
                admin_back_keyboard(),
            )
            return
        if action in {"sessions", "session_help"}:
            await state.clear()
            text, markup = await assistant_sessions_keyboard()
            await edit_admin_menu(callback, text, markup)
            return
        if action == "session_add":
            await state.set_state(AdminState.assistant_session)
            await state.update_data(assistant_session_mode="add")
            if callback.message:
                await remember_panel(state, callback.message)
            await edit_admin_menu(
                callback,
                "أرسل StringSession لحساب مساعدك في هذه المحادثة الخاصة فقط. "
                "تصل الجلسة عبر محادثة تيليجرام عادية؛ ستُحذف الرسالة فور استلامها "
                "وتُخزن الجلسة مشفرة في قاعدة البيانات. "
                "لا ترسل رمز تسجيل الدخول أو كلمة مرور التحقق بخطوتين. "
                "أرسل /cancel للإلغاء.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        if action == "session_replace" and len(parts) == 3 and parts[2].isdigit():
            async with database.session() as session:
                account = await session.get(AssistantSession, int(parts[2]))
            if account is None:
                if callback.message:
                    await edit_admin_menu(
                        callback,
                        "جلسة الحساب غير موجودة.",
                        admin_back_keyboard("admin:sessions"),
                    )
                return
            await state.set_state(AdminState.assistant_session)
            await state.update_data(
                assistant_session_mode="replace",
                assistant_session_id=account.id,
            )
            if callback.message:
                await remember_panel(state, callback.message)
            assignment = (
                f"المخصصة للبوت #{account.assigned_bot_id}"
                if account.assigned_bot_id
                else "المتاحة"
            )
            await edit_admin_menu(
                callback,
                f"أرسل StringSession الجديدة للحساب {account.telegram_id} ({assignment}). "
                "ستُحذف رسالة الجلسة فور استلامها، ويعاد تشغيل البوت العامل لتطبيقها. "
                "أرسل /cancel للإلغاء.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        if action == "broadcast":
            await state.set_state(AdminState.broadcast_message)
            if callback.message:
                await remember_panel(state, callback.message)
                await edit_admin_menu(
                    callback,
                    "أرسل الرسالة أو الوسائط لنسخها إلى الموافقين في البوتات المجانية. "
                    "للإلغاء أرسل /cancel.",
                    admin_back_keyboard(),
                )
            return
        if action == "factory_broadcast":
            await state.set_state(AdminState.factory_broadcast_message)
            if callback.message:
                await remember_panel(state, callback.message)
            await edit_admin_menu(
                callback,
                "- الاذاعة المرسله تكون داخل الصانع, ارسل محتوى الاذاعة :)",
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🔴 الغاء",
                                callback_data="admin:broadcast_cancel",
                            )
                        ]
                    ]
                ),
            )
            return
        if action == "broadcast_cancel":
            await state.clear()
            await edit_admin_menu(
                callback,
                "تم إلغاء الإذاعة والعودة إلى لوحة الإدارة.",
                await current_dashboard_keyboard(callback.from_user.id),
            )
            return

        if callback.message:
            await edit_admin_menu(
                callback, "القسم المطلوب غير معروف.", admin_back_keyboard()
            )

    @router.message(AdminState.add_admin_id)
    async def add_factory_admin(message: Message, state: FSMContext) -> None:
        if not message.from_user or message.from_user.id not in settings.admin_ids:
            await state.clear()
            return
        value = (message.text or "").strip()
        if value == "/cancel":
            await state.clear()
            text, markup, _ = await factory_admins_panel(can_manage=True)
            await message.answer("تم إلغاء إضافة الأدمن.\n" + text, reply_markup=markup)
            return
        if message.chat.type != "private":
            await message.answer("أرسل ايدي المستخدم في المحادثة الخاصة مع بوت الصانع.")
            return
        if not value.isdigit() or int(value) <= 0:
            await message.answer("أرسل ايدي تيليجرام رقميًا موجبًا أو /cancel للإلغاء.")
            return
        user_id = int(value)
        if user_id in settings.admin_ids:
            await message.answer("هذا المستخدم مالك مُعرّف مسبقًا ولا يمكن إضافته مرة أخرى.")
            return
        async with database.session() as session:
            existing = await session.get(FactoryAdmin, user_id)
            if existing is not None:
                await message.answer("هذا المستخدم أدمن بالفعل.")
                await state.clear()
                return

        username = None
        try:
            target = await message.bot.get_chat(user_id)
            if target.type != "private":
                await message.answer("المعرف لا يعود إلى حساب مستخدم خاص.")
                return
            username = target.username
        except TelegramAPIError:
            logger.warning(
                "تعذر جلب اسم مستخدم الأدمن الجديد %s؛ سيعرض رقمه بدلاً منه",
                user_id,
                exc_info=True,
            )
        await state.set_state(AdminState.admin_add_confirmation)
        await state.update_data(
            pending_admin_id=user_id,
            pending_admin_username=username,
        )
        await edit_tracked_panel(
            message,
            state,
            "- هل تريد منح هذا الادمن صلاحيات التحكم بالبوتات المرفوعه بالصانع ؟",
            admin_add_permissions_keyboard(),
        )

    @router.message(AdminState.assistant_session)
    async def save_assistant_session(message: Message, state: FSMContext) -> None:
        if not message.from_user or not is_admin(message.from_user.id, settings):
            await state.clear()
            return
        value = (message.text or "").strip()
        if value == "/cancel":
            await state.clear()
            text, markup = await assistant_sessions_keyboard()
            await edit_tracked_panel(message, state, "تم الإلغاء.\n" + text, markup)
            return
        if message.chat.type != "private":
            try:
                await message.delete()
            except TelegramAPIError:
                logger.exception(
                    "تعذر حذف رسالة جلسة الحساب المساعد من محادثة غير خاصة"
                )
            await edit_tracked_panel(
                message,
                state,
                "لأمان الجلسة، أرسلها في محادثة خاصة مع بوت الصانع فقط.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        if not value:
            await edit_tracked_panel(
                message,
                state,
                "أرسل StringSession كنص، أو /cancel للإلغاء.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        try:
            await message.delete()
        except TelegramAPIError:
            logger.exception(
                "تعذر حذف رسالة جلسة الحساب المساعد من محادثة الإدارة"
            )
            await state.clear()
            await edit_tracked_panel(
                message,
                state,
                "تعذر حذف الرسالة؛ لم تُحفظ الجلسة. احذف الرسالة يدويًا ثم أعد المحاولة.",
                admin_back_keyboard("admin:sessions"),
            )
            return

        telegram_id: int | None = None
        assigned_bot_id: int | None = None
        client = None
        try:
            client = TelegramClient(
                StringSession(value),
                settings.telegram_api_id,
                settings.telegram_api_hash,
            )
            await client.connect()
            if not await client.is_user_authorized():
                raise ValueError("الجلسة غير مصرح بها.")
            account_identity = await client.get_me()
            if account_identity is None:
                raise ValueError("تعذر تحديد الحساب المرتبط بالجلسة.")
            telegram_id = account_identity.id
        except Exception as error:
            logger.warning(
                "رفض جلسة حساب مساعد واردة بعد فشل التحقق (%s)",
                type(error).__name__,
            )
            await edit_tracked_panel(
                message,
                state,
                "تعذر التحقق من الجلسة. تأكد أنها StringSession صالحة ومصرح بها ثم أعد المحاولة.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        finally:
            if client is not None and client.is_connected():
                try:
                    await client.disconnect()
                except Exception:
                    logger.warning("تعذر إغلاق اتصال التحقق من جلسة الحساب المساعد")

        if telegram_id is None:
            await edit_tracked_panel(
                message,
                state,
                "تعذر تحديد الحساب المرتبط بالجلسة؛ لم تُحفظ.",
                admin_back_keyboard("admin:sessions"),
            )
            return
        data = await state.get_data()
        mode = data.get("assistant_session_mode")
        account_id = data.get("assistant_session_id")
        encrypted = Fernet(settings.fernet_key.encode()).encrypt(
            value.encode()
        ).decode()
        try:
            async with database.session() as session:
                if mode == "replace" and isinstance(account_id, int):
                    account = await session.get(AssistantSession, account_id)
                    if account is None:
                        raise LookupError("جلسة الحساب المراد استبدالها غير موجودة.")
                    duplicate = await session.scalar(
                        select(AssistantSession.id).where(
                            AssistantSession.telegram_id == telegram_id,
                            AssistantSession.id != account_id,
                        )
                    )
                    if duplicate:
                        raise ValueError(
                            "هذا الحساب مسجل بالفعل ضمن جلسة أخرى."
                        )
                    account.telegram_id = telegram_id
                    account.encrypted_session = encrypted
                    if account.assigned_bot_id is not None:
                        assigned_bot_id = account.assigned_bot_id
                        assigned_bot = await session.get(
                            BotRecord, account.assigned_bot_id
                        )
                        if assigned_bot is not None:
                            assigned_bot.encrypted_voice_session = encrypted
                elif mode == "add":
                    duplicate = await session.scalar(
                        select(AssistantSession.id).where(
                            AssistantSession.telegram_id == telegram_id
                        )
                    )
                    if duplicate:
                        raise ValueError(
                            "هذا الحساب مسجل بالفعل؛ اختره من القائمة لاستبدال جلسته."
                        )
                    session.add(
                        AssistantSession(
                            telegram_id=telegram_id,
                            encrypted_session=encrypted,
                        )
                    )
                else:
                    raise RuntimeError("انتهت جلسة إدارة الحسابات المساعدة.")
                await session.commit()
        except (IntegrityError, LookupError, ValueError, RuntimeError) as error:
            await state.clear()
            text, markup = await assistant_sessions_keyboard()
            await edit_tracked_panel(
                message, state, f"تعذر حفظ جلسة الحساب: {error}\n{text}", markup
            )
            return

        restart_failures: list[int] = []
        restarted: list[int] = []
        assignment_error: str | None = None
        if mode == "add":
            try:
                assigned_bot_ids = (
                    await manager.assign_available_assistant_sessions()
                )
            except Exception:
                logger.exception(
                    "تعذر تخصيص جلسة الحساب المساعد الجديدة للبوتات المفعلة"
                )
                assigned_bot_ids = []
                assignment_error = (
                    "تعذر تخصيص الجلسة للبوتات تلقائياً؛ راجع سجل الصانع."
                )
        else:
            assigned_bot_ids = [assigned_bot_id] if assigned_bot_id is not None else []
        for bot_id in assigned_bot_ids:
            try:
                if await manager.restart_bot(bot_id):
                    restarted.append(bot_id)
            except Exception:
                logger.exception(
                    "تعذر إعادة تشغيل البوت %s بعد تحديث جلسة الحساب المساعد",
                    bot_id,
                )
                restart_failures.append(bot_id)

        await state.clear()
        text, markup = await assistant_sessions_keyboard()
        result = f"تم التحقق من جلسة الحساب {telegram_id} وحفظها مشفرة."
        if assigned_bot_ids:
            result += f"\nتم تخصيصها للبوتات: {', '.join(map(str, assigned_bot_ids))}."
        if restarted:
            result += f"\nأعيد تشغيل البوتات لتطبيق الجلسات: {', '.join(map(str, restarted))}."
        if restart_failures:
            result += (
                "\nتعذر إعادة تشغيل البوتات التالية؛ راجع سجلاتها: "
                + ", ".join(map(str, restart_failures))
                + "."
            )
        if assignment_error:
            result += f"\n{assignment_error}"
        await edit_tracked_panel(
            message,
            state,
            f"{result}\n{text}",
            markup,
        )

    @router.message(AdminState.payment_details)
    async def save_payment_details(message: Message, state: FSMContext) -> None:
        if not message.from_user or not is_admin(message.from_user.id, settings):
            await state.clear()
            return
        if (message.text or "").strip() == "/cancel":
            await edit_tracked_panel(
                message,
                state,
                "تم الإلغاء.",
                admin_payment_settings_keyboard(),
            )
            await state.clear()
            return
        data = await state.get_data()
        kind = data.get("payment_kind")
        allowed = {
            "visa": "VISA/Master Card",
            "binance": "Binance ID",
            "stars": "نجوم",
            "asiacell": "اسياسيل",
            "agent": "شحن عبر الوكيل",
        }
        if kind not in allowed:
            await edit_tracked_panel(
                message,
                state,
                "انتهت جلسة إعداد الدفع؛ أعد المحاولة من لوحة الإدارة.",
                admin_payment_settings_keyboard(),
            )
            await state.clear()
            return
        details = (message.text or "").strip()
        stars_amount = None
        payload = details
        if kind == "stars":
            first, separator, remainder = details.partition("\n")
            if not first.isdigit() or not 1 <= int(first) <= 100000:
                await edit_tracked_panel(
                    message,
                    state,
                    "أرسل عدداً صحيحاً من 1 إلى 100000 نجمة في السطر الأول، ثم التفاصيل اختيارياً.",
                    admin_back_keyboard("admin:payment_settings"),
                )
                return
            stars_amount = int(first)
            payload = remainder.strip() if separator else ""
        if not payload and kind != "stars":
            await edit_tracked_panel(
                message,
                state,
                "أرسل تفاصيل الدفع أو /cancel للإلغاء.",
                admin_back_keyboard("admin:payment_settings"),
            )
            return
        agent_url = urlsplit(payload) if kind == "agent" else None
        if kind == "agent" and not (
            (
                agent_url is not None
                and agent_url.scheme == "https"
                and bool(agent_url.netloc)
            )
            or re.fullmatch(r"@[A-Za-z0-9_]{5,32}", payload)
        ):
            await edit_tracked_panel(
                message,
                state,
                "أرسل رابط وكيل HTTPS أو اسم مستخدم يبدأ بـ @.",
                admin_back_keyboard("admin:payment_settings"),
            )
            return
        await state.update_data(
            payment_payload=payload, payment_stars_amount=stars_amount
        )
        confirm_keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🟢 تأكيد ✓", callback_data="admin:payment_confirm"
                    ),
                    InlineKeyboardButton(
                        text="🔴 تعديل ✐", callback_data="admin:payment_redo"
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="🔴 رجوع ◄", callback_data="admin:payment_settings"
                    )
                ],
            ]
        )
        await edit_tracked_panel(
            message,
            state,
            "تم استلام التفاصيل. اختر تأكيد للحفظ أو تعديل لإرسال تفاصيل جديدة.",
            confirm_keyboard,
        )

    @router.message(AdminState.add_subscription)
    async def save_subscription(message: Message, state: FSMContext, bot: Bot) -> None:
        if not message.from_user or not is_admin(message.from_user.id, settings):
            await state.clear()
            return
        value = (message.text or "").strip()
        if value == "/cancel":
            await edit_tracked_panel(
                message,
                state,
                "تم الإلغاء.",
                admin_back_keyboard("admin:subs"),
            )
            await state.clear()
            return
        address = value
        invite_link = ""
        if " " in value:
            address, invite_link = value.split(maxsplit=1)
            if not CHAT_ID_PATTERN.fullmatch(address):
                await edit_tracked_panel(
                    message,
                    state,
                    "للقنوات الخاصة أرسل: <chat_id> <رابط_الدعوة_HTTPS>.",
                    admin_back_keyboard("admin:subs"),
                )
                return
            if not invite_link.startswith(("https://t.me/", "https://telegram.me/")):
                await edit_tracked_panel(
                    message,
                    state,
                    "رابط الدعوة يجب أن يكون رابط تيليجرام HTTPS.",
                    admin_back_keyboard("admin:subs"),
                )
                return
        if address.startswith(("https://t.me/", "https://telegram.me/")):
            address = address.rsplit("/", 1)[-1]
            if address.startswith("+") or address.startswith("joinchat"):
                await edit_tracked_panel(
                    message,
                    state,
                    "للقنوات الخاصة استخدم /addsub <chat_id> <invite_link>.",
                    admin_back_keyboard("admin:subs"),
                )
                return
            address = "@" + address.lstrip("@")
        if not CHAT_ID_PATTERN.fullmatch(address):
            await edit_tracked_panel(
                message,
                state,
                "أرسل @username أو رابط قناة عامة صالحاً.",
                admin_back_keyboard("admin:subs"),
            )
            return
        try:
            chat = await bot.get_chat(address)
            can_check_members = await _factory_bot_is_channel_admin(bot, chat.id)
        except TelegramAPIError:
            await edit_tracked_panel(
                message,
                state,
                "تعذر الوصول للقناة. أضف بوت الصانع كمشرف فيها، ثم أعد إرسال المعرف.",
                admin_back_keyboard("admin:subs"),
            )
            return
        if not can_check_members:
            await edit_tracked_panel(
                message,
                state,
                "يجب إضافة بوت الصانع المركزي إلى القناة كمشرف حتى يتمكن من "
                "فحص عضوية المستخدمين.",
                admin_back_keyboard("admin:subs"),
            )
            return
        chat_id = str(chat.id)
        invite_link = invite_link or (
            f"https://t.me/{chat.username}"
            if chat.username
            else getattr(chat, "invite_link", None)
        )
        if not invite_link:
            await edit_tracked_panel(
                message,
                state,
                "تعذر تحديد رابط القناة؛ استخدم /addsub <chat_id> <invite_link>.",
                admin_back_keyboard("admin:subs"),
            )
            return
        async with database.session() as session:
            existing = await session.scalar(
                select(ForcedSub).where(ForcedSub.chat_id == chat_id)
            )
            if existing:
                existing.invite_link = invite_link
                existing.title = chat.title or chat.username or chat_id
            else:
                session.add(
                    ForcedSub(
                        chat_id=chat_id,
                        invite_link=invite_link,
                        title=chat.title or chat.username or chat_id,
                    )
                )
            await session.commit()
        restart_message = await restart_free_bots_for_subscription_change()
        await edit_tracked_panel(
            message,
            state,
            f"تمت إضافة قناة {chat.title or chat_id} للاشتراك الإجباري المجاني. "
            "ستظهر لمستخدمي البوتات المجانية، ويتحقق بوت الصانع المركزي من "
            "اشتراك كل مستخدم عند استخدام البوت."
            + restart_message,
            admin_back_keyboard("admin:subs"),
        )
        await state.clear()

    @router.callback_query(F.data.startswith("review:"))
    async def review_payment(callback: CallbackQuery) -> None:
        if not is_admin(callback.from_user.id, settings):
            await callback.answer("هذه العملية خاصة بالإدارة.", show_alert=True)
            return
        parts = (callback.data or "").split(":")
        if len(parts) != 3 or parts[1] not in {"approve", "reject"} or not parts[2].isdigit():
            await callback.answer("طلب الدفع غير صالح.", show_alert=True)
            return
        request_id = int(parts[2])
        approved = parts[1] == "approve"
        async with database.session() as session:
            payment_request = await session.get(PaymentRequest, request_id)
            if payment_request is None or payment_request.status != "pending":
                await callback.answer("تمت مراجعة هذا الطلب مسبقاً.", show_alert=True)
                return
            payment_request.status = "approved" if approved else "rejected"
            payment_request.reviewed_by = callback.from_user.id
            payment_request.reviewed_at = utc_now()
            payment_request.receipt_file_id = None
            if approved:
                user = await session.scalar(
                    select(User).where(User.telegram_id == payment_request.user_id)
                )
                if user is None:
                    session.add(User(telegram_id=payment_request.user_id))
                    await session.flush()
                grant = await session.scalar(
                    select(PaidGrant).where(
                        PaidGrant.user_id == payment_request.user_id
                    )
                )
                if grant is None:
                    session.add(PaidGrant(user_id=payment_request.user_id))
            user_id = payment_request.user_id
            await session.commit()
        await callback.answer("تمت مراجعة الطلب.")
        if callback.message:
            await callback.message.edit_caption(
                caption=f"تم {'قبول' if approved else 'رفض'} طلب الدفع رقم {request_id}.",
                reply_markup=None,
            )
        try:
            await callback.bot.send_message(
                user_id,
                "• تم تأكيد الدفع يمكنك المتابعة ✓"
                if approved
                else "• رُفضت عملية الدفع، تحقق من المعلومات وأعد المحاولة ✘",
                reply_markup=(
                    InlineKeyboardMarkup(
                        inline_keyboard=[
                            [
                                InlineKeyboardButton(
                                    text="🟢 متابعة للقوالب المدفوعة",
                                    callback_data="create:paid",
                                )
                            ]
                        ]
                    )
                    if approved
                    else None
                ),
            )
        except TelegramAPIError:
            logger.exception(
                "تعذر إرسال نتيجة مراجعة الدفع إلى المستخدم %s", user_id
            )

    @router.message(Command("templates"))
    async def templates(message: Message, state: FSMContext) -> None:
        if not is_factory_owner(message.from_user.id, settings):
            await message.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
            )
            return
        templates_list = loader.list_templates()
        await show_admin_list(
            message,
            state,
            "• قائمة القوالب المرفوعة بالصانع:",
            admin_template_list_keyboard(templates_list),
        )

    @router.message(Command("bots"))
    async def list_bots(message: Message, state: FSMContext) -> None:
        if not has_bot_management(message.from_user.id, settings):
            await message.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
            )
            return
        async with database.session() as session:
            records = (
                await session.execute(select(BotRecord).order_by(BotRecord.id))
            ).scalars().all()
        body = "\n".join(
            f"{item.id}: @{item.username} [{item.tier}] {item.status}"
            for item in records
        )
        await show_admin_list(
            message,
            state,
            body or "لا توجد بوتات مسجلة.",
            admin_back_keyboard("admin:open"),
        )

    @router.message(Command("stopbot"))
    async def stop_bot(message: Message) -> None:
        if not has_bot_management(message.from_user.id, settings):
            await message.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
            )
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not parts[1].isdigit():
            await message.answer("الاستخدام: /stopbot <id>")
            return
        try:
            await manager.stop_bot(int(parts[1]))
        except LookupError as error:
            await message.answer(str(error))
            return
        await message.answer("تم إيقاف البوت وتعطيل إعادة تشغيله التلقائية.")

    @router.message(Command("startbot"))
    async def start_bot(message: Message) -> None:
        if not has_bot_management(message.from_user.id, settings):
            await message.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
            )
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not parts[1].isdigit():
            await message.answer("الاستخدام: /startbot <id>")
            return
        try:
            await manager.start_stored_bot(int(parts[1]))
        except (InvalidToken, LookupError, OSError, RuntimeError, ValueError) as error:
            await message.answer(f"تعذر تشغيل البوت: {error}")
            return
        await message.answer("تم تفعيل البوت.")

    @router.message(Command("deletetemplate"))
    async def delete_template(message: Message) -> None:
        if not is_factory_owner(message.from_user.id, settings):
            await message.answer(
                "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
            )
            return
        value = (message.text or "").partition(" ")[2].strip()
        tier, separator, name = value.partition(":")
        if not separator:
            await message.answer("الاستخدام: /deletetemplate <free|paid>:<name>")
            return
        async with database.session() as session:
            in_use = await session.scalar(
                select(BotRecord.id)
                .where(
                    BotRecord.tier == tier,
                    BotRecord.template_name == name,
                    BotRecord.enabled.is_(True),
                )
                .limit(1)
            )
        if in_use:
            await message.answer("لا يمكن حذف قالب تستخدمه بوتات نشطة.")
            return
        try:
            loader.delete(tier, name)
        except (ValueError, FileNotFoundError) as error:
            await message.answer(f"تعذر حذف القالب: {error}")
            return
        await message.answer(f"تم حذف القالب {tier}:{name}.")

    @router.message(Command("addsub"))
    async def add_sub(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        parts = (message.text or "").split(maxsplit=2)
        if len(parts) != 3 or not CHAT_ID_PATTERN.fullmatch(parts[1]):
            await message.answer("الاستخدام: /addsub <chat_id|@channel> <invite_link>")
            return
        if not parts[2].startswith(("https://t.me/", "https://telegram.me/")):
            await message.answer("رابط الدعوة يجب أن يكون رابط تيليجرام HTTPS.")
            return
        try:
            chat = await bot.get_chat(parts[1])
            can_check_members = await _factory_bot_is_channel_admin(bot, chat.id)
        except TelegramAPIError:
            logger.exception(
                "تعذر التحقق من عضوية بوت الصانع في قناة الاشتراك %s",
                parts[1],
            )
            await message.answer(
                "تعذر الوصول للقناة أو التحقق من صلاحيات بوت الصانع. "
                "أضفه إلى القناة كمشرف ثم حاول مجدداً."
            )
            return
        if not can_check_members:
            await message.answer(
                "يجب إضافة بوت الصانع المركزي إلى القناة كمشرف حتى يتمكن من "
                "فحص عضوية المستخدمين."
            )
            return
        async with database.session() as session:
            chat_id = str(chat.id)
            existing = await session.scalar(select(ForcedSub).where(ForcedSub.chat_id == chat_id))
            if existing:
                existing.invite_link = parts[2]
                existing.title = chat.title or chat.username or chat_id
            else:
                session.add(
                    ForcedSub(
                        chat_id=chat_id,
                        invite_link=parts[2],
                        title=chat.title or chat.username or chat_id,
                    )
                )
            await session.commit()
        restart_message = await restart_free_bots_for_subscription_change()
        await message.answer(
            "تم تحديث قناة الاشتراك الإجباري للبوتات المجانية، ويسري التعديل "
            "مباشرة عند الفحص التالي بواسطة بوت الصانع المركزي."
            + restart_message
        )

    @router.message(Command("delsub"))
    async def delete_sub(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not CHAT_ID_PATTERN.fullmatch(parts[1]):
            await message.answer("الاستخدام: /delsub <chat_id|@channel>")
            return
        async with database.session() as session:
            existing = await session.scalar(select(ForcedSub).where(ForcedSub.chat_id == parts[1]))
            if existing:
                await session.delete(existing)
                await session.commit()
        restart_message = await restart_free_bots_for_subscription_change()
        await message.answer(
            "تم حذف القناة؛ يسري التعديل مباشرة عند الفحص التالي."
            + restart_message
        )

    @router.message(Command("payments"))
    async def list_payments(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        async with database.session() as session:
            methods = (
                await session.execute(select(PaymentMethod).order_by(PaymentMethod.id))
            ).scalars().all()
        text = "\n".join(
            f"{item.id}. {'🟢' if item.enabled else '🔴'} {item.title} "
            f"[{item.kind}]"
            + (f" — {item.stars_amount} XTR" if item.kind == "stars" else f" — {item.payload}")
            for item in methods
        )
        await message.answer(text or "لا توجد وسائل دفع مضافة.")

    @router.message(Command("paymentadd"))
    async def add_payment(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        try:
            parts = shlex.split(message.text or "")
        except ValueError:
            parts = []
        if len(parts) != 4:
            await message.answer(
                'الاستخدام:\n/paymentadd stars "العنوان" <عدد_النجوم>\n'
                '/paymentadd link "العنوان" <رابط_https>\n'
                '/paymentadd contact "العنوان" <رابط_تواصل_https>'
            )
            return
        _, kind, title, value = parts
        kind = kind.casefold()
        if kind not in {"stars", "link", "contact"} or len(title) > 64:
            await message.answer("نوع الوسيلة غير صالح أو العنوان طويل.")
            return
        stars_amount = None
        payload = ""
        if kind == "stars":
            if not value.isdigit() or not 1 <= int(value) <= 100000:
                await message.answer("قيمة النجوم يجب أن تكون بين 1 و100000.")
                return
            stars_amount = int(value)
        else:
            if not value.startswith("https://") or len(value) > 512:
                await message.answer("استخدم رابط HTTPS صالحاً للدفع أو التواصل.")
                return
            payload = value
        async with database.session() as session:
            session.add(
                PaymentMethod(
                    title=title,
                    kind=kind,
                    payload=payload,
                    stars_amount=stars_amount,
                    enabled=True,
                )
            )
            await session.commit()
        await message.answer(f"تمت إضافة وسيلة الدفع 🟢 {title}.")

    @router.message(Command("paymentdel"))
    async def delete_payment(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not parts[1].isdigit():
            await message.answer("الاستخدام: /paymentdel <id>")
            return
        async with database.session() as session:
            method = await session.get(PaymentMethod, int(parts[1]))
            if method:
                await session.delete(method)
                await session.commit()
        await message.answer("تم حذف وسيلة الدفع 🔴.")

    @router.message(Command("paymenttoggle"))
    async def toggle_payment(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not parts[1].isdigit():
            await message.answer("الاستخدام: /paymenttoggle <id>")
            return
        async with database.session() as session:
            method = await session.get(PaymentMethod, int(parts[1]))
            if method:
                method.enabled = not method.enabled
                await session.commit()
                enabled = method.enabled
            else:
                enabled = None
        await message.answer(
            "تم تفعيل وسيلة الدفع 🟢." if enabled else
            "تم تعطيل وسيلة الدفع 🔴." if enabled is not None else
            "لم يتم العثور على وسيلة الدفع."
        )

    @router.message(Command("grantpaid"))
    async def grant_paid(message: Message) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) != 2 or not parts[1].isdigit():
            await message.answer("الاستخدام: /grantpaid <telegram_user_id>")
            return
        user_id = int(parts[1])
        async with database.session() as session:
            user = await session.scalar(select(User).where(User.telegram_id == user_id))
            if user is None:
                session.add(User(telegram_id=user_id))
                await session.flush()
            grant = await session.get(PaidGrant, user_id)
            if grant is None:
                session.add(PaidGrant(user_id=user_id))
                await session.commit()
        await message.answer("تم تفعيل القسم المدفوع للمستخدم.")

    @router.message(Command("broadcast"))
    async def begin_broadcast(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id, settings):
            return
        await state.set_state(AdminState.broadcast_message)
        panel = await message.answer(
            "أرسل الرسالة أو الوسائط لنسخها إلى الموافقين في البوتات المجانية."
        )
        await remember_panel(state, panel)

    @router.message(AdminState.broadcast_message)
    async def finish_broadcast(message: Message, state: FSMContext, bot: Bot) -> None:
        if not is_admin(message.from_user.id, settings):
            await state.clear()
            return
        if (message.text or "").strip() == "/cancel":
            await edit_tracked_panel(message, state, "تم إلغاء الإذاعة.")
            await state.clear()
            return
        attempted, delivered = await broadcast_free_users(
            database, bot, message.from_user.id, message
        )
        await edit_tracked_panel(
            message, state, f"اكتملت الإذاعة: أُرسلت {delivered} من أصل {attempted}."
        )
        await state.clear()

    @router.message(AdminState.factory_broadcast_message)
    async def finish_factory_broadcast(
        message: Message, state: FSMContext, bot: Bot
    ) -> None:
        if not message.from_user or not is_admin(message.from_user.id, settings):
            await state.clear()
            return
        if (message.text or "").strip() in {"/cancel", "الغاء", "إلغاء"}:
            await state.clear()
            await edit_tracked_panel(
                message,
                state,
                "تم إلغاء الإذاعة والعودة إلى لوحة الإدارة.",
                await current_dashboard_keyboard(message.from_user.id),
            )
            return
        if not (
            message.text
            or message.photo
            or message.video
            or message.animation
        ):
            await edit_tracked_panel(
                message,
                state,
                "- ارسل نصاً أو صورة أو فيديو أو GIF، أو اضغط «الغاء».",
                InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🔴 الغاء",
                                callback_data="admin:broadcast_cancel",
                            )
                        ]
                    ]
                ),
            )
            return
        attempted, delivered = await broadcast_factory_users(
            database, bot, message.from_user.id, message
        )
        await edit_tracked_panel(
            message,
            state,
            f"اكتملت إذاعة الصانع: أُرسلت {delivered} من أصل {attempted} مستخدم وافقوا على الإذاعات.",
            await current_dashboard_keyboard(message.from_user.id),
        )
        await state.clear()

    @router.message(F.document)
    async def upload_template(
        message: Message, bot: Bot, state: FSMContext
    ) -> None:
        if not message.from_user or not is_factory_owner(
            message.from_user.id, settings
        ):
            if message.from_user and is_admin(message.from_user.id, settings):
                await message.answer(
                    "- ممنوع الوصول لهذه الاقسام، مخصصه للادارة فقط."
                )
            return
        description = (message.caption or "").strip().split(":", maxsplit=1)
        if len(description) != 2 or description[0] not in ("free", "paid"):
            await edit_tracked_panel(
                message,
                state,
                "أرفق ZIP أو ملف .py بوصف free:name أو paid:name.",
                admin_back_keyboard(),
            )
            return
        file_name = message.document.file_name or ""
        if Path(file_name).suffix.casefold() not in {".zip", ".py"}:
            await edit_tracked_panel(
                message,
                state,
                "ارفع أرشيف ZIP كاملاً أو ملف Python بامتداد .py.",
                admin_back_keyboard(),
            )
            return
        max_size = MAX_ARCHIVE_BYTES if file_name.lower().endswith(".zip") else MAX_FILE_BYTES
        if message.document.file_size and message.document.file_size > max_size:
            await edit_tracked_panel(
                message, state, "حجم الملف يتجاوز الحد المسموح.", admin_back_keyboard()
            )
            return
        with tempfile.TemporaryDirectory(prefix="factory-template-") as temporary:
            upload_path = Path(temporary) / Path(file_name).name
            try:
                await bot.download(message.document, destination=upload_path)
            except (OSError, TelegramAPIError):
                await edit_tracked_panel(
                    message,
                    state,
                    "تعذر تنزيل ملف القالب من تيليجرام؛ أعد المحاولة.",
                    admin_back_keyboard(),
                )
                return
            try:
                await edit_tracked_panel(
                    message,
                    state,
                    "• تم استلام المشروع، يجري فحص ملفاته وإضافتها إلى القوالب.",
                    admin_back_keyboard(),
                )
                installed = loader.install_upload(description[0], description[1], upload_path)
            except (OSError, ValueError, FileExistsError, zipfile.BadZipFile) as error:
                await edit_tracked_panel(
                    message,
                    state,
                    f"تعذر تثبيت القالب: {error}",
                    admin_back_keyboard(),
                )
                return
        await edit_tracked_panel(
            message,
            state,
            f"حُفظ المشروع {installed.tier}:{installed.name} في مجلد مستقل.\n"
            "سيُنشأ مجلد تشغيل وبيئة اعتماديات منفصلان عند تشغيل نسخة البوت. "
            "يجب رفع ملفات المشروع الموثوقة فقط.",
            admin_back_keyboard(),
        )
        await state.clear()

    return router


def create_router(
    database: Database,
    loader: TemplateLoader,
    settings: Settings,
    manager: ProcessManager,
) -> Router:
    return setup_admin_handlers(database, loader, settings, manager)
