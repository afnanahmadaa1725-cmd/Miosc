"""إعدادات المصنع؛ لا تُحفظ الأسرار داخل الشيفرة المصدرية."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from pathlib import PurePosixPath, PureWindowsPath

from core.fernet_compat import Fernet
from dotenv import load_dotenv
from sqlalchemy.engine import make_url

PROJECT_ROOT = Path(__file__).resolve().parent
load_dotenv(PROJECT_ROOT / ".env")


def _project_path(variable: str, default: str) -> Path:
    value = os.environ.get(variable, default).strip() or default
    windows_path = PureWindowsPath(value)
    normalized = value.replace("\\", "/")
    posix_path = PurePosixPath(normalized)
    path = Path(normalized)
    if (
        windows_path.is_absolute()
        or windows_path.drive
        or posix_path.is_absolute()
        or path.is_absolute()
    ):
        value = windows_path.name if windows_path.drive else path.name
        path = Path(value)
    if not value or path == Path(".") or ".." in path.parts:
        raise RuntimeError(f"{variable} يجب أن يكون مساراً نسبياً داخل مجلد المشروع.")
    resolved = (PROJECT_ROOT / path).resolve()
    try:
        resolved.relative_to(PROJECT_ROOT)
    except ValueError as error:
        raise RuntimeError(
            f"{variable} يجب أن يشير إلى مسار داخل مجلد المشروع."
        ) from error
    return resolved


def _project_database_url(value: str) -> str:
    url = make_url(value)
    if (
        url.get_backend_name() != "sqlite"
        or not url.database
        or url.database == ":memory:"
    ):
        return value

    database = url.database
    windows_path = PureWindowsPath(database)
    normalized = database.replace("\\", "/")
    posix_path = PurePosixPath(normalized)
    path = Path(normalized)
    if (
        windows_path.is_absolute()
        or windows_path.drive
        or posix_path.is_absolute()
        or path.is_absolute()
    ):
        path = Path(windows_path.name if windows_path.drive else path.name)
    if ".." in path.parts:
        raise RuntimeError(
            "مسار قاعدة SQLite يجب أن يكون نسبياً داخل مجلد المشروع."
        )
    resolved = (PROJECT_ROOT / path).resolve()
    try:
        resolved.relative_to(PROJECT_ROOT)
    except ValueError as error:
        raise RuntimeError(
            "مسار قاعدة SQLite يجب أن يكون داخل مجلد المشروع."
        ) from error
    return url.set(database=str(resolved)).render_as_string(hide_password=False)


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: frozenset[int]
    database_url: str
    fernet_key: str
    data_dir: Path
    templates_dir: Path
    logs_dir: Path
    youtube_cookies_file: Path | None
    telegram_api_id: int
    telegram_api_hash: str
    developer_channel: str
    factory_updates_channel: str
    managed_admin_ids: set[int] = field(default_factory=set)
    managed_bot_admin_ids: set[int] = field(default_factory=set)

    def is_admin(self, user_id: int) -> bool:
        return user_id in self.admin_ids or user_id in self.managed_admin_ids

    def can_manage_bots(self, user_id: int) -> bool:
        return user_id in self.admin_ids or user_id in self.managed_bot_admin_ids

    @property
    def all_admin_ids(self) -> frozenset[int]:
        return self.admin_ids | self.managed_admin_ids


def load_settings() -> Settings:
    """اقرأ متغيرات البيئة وتحقق من الإعدادات الإلزامية."""
    token = os.environ.get("FACTORY_BOT_TOKEN", "").strip()
    key = os.environ.get("FACTORY_FERNET_KEY", "").strip()
    admin_ids = frozenset(
        int(value.strip())
        for value in os.environ.get("FACTORY_ADMIN_IDS", "").split(",")
        if value.strip()
    )
    api_id = os.environ.get("TELEGRAM_API_ID", "").strip()
    api_hash = os.environ.get("TELEGRAM_API_HASH", "").strip()
    required = {
        "FACTORY_BOT_TOKEN": token,
        "FACTORY_FERNET_KEY": key,
        "FACTORY_ADMIN_IDS": admin_ids,
        "TELEGRAM_API_ID": api_id,
        "TELEGRAM_API_HASH": api_hash,
    }
    missing = [name for name, value in required.items() if not value]
    if missing:
        raise RuntimeError(f"إعدادات مطلوبة غير موجودة: {', '.join(missing)}")
    try:
        Fernet(key.encode("ascii"))
    except (UnicodeEncodeError, ValueError) as error:
        raise RuntimeError("FACTORY_FERNET_KEY يجب أن يكون مفتاح Fernet صالحاً.") from error
    telegram_api_id = int(api_id)
    if telegram_api_id <= 0:
        raise RuntimeError("TELEGRAM_API_ID يجب أن يكون عدداً موجباً.")
    return Settings(
        bot_token=token,
        admin_ids=admin_ids,
        database_url=_project_database_url(
            os.environ.get("FACTORY_DATABASE_URL", "").strip()
            or "sqlite+aiosqlite:///factory.sqlite3"
        ),
        fernet_key=key,
        data_dir=_project_path("FACTORY_DATA_DIR", "generated_bots_data"),
        templates_dir=_project_path("FACTORY_TEMPLATES_DIR", "templates"),
        logs_dir=_project_path("FACTORY_LOGS_DIR", "logs"),
        youtube_cookies_file=(
            _project_path("FACTORY_YT_DLP_COOKIEFILE", "cookies.txt")
            if os.environ.get("FACTORY_YT_DLP_COOKIEFILE", "").strip()
            else None
        ),
        telegram_api_id=telegram_api_id,
        telegram_api_hash=api_hash,
        developer_channel=os.environ.get(
            "FACTORY_DEVELOPER_CHANNEL", "ss_rssb"
        ).strip() or "ss_rssb",
        factory_updates_channel=os.environ.get(
            "FACTORY_UPDATES_CHANNEL", "a_zi63"
        ).strip() or "a_zi63",
    )
