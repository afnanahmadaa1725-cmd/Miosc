"""Verify free-bot subscription requests using the central factory bot."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import timedelta

from sqlalchemy import delete, select, update

from core.telegram_compat import is_telegram_api_error
from database.connection import Database
from database.models import BotRecord, ForcedSub, SubscriptionCheck, utc_now

logger = logging.getLogger(__name__)
CHANNEL_ACCESS_ERROR = (
    "تعذر على بوت الصانع قراءة عضوية إحدى القنوات. "
    "تأكد من إضافة بوت الصانع إلى القناة ومنحه صلاحية مشاهدة الأعضاء."
)


async def _finish_request(
    database: Database,
    request_id: str,
    *,
    missing_chat_ids: list[str] | None = None,
    error: str | None = None,
) -> None:
    async with database.session() as session:
        request = await session.get(SubscriptionCheck, request_id)
        if request and request.status == "processing":
            request.status = "done"
            request.missing_chat_ids = json.dumps(
                missing_chat_ids or [], ensure_ascii=True
            )
            request.error = error
            request.checked_at = utc_now()
            await session.commit()


async def _check_request(
    database: Database, central_bot, request_id: str
) -> None:
    async with database.session() as session:
        request = await session.get(SubscriptionCheck, request_id)
        if request is None or request.status != "processing":
            return
        record = await session.get(BotRecord, request.bot_id)
        if record is None or record.tier != "free" or not record.enabled:
            unavailable = True
            user_id = 0
            channels = []
        else:
            unavailable = False
            user_id = request.user_id
            channels = (
                await session.execute(select(ForcedSub).order_by(ForcedSub.id))
            ).scalars().all()
    if unavailable:
        await _finish_request(
            database,
            request_id,
            error="هذا البوت المجاني غير متاح للتحقق حالياً.",
        )
        return

    missing: list[str] = []
    try:
        for channel in channels:
            chat_id = (
                int(channel.chat_id)
                if channel.chat_id.lstrip("-").isdigit()
                else channel.chat_id
            )
            member = await central_bot.get_chat_member(chat_id, user_id)
            status = getattr(member.status, "value", member.status)
            if status not in {"creator", "administrator", "member"} and not (
                status == "restricted" and member.is_member
            ):
                missing.append(channel.chat_id)
    except Exception as error:
        if not is_telegram_api_error(error):
            raise
        logger.exception(
            "Central factory bot could not check user %s in subscription channel %s",
            user_id,
            channel.chat_id,
        )
        await _finish_request(
            database,
            request_id,
            missing_chat_ids=[item.chat_id for item in channels],
            error=CHANNEL_ACCESS_ERROR,
        )
        return

    await _finish_request(
        database, request_id, missing_chat_ids=missing
    )


async def process_pending_subscription_checks(
    database: Database, central_bot, *, limit: int = 20
) -> int:
    async with database.session() as session:
        expired_before = utc_now() - timedelta(minutes=2)
        stale = await session.execute(
            update(SubscriptionCheck)
            .where(
                SubscriptionCheck.status.in_(("pending", "processing")),
                SubscriptionCheck.created_at < expired_before,
            )
            .values(
                status="done",
                missing_chat_ids="[]",
                error="انتهت مهلة التحقق؛ حاول مرة أخرى.",
                checked_at=utc_now(),
            )
        )
        expired_checks = await session.execute(
            delete(SubscriptionCheck).where(
                SubscriptionCheck.status == "done",
                SubscriptionCheck.checked_at < utc_now() - timedelta(minutes=5),
            )
        )
        if stale.rowcount or expired_checks.rowcount:
            await session.commit()
        request_ids = (
            await session.execute(
                select(SubscriptionCheck.request_id)
                .where(SubscriptionCheck.status == "pending")
                .order_by(SubscriptionCheck.created_at)
                .limit(limit)
            )
        ).scalars().all()

    processed = 0
    for request_id in request_ids:
        async with database.session() as session:
            result = await session.execute(
                update(SubscriptionCheck)
                .where(
                    SubscriptionCheck.request_id == request_id,
                    SubscriptionCheck.status == "pending",
                )
                .values(status="processing")
            )
            if result.rowcount != 1:
                continue
            await session.commit()
        processed += 1
        try:
            await _check_request(database, central_bot, request_id)
        except Exception as error:
            logger.exception(
                "Unexpected error while checking factory subscription request %s",
                request_id,
            )
            await _finish_request(
                database,
                request_id,
                error=f"تعذر إكمال التحقق من الاشتراك: {str(error)[:250]}",
            )
    return processed


async def run_subscription_check_worker(
    database: Database, central_bot
) -> None:
    while True:
        try:
            processed = await process_pending_subscription_checks(
                database, central_bot
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Central subscription-check worker iteration failed")
            await asyncio.sleep(1)
            continue
        await asyncio.sleep(0.1 if processed else 0.5)
