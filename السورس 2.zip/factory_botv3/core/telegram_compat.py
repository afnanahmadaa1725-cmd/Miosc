"""Small runtime bridge for Telegram API objects during the PTB migration."""

from __future__ import annotations

from datetime import timedelta
from typing import Any


def is_telegram_api_error(error: Exception) -> bool:
    module = type(error).__module__
    return module.startswith("telegram.")


def is_forbidden_error(error: Exception) -> bool:
    return type(error).__name__ in {"TelegramForbiddenError", "Forbidden"}


def retry_after_seconds(error: Exception) -> float | None:
    if type(error).__name__ not in {"TelegramRetryAfter", "RetryAfter"}:
        return None
    retry_after: Any = getattr(error, "retry_after", None)
    if isinstance(retry_after, timedelta):
        return max(0.0, retry_after.total_seconds())
    if isinstance(retry_after, (int, float)):
        return max(0.0, float(retry_after))
    return None


async def copy_message_to(message: Any, bot: Any, chat_id: int) -> None:
    copy_to = getattr(message, "copy_to", None)
    if callable(copy_to):
        await copy_to(chat_id=chat_id)
        return
    await bot.copy_message(
        chat_id=chat_id,
        from_chat_id=message.chat_id,
        message_id=message.message_id,
    )
