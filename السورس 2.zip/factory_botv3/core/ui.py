from __future__ import annotations

from collections.abc import MutableMapping
from typing import Any


def _bot_for(value: Any) -> Any:
    bot = getattr(value, "bot", None)
    if bot is not None:
        return bot
    get_bot = getattr(value, "get_bot", None)
    if callable(get_bot):
        return get_bot()
    raise RuntimeError("Telegram update object is not associated with a bot.")


async def _state_data(state: Any) -> MutableMapping[str, Any]:
    if isinstance(state, MutableMapping):
        return state
    get_data = getattr(state, "get_data", None)
    if not callable(get_data):
        raise TypeError("State must be a mapping or provide get_data().")
    return await get_data()


async def _update_state(state: Any, values: dict[str, Any]) -> None:
    if isinstance(state, MutableMapping):
        state.update(values)
        return
    update_data = getattr(state, "update_data", None)
    if not callable(update_data):
        raise TypeError("State must be a mapping or provide update_data().")
    await update_data(**values)


def _is_message_not_modified(error: Exception) -> bool:
    known_error = (
        type(error).__name__ in {"TelegramBadRequest", "BadRequest"}
        and type(error).__module__.startswith("telegram.")
    )
    return known_error and "message is not modified" in str(error).casefold()


def _is_message_caption_too_long(error: Exception) -> bool:
    known_error = (
        type(error).__name__ in {"TelegramBadRequest", "BadRequest"}
        and type(error).__module__.startswith("telegram.")
    )
    return known_error and "caption is too long" in str(error).casefold()


async def edit_callback_panel(
    callback: Any,
    text: str,
    reply_markup: Any = None,
    parse_mode: str | None = None,
    state: Any = None,
) -> Any | None:
    message = callback.message
    if message is None:
        return None
    if message.photo or message.animation:
        try:
            await message.edit_caption(
                caption=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
            )
        except Exception as error:
            if _is_message_not_modified(error):
                pass
            elif _is_message_caption_too_long(error):
                replacement = await _bot_for(callback).send_message(
                    chat_id=message.chat.id,
                    text=text,
                    reply_markup=reply_markup,
                    parse_mode=parse_mode,
                )
                if state is not None:
                    await remember_panel(state, replacement)
                return replacement
            else:
                raise
        if state is not None:
            await remember_panel(state, message)
        return message
    try:
        await message.edit_text(
            text, reply_markup=reply_markup, parse_mode=parse_mode
        )
    except Exception as error:
        if not _is_message_not_modified(error):
            raise
    if state is not None:
        await remember_panel(state, message)
    return message


async def remember_panel(state: Any, message: Any) -> None:
    await _update_state(
        state,
        {
            "panel_chat_id": message.chat.id,
            "panel_message_id": message.message_id,
            "panel_media": bool(message.photo or message.animation),
        },
    )


async def edit_tracked_panel(
    message: Any,
    state: Any,
    text: str,
    reply_markup: Any = None,
) -> None:
    data = await _state_data(state)
    chat_id = data.get("panel_chat_id")
    message_id = data.get("panel_message_id")
    if not isinstance(chat_id, int) or not isinstance(message_id, int):
        await message.answer(text, reply_markup=reply_markup)
        return
    if data.get("panel_media"):
        bot = _bot_for(message)
        try:
            await bot.edit_message_caption(
                chat_id=chat_id,
                message_id=message_id,
                caption=text,
                reply_markup=reply_markup,
            )
        except Exception as error:
            if _is_message_not_modified(error):
                return
            if not _is_message_caption_too_long(error):
                raise
            replacement = await bot.send_message(
                chat_id=chat_id,
                text=text,
                reply_markup=reply_markup,
            )
            await remember_panel(state, replacement)
        return
    try:
        await _bot_for(message).edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
        )
    except Exception as error:
        if not _is_message_not_modified(error):
            raise
