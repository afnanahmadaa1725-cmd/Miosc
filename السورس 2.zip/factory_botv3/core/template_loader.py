"""اكتشاف القوالب وتثبيتها بأمان من أرشيفات المشرف."""

from __future__ import annotations

import json
import re
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_-]{1,48}$")
MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_FILES = 80
MAX_TOTAL_UNCOMPRESSED_BYTES = 50 * 1024 * 1024
DEFAULT_REQUIREMENTS = (
    "python-telegram-bot>=22.7,<23\n"
    "SQLAlchemy[asyncio]>=2.0,<3\n"
    "aiosqlite>=0.20\n"
    "pyaes>=1.6.1,<2\n"
    "Telethon>=1.36,<2\n"
    "py-tgcalls>=2.3.3,<3\n"
    "static-ffmpeg>=3.0,<4\n"
)


@dataclass(frozen=True)
class TemplateInfo:
    tier: str
    name: str
    path: Path


class TemplateLoader:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        for tier in ("free", "paid"):
            (self.root / tier).mkdir(parents=True, exist_ok=True)

    def list_templates(self, tier: str | None = None) -> list[TemplateInfo]:
        tiers = (tier,) if tier else ("free", "paid")
        found: list[TemplateInfo] = []
        for current_tier in tiers:
            if current_tier not in ("free", "paid"):
                raise ValueError("نوع القالب غير صالح.")
            for path in sorted((self.root / current_tier).iterdir()):
                if (
                    path.is_dir()
                    and (path / "bot.py").is_file()
                    and (path / "requirements.txt").is_file()
                ):
                    found.append(TemplateInfo(current_tier, path.name, path))
        return found

    def get(self, tier: str, name: str | None = None) -> TemplateInfo:
        for item in self.list_templates(tier):
            if name is None or item.name == name:
                return item
        raise FileNotFoundError(f"لا يوجد قالب متاح ضمن القسم {tier}.")

    def install_zip(self, tier: str, name: str, archive_path: str | Path) -> TemplateInfo:
        if tier not in ("free", "paid") or not NAME_PATTERN.fullmatch(name):
            raise ValueError("اسم القالب أو نوعه غير صالح.")
        archive = Path(archive_path)
        if archive.stat().st_size > MAX_ARCHIVE_BYTES:
            raise ValueError("حجم أرشيف القالب يتجاوز الحد المسموح.")
        destination = (self.root / tier / name).resolve()
        if destination.exists():
            raise FileExistsError("يوجد قالب بهذا الاسم؛ احذفه أولاً قبل استبداله.")
        destination.mkdir(parents=True)
        try:
            with zipfile.ZipFile(archive) as source:
                entries = [item for item in source.infolist() if not item.is_dir()]
                if len(entries) > MAX_FILES or sum(item.file_size for item in entries) > MAX_TOTAL_UNCOMPRESSED_BYTES:
                    raise ValueError("عدد ملفات القالب يتجاوز الحد المسموح.")
                common_prefix = self._common_project_prefix(entries)
                for item in entries:
                    if "\\" in item.filename or ":" in item.filename or "\x00" in item.filename:
                        raise ValueError("الأرشيف يحتوي على اسم ملف غير آمن.")
                    if item.flag_bits & 0x1:
                        raise ValueError("الأرشيف المشفر بكلمة مرور غير مدعوم.")
                    if item.compress_type not in (
                        zipfile.ZIP_STORED,
                        zipfile.ZIP_DEFLATED,
                        zipfile.ZIP_BZIP2,
                        zipfile.ZIP_LZMA,
                    ):
                        raise ValueError("طريقة ضغط أحد ملفات الأرشيف غير مدعومة.")
                    relative = PurePosixPath(item.filename)
                    if not relative.parts or relative.is_absolute() or any(
                        part in ("..", "") for part in relative.parts
                    ):
                        raise ValueError("الأرشيف يحتوي على مسار غير آمن.")
                    if item.file_size > MAX_FILE_BYTES:
                        raise ValueError("أحد ملفات القالب يتجاوز الحد المسموح.")
                    parts = relative.parts
                    if common_prefix and parts[0] == common_prefix:
                        parts = parts[1:]
                    elif parts[0] == name:
                        parts = parts[1:]
                    elif len(parts) > 1 and parts[0] in ("template", "package"):
                        parts = parts[1:]
                    if not parts:
                        continue
                    target = destination.joinpath(*parts).resolve()
                    if destination not in target.parents:
                        raise ValueError("الأرشيف يحاول الكتابة خارج مجلد القالب.")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source.open(item) as file_in, target.open("xb") as file_out:
                        shutil.copyfileobj(file_in, file_out)
            entrypoint = self._find_entrypoint(destination)
            if not entrypoint:
                raise ValueError("يجب أن يحتوي المشروع bot.py أو main.py في مجلده الرئيسي.")
            requirements = destination / "requirements.txt"
            if not requirements.is_file():
                requirements.write_text(DEFAULT_REQUIREMENTS, encoding="utf-8")
            self._write_manifest(destination, entrypoint, archive.name)
            return TemplateInfo(tier, name, destination)
        except Exception:
            shutil.rmtree(destination, ignore_errors=True)
            raise

    @staticmethod
    def _common_project_prefix(entries: list[zipfile.ZipInfo]) -> str | None:
        first_parts = [PurePosixPath(item.filename).parts for item in entries]
        if not first_parts or any(not parts for parts in first_parts):
            return None
        prefix = first_parts[0][0]
        if (
            all(parts[0] == prefix and len(parts) > 1 for parts in first_parts)
            and any(parts[1] in {"bot.py", "main.py"} for parts in first_parts)
        ):
            return prefix
        return None

    @staticmethod
    def _find_entrypoint(folder: Path) -> str | None:
        for candidate in ("bot.py", "main.py"):
            if (folder / candidate).is_file():
                return candidate
        python_files = [
            item for item in folder.glob("*.py")
            if item.name not in {"__init__.py", "utils.py"}
        ]
        if len(python_files) == 1:
            python_files[0].rename(folder / "bot.py")
            return "bot.py"
        return None

    @staticmethod
    def _write_manifest(folder: Path, entrypoint: str, source_name: str) -> None:
        (folder / "factory_template.json").write_text(
            json.dumps(
                {"entrypoint": entrypoint, "source": source_name},
                ensure_ascii=True,
            ),
            encoding="utf-8",
        )

    def install_upload(
        self, tier: str, name: str, upload_path: str | Path
    ) -> TemplateInfo:
        """احفظ مشروع ZIP كاملاً أو ملف Python منفرداً داخل مجلد قالب مستقل."""
        source = Path(upload_path)
        suffix = source.suffix.casefold()
        if suffix == ".zip":
            return self.install_zip(tier, name, source)
        if suffix != ".py":
            raise ValueError("الصيغ المدعومة هي ZIP أو ملف Python بامتداد .py.")
        if tier not in ("free", "paid") or not NAME_PATTERN.fullmatch(name):
            raise ValueError("اسم المشروع أو نوعه غير صالح.")
        if source.stat().st_size > MAX_FILE_BYTES:
            raise ValueError("حجم ملف Python يتجاوز الحد المسموح.")
        destination = (self.root / tier / name).resolve()
        if destination.exists():
            raise FileExistsError("يوجد قالب بهذا الاسم؛ اختر اسماً آخر.")
        destination.mkdir(parents=True)
        try:
            shutil.copyfile(source, destination / "bot.py")
            (destination / "requirements.txt").write_text(
                DEFAULT_REQUIREMENTS, encoding="utf-8"
            )
            self._write_manifest(destination, "bot.py", source.name)
            return TemplateInfo(tier, name, destination)
        except Exception:
            shutil.rmtree(destination, ignore_errors=True)
            raise

    def delete(self, tier: str, name: str) -> None:
        if tier not in ("free", "paid") or not NAME_PATTERN.fullmatch(name):
            raise ValueError("اسم القالب أو نوعه غير صالح.")
        target = (self.root / tier / name).resolve()
        if target.parent != (self.root / tier).resolve() or not target.exists():
            raise FileNotFoundError("القالب غير موجود.")
        shutil.rmtree(target)

    def copy_to(self, template: TemplateInfo, destination: str | Path) -> None:
        target = Path(destination).resolve()
        if target.exists():
            raise FileExistsError("مجلد بيانات البوت موجود مسبقاً.")
        shutil.copytree(
            template.path,
            target,
            ignore=shutil.ignore_patterns(
                "__pycache__", "*.pyc", ".venv", ".env", "*.session", "*.session-journal"
            ),
        )
