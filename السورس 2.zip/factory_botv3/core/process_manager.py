"""تشغيل ومراقبة كل بوت مصنوع في عملية نظام مستقلة."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import sysconfig
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path, PurePosixPath

from packaging.requirements import InvalidRequirement, Requirement
from sqlalchemy import delete, select, update
from sqlalchemy.engine import make_url

from config import PROJECT_ROOT
from core.fernet_compat import Fernet
from core.template_loader import TemplateInfo, TemplateLoader
from database.connection import Database
from database.models import AssistantSession, BotRecord, SubscriptionCheck

logger = logging.getLogger(__name__)
YOUTUBE_REQUIREMENT = "yt-dlp[default,deno]>=2025.10.22"


@dataclass
class ManagedProcess:
    process: asyncio.subprocess.Process
    stdout_file: object
    stderr_file: object


class ProcessManager:
    def __init__(
        self,
        database: Database,
        loader: TemplateLoader,
        data_dir: str | Path,
        logs_dir: str | Path,
        fernet_key: str,
        telegram_api_id: int,
        telegram_api_hash: str,
        database_url: str,
        youtube_cookies_file: str | Path | None = None,
    ) -> None:
        self.database = database
        self.loader = loader
        self.project_root = PROJECT_ROOT

        def project_path(path: str | Path) -> Path:
            candidate = Path(path)
            if not candidate.is_absolute():
                candidate = self.project_root / candidate
            candidate = candidate.resolve()
            try:
                candidate.relative_to(self.project_root)
            except ValueError as error:
                raise ValueError(
                    "مسارات تشغيل البوتات يجب أن تبقى داخل المشروع."
                ) from error
            return candidate

        self.data_dir = project_path(data_dir)
        self.logs_dir = project_path(logs_dir)
        self.youtube_cookies_file = (
            project_path(youtube_cookies_file) if youtube_cookies_file else None
        )
        self.fernet_key = fernet_key
        self.telegram_api_id = telegram_api_id
        self.telegram_api_hash = telegram_api_hash
        database_url_object = make_url(database_url)
        if database_url_object.get_backend_name() == "sqlite":
            database_file = database_url_object.database
            if not database_file or database_file == ":memory:":
                raise ValueError("يجب استخدام قاعدة SQLite على ملف لمشاركتها مع عمليات البوتات.")
            database_path = Path(database_file)
            if not database_path.is_absolute():
                database_path = self.project_root / database_path
            database_url_object = database_url_object.set(
                database=str(database_path.resolve())
            )
        self.database_url = database_url_object.render_as_string(hide_password=False)
        self.processes: dict[int, ManagedProcess] = {}
        self._youtube_dependencies_lock = asyncio.Lock()
        self._supervisor: asyncio.Task[None] | None = None
        self._stopping = False
        self._ffmpeg_path: Path | None = None
        self._ffmpeg_resolution_attempted = False
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

    def _folder_for_data_path(self, data_path: str) -> Path:
        normalized = str(data_path).strip().replace("\\", "/")
        folder_name = PurePosixPath(normalized).name
        if not re.fullmatch(r"bot_[A-Za-z0-9_-]+", folder_name):
            raise ValueError(f"مسار بيانات البوت غير صالح: {data_path}")
        return (self.data_dir / folder_name).resolve()

    def _stored_data_path(self, folder: Path) -> str:
        return folder.relative_to(self.project_root).as_posix()

    def _youtube_cookiefile_for_template(self, template_name: str) -> Path | None:
        if template_name != "music_bot" or self.youtube_cookies_file is None:
            return None
        if not self.youtube_cookies_file.is_file():
            raise FileNotFoundError(
                f"ملف كوكيز YouTube غير موجود: {self.youtube_cookies_file}"
            )
        return self.youtube_cookies_file

    async def normalize_stored_data_paths(self) -> None:
        """Repair legacy absolute bot paths and persist project-relative paths."""
        updated_count = 0
        async with self.database.session() as session:
            records = (
                await session.execute(select(BotRecord).order_by(BotRecord.id))
            ).scalars().all()
            for record in records:
                folder = self._folder_for_data_path(record.data_path)
                normalized_path = self._stored_data_path(folder)
                if record.data_path != normalized_path:
                    record.data_path = normalized_path
                    updated_count += 1
            if updated_count:
                await session.commit()
        if updated_count:
            logger.info("تم تصحيح مسارات %s بوت في قاعدة البيانات", updated_count)

    @staticmethod
    def _ffmpeg_bin_dir() -> Path | None:
        ffprobe = shutil.which("ffprobe")
        ffmpeg = shutil.which("ffmpeg")
        if ffprobe and ffmpeg and Path(ffprobe).parent == Path(ffmpeg).parent:
            return Path(ffprobe).parent

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            packages = (
                Path(local_app_data)
                / "Microsoft"
                / "WinGet"
                / "Packages"
            )
            for package in packages.glob("Gyan.FFmpeg_*"):
                for bin_dir in package.glob("ffmpeg-*/bin"):
                    if (bin_dir / "ffprobe.exe").is_file() and (
                        bin_dir / "ffmpeg.exe"
                    ).is_file():
                        return bin_dir

        from static_ffmpeg import run as static_ffmpeg_run

        ffmpeg_path, ffprobe_path = (
            static_ffmpeg_run.get_or_fetch_platform_executables_else_raise()
        )
        ffmpeg = Path(ffmpeg_path)
        ffprobe = Path(ffprobe_path)
        if ffmpeg.is_file() and ffprobe.is_file() and ffmpeg.parent == ffprobe.parent:
            return ffmpeg.parent
        return None

    async def _resolve_ffmpeg_path(self) -> Path | None:
        if not self._ffmpeg_resolution_attempted:
            self._ffmpeg_resolution_attempted = True
            try:
                self._ffmpeg_path = await asyncio.to_thread(self._ffmpeg_bin_dir)
            except Exception:
                logger.exception("تعذر تهيئة FFmpeg وffprobe من الحزمة المضمنة")
        if self._ffmpeg_path is None:
            logger.error("لم يُعثر على ffmpeg وffprobe؛ قد تتعطل ميزات تشغيل الصوت.")
        return self._ffmpeg_path

    @staticmethod
    def _factory_runtime_satisfies_requirements(requirements_path: Path) -> bool:
        if not requirements_path.is_file():
            return False
        for raw_line in requirements_path.read_text(encoding="utf-8").splitlines():
            requirement_text = raw_line.partition("#")[0].strip()
            if not requirement_text:
                continue
            try:
                requirement = Requirement(requirement_text)
            except InvalidRequirement:
                return False
            if requirement.url:
                return False
            if requirement.marker and not requirement.marker.evaluate():
                continue
            try:
                installed_version = version(requirement.name)
            except PackageNotFoundError:
                return False
            if requirement.specifier and not requirement.specifier.contains(
                installed_version, prereleases=True
            ):
                return False
        return True

    @staticmethod
    def _deno_executable() -> Path | None:
        executable = shutil.which("deno")
        if executable:
            return Path(executable)
        name = "deno.exe" if os.name == "nt" else "deno"
        candidate = Path(sysconfig.get_path("scripts")) / name
        return candidate if candidate.is_file() else None

    @classmethod
    def _youtube_runtime_satisfies_requirements(cls) -> bool:
        requirement = Requirement(YOUTUBE_REQUIREMENT)
        try:
            installed_version = version("yt-dlp")
            ejs_version = version("yt-dlp-ejs")
            deno_version = version("deno")
        except PackageNotFoundError:
            return False
        return (
            requirement.specifier.contains(installed_version, prereleases=True)
            and Requirement("yt-dlp-ejs>=0.8.0").specifier.contains(
                ejs_version, prereleases=True
            )
            and Requirement("deno>=2.6.6").specifier.contains(
                deno_version, prereleases=True
            )
            and cls._deno_executable() is not None
        )

    async def _ensure_youtube_runtime(self) -> None:
        async with self._youtube_dependencies_lock:
            if self._youtube_runtime_satisfies_requirements():
                return

            logger.info(
                "Installing or updating yt-dlp EJS and Deno support before starting "
                "a music bot."
            )
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "pip",
                "install",
                "--upgrade",
                YOUTUBE_REQUIREMENT,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            try:
                output, _ = await asyncio.wait_for(
                    process.communicate(), timeout=600
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                raise RuntimeError(
                    "انتهت مهلة تحديث yt-dlp وDeno. تحقق من اتصال الإنترنت ثم أعد تشغيل البوت."
                ) from None
            if process.returncode != 0:
                details = (output or b"").decode("utf-8", errors="replace")[-2000:]
                raise RuntimeError(
                    "تعذر تحديث دعم YouTube تلقائياً. تحقق من اتصال الإنترنت وصلاحية "
                    "تثبيت الحزم.\n"
                    + (details or "لم يعرض pip تفاصيل إضافية.")
                )
            if not self._youtube_runtime_satisfies_requirements():
                raise RuntimeError(
                    "اكتمل تثبيت دعم YouTube لكن لم يتم العثور على Deno أو EJS. "
                    "تحقق من بيئة Python وأعد تشغيل المصنع."
                )

    async def create_and_start(
        self,
        record: BotRecord,
        template: TemplateInfo,
        plaintext_token: str,
        plaintext_voice_session: str,
    ) -> None:
        folder = self.data_dir / f"bot_{record.token_hash}"
        self.loader.copy_to(template, folder)
        (folder / "bot_config.json").write_text(
            json.dumps(
                {
                    "bot_id": record.id,
                    "tier": record.tier,
                    "owner_id": record.owner_id,
                    "template_name": record.template_name,
                    "token_hash": record.token_hash,
                },
                ensure_ascii=True,
            ),
            encoding="utf-8",
        )
        manifest_path = folder / "factory_template.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
        entrypoint = manifest.get("entrypoint", "bot.py")
        await self.start_bot(
            record.id,
            plaintext_token,
            plaintext_voice_session,
            entrypoint=entrypoint,
        )

    async def start_bot(
        self,
        bot_id: int,
        plaintext_token: str,
        plaintext_voice_session: str,
        entrypoint: str | None = None,
    ) -> None:
        existing = self.processes.get(bot_id)
        if existing and existing.process.returncode is None:
            return
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None or not record.enabled:
                return
            folder = self._folder_for_data_path(record.data_path)
            normalized_path = self._stored_data_path(folder)
            if record.data_path != normalized_path:
                record.data_path = normalized_path
                await session.commit()
            tier = record.tier
            owner_id = record.owner_id
            template_name = record.template_name
        youtube_cookiefile = self._youtube_cookiefile_for_template(template_name)
        manifest_path = folder / "factory_template.json"
        if entrypoint is None and manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            entrypoint = manifest.get("entrypoint")
        bot_script = folder / (entrypoint or "bot.py")
        if not bot_script.is_file():
            raise FileNotFoundError(f"ملف تشغيل البوت غير موجود: {bot_script}")
        stdout_file = (self.logs_dir / f"bot_{bot_id}.out.log").open("a", encoding="utf-8")
        stderr_file = (self.logs_dir / f"bot_{bot_id}.err.log").open("a", encoding="utf-8")
        try:
            interpreter = await self._prepare_environment(folder, template_name)
        except Exception:
            stdout_file.close()
            stderr_file.close()
            raise
        environment = os.environ.copy()
        ffmpeg_bin_dir = await self._resolve_ffmpeg_path()
        if ffmpeg_bin_dir:
            environment["PATH"] = os.pathsep.join(
                (str(ffmpeg_bin_dir), environment.get("PATH", ""))
            )
        deno_executable = self._deno_executable()
        if deno_executable:
            environment["PATH"] = os.pathsep.join(
                (str(deno_executable.parent), environment.get("PATH", ""))
            )
        for secret_name in (
            "FACTORY_BOT_TOKEN",
            "FACTORY_FERNET_KEY",
            "FACTORY_ADMIN_IDS",
            "FACTORY_YT_DLP_COOKIEFILE",
            "YT_DLP_COOKIEFILE",
            "FACTORY_TELETHON_SESSION",
            "FACTORY_TEMPLATE_TELETHON_SESSIONS",
            "FACTORY_DATABASE_URL",
            "SESSION_STRING",
        ):
            environment.pop(secret_name, None)
        environment.update(
            {
                "BOT_TOKEN": plaintext_token,
                "TELETHON_SESSION": plaintext_voice_session,
                "BOT_CONFIG_PATH": str(folder / "bot_config.json"),
                "BOT_ID": str(bot_id),
                "BOT_OWNER_ID": str(owner_id),
                "TELEGRAM_API_ID": str(self.telegram_api_id),
                "TELEGRAM_API_HASH": self.telegram_api_hash,
                "BOT_TIER": tier,
                "FACTORY_APP_ROOT": str(Path(__file__).resolve().parent.parent),
            }
        )
        if youtube_cookiefile:
            environment["YT_DLP_COOKIEFILE"] = str(youtube_cookiefile)
        if tier == "free":
            environment["FACTORY_DATABASE_URL"] = self.database_url
        app_root = str(Path(__file__).resolve().parent.parent)
        current_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = os.pathsep.join(
            item for item in (app_root, current_pythonpath) if item
        )
        kwargs: dict[str, object] = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True
        try:
            process = await asyncio.create_subprocess_exec(
                str(interpreter),
                str(bot_script),
                cwd=str(folder),
                env=environment,
                stdout=stdout_file,
                stderr=stderr_file,
                **kwargs,
            )
        except Exception:
            stdout_file.close()
            stderr_file.close()
            raise
        await asyncio.sleep(0.5)
        if process.returncode is not None:
            stdout_file.close()
            stderr_file.close()
            details = self._read_log_excerpt(stderr_file.name)
            raise RuntimeError(
                f"انتهت عملية البوت أثناء بدء التشغيل برمز {process.returncode}."
                + (f"\nتفاصيل الخطأ:\n{details}" if details else " راجع سجل الأخطاء.")
            )
        self.processes[bot_id] = ManagedProcess(process, stdout_file, stderr_file)
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record:
                record.status = "running"
                record.pid = process.pid
                await session.commit()

    async def _prepare_environment(
        self, folder: Path, template_name: str | None = None
    ) -> Path:
        """Use the shared runtime and bootstrap YouTube support for music bots."""
        requirements_path = folder / "requirements.txt"
        if template_name == "music_bot":
            await self._ensure_youtube_runtime()
        if not self._factory_runtime_satisfies_requirements(requirements_path):
            raise RuntimeError(
                "اعتماديات القالب غير متوفرة أو إصداراتها غير متوافقة في بيئة "
                "الصانع. ثبّتها في بيئة الصانع ثم أعد تشغيله قبل إنشاء البوت."
            )
        return Path(sys.executable)

    @staticmethod
    def _read_log_excerpt(log_path: str, limit: int = 2000) -> str:
        try:
            return Path(log_path).read_text(encoding="utf-8", errors="replace")[-limit:].strip()
        except OSError:
            logger.exception("تعذر قراءة سجل العملية: %s", log_path)
            return ""

    async def start_all(self) -> None:
        await self._resolve_ffmpeg_path()
        await self.normalize_stored_data_paths()
        async with self.database.session() as session:
            records = (
                await session.execute(select(BotRecord).where(BotRecord.enabled.is_(True)))
            ).scalars().all()
        cipher = Fernet(self.fernet_key.encode())
        for record in records:
            try:
                voice_session = await self._assistant_session_for_bot(record.id)
                token = cipher.decrypt(record.encrypted_token.encode()).decode()
                await self.start_bot(record.id, token, voice_session)
            except Exception:
                logger.exception("تعذر بدء البوت رقم %s عند استعادة العمليات", record.id)
                async with self.database.session() as session:
                    current = await session.get(BotRecord, record.id)
                    if current:
                        current.status = "error"
                        current.pid = None
                        await session.commit()
        self._supervisor = asyncio.create_task(self._supervise())

    async def start_stored_bot(self, bot_id: int) -> None:
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
        voice_session = await self._assistant_session_for_bot(bot_id)
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
            record.enabled = True
            token = Fernet(self.fernet_key.encode()).decrypt(
                record.encrypted_token.encode()
            ).decode()
            record.encrypted_voice_session = Fernet(self.fernet_key.encode()).encrypt(
                voice_session.encode()
            ).decode()
            await session.commit()
        try:
            await self.start_bot(bot_id, token, voice_session)
        except Exception:
            async with self.database.session() as session:
                record = await session.get(BotRecord, bot_id)
                if record:
                    record.enabled = False
                    record.status = "error"
                    record.pid = None
                    await session.commit()
            raise

    async def _assistant_session_for_bot(self, bot_id: int) -> str:
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
            account = await session.scalar(
                select(AssistantSession).where(
                    AssistantSession.assigned_bot_id == bot_id
                )
            )
            if account is None:
                available_id = await session.scalar(
                    select(AssistantSession.id)
                    .where(AssistantSession.assigned_bot_id.is_(None))
                    .order_by(AssistantSession.id)
                    .limit(1)
                )
                if available_id is None:
                    return ""
                claimed = await session.execute(
                    update(AssistantSession)
                    .where(
                        AssistantSession.id == available_id,
                        AssistantSession.assigned_bot_id.is_(None),
                    )
                    .values(assigned_bot_id=bot_id)
                )
                if claimed.rowcount != 1:
                    raise RuntimeError(
                        "تم تخصيص الجلسة لبوت آخر بالتزامن؛ أعد المحاولة."
                    )
                account = await session.get(AssistantSession, available_id)
            if account is None:
                raise RuntimeError("تعذر تحميل جلسة الحساب المساعد.")
            encrypted_session = account.encrypted_session
            if record.encrypted_voice_session != encrypted_session:
                record.encrypted_voice_session = encrypted_session
            await session.commit()
        return Fernet(self.fernet_key.encode()).decrypt(
            encrypted_session.encode()
        ).decode()

    async def assign_available_assistant_sessions(self) -> list[int]:
        """Assign waiting helper sessions to enabled bots that have none."""
        assigned_bot_ids: list[int] = []
        async with self.database.session() as session:
            bots = (
                await session.execute(
                    select(BotRecord)
                    .where(BotRecord.enabled.is_(True))
                    .order_by(BotRecord.id)
                )
            ).scalars().all()
            available_accounts = (
                await session.execute(
                    select(AssistantSession)
                    .where(AssistantSession.assigned_bot_id.is_(None))
                    .order_by(AssistantSession.id)
                )
            ).scalars().all()
            for record in bots:
                if not available_accounts:
                    break
                already_assigned = await session.scalar(
                    select(AssistantSession.id).where(
                        AssistantSession.assigned_bot_id == record.id
                    )
                )
                if already_assigned is not None:
                    continue
                account = available_accounts.pop(0)
                claimed = await session.execute(
                    update(AssistantSession)
                    .where(
                        AssistantSession.id == account.id,
                        AssistantSession.assigned_bot_id.is_(None),
                    )
                    .values(assigned_bot_id=record.id)
                )
                if claimed.rowcount != 1:
                    raise RuntimeError(
                        "تعذر تخصيص جلسة الحساب المساعد؛ أعد المحاولة."
                    )
                record.encrypted_voice_session = account.encrypted_session
                assigned_bot_ids.append(record.id)
            await session.commit()
        return assigned_bot_ids

    async def restart_bot(self, bot_id: int) -> bool:
        managed = self.processes.get(bot_id)
        if managed is None or managed.process.returncode is not None:
            return False
        self.processes.pop(bot_id, None)
        managed.process.terminate()
        try:
            await asyncio.wait_for(managed.process.wait(), timeout=10)
        except asyncio.TimeoutError:
            managed.process.kill()
            await managed.process.wait()
        managed.stdout_file.close()
        managed.stderr_file.close()
        await self.start_stored_bot(bot_id)
        return True

    async def restart_running_bots_for_tier(
        self, tier: str
    ) -> tuple[list[int], list[int]]:
        if tier not in {"free", "paid"}:
            raise ValueError("نوع القالب غير صالح.")
        async with self.database.session() as session:
            bot_ids = (
                await session.execute(
                    select(BotRecord.id)
                    .where(
                        BotRecord.tier == tier,
                        BotRecord.enabled.is_(True),
                        BotRecord.status == "running",
                    )
                    .order_by(BotRecord.id)
                )
            ).scalars().all()

        restarted: list[int] = []
        failed: list[int] = []
        for bot_id in bot_ids:
            try:
                if await self.restart_bot(bot_id):
                    restarted.append(bot_id)
                else:
                    failed.append(bot_id)
            except Exception:
                logger.exception(
                    "تعذر إعادة تشغيل البوت %s بعد تحديث إعدادات القسم %s",
                    bot_id,
                    tier,
                )
                failed.append(bot_id)
        return restarted, failed

    async def stop_bot(self, bot_id: int) -> None:
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
            record.enabled = False
            record.status = "stopped"
            record.pid = None
            await session.commit()
        managed = self.processes.pop(bot_id, None)
        if managed is None:
            return
        if managed.process.returncode is None:
            managed.process.terminate()
            try:
                await asyncio.wait_for(managed.process.wait(), timeout=10)
            except asyncio.TimeoutError:
                managed.process.kill()
                await managed.process.wait()
        managed.stdout_file.close()
        managed.stderr_file.close()

    async def delete_bot(self, bot_id: int) -> None:
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
            folder = self._folder_for_data_path(record.data_path)
            managed_folder = (
                folder.parent == self.data_dir and folder.name.startswith("bot_")
            )
            if folder.exists() and not managed_folder:
                raise ValueError("مسار بيانات البوت غير آمن؛ لم يتم حذف بياناته.")

        await self.stop_bot(bot_id)
        async with self.database.session() as session:
            record = await session.get(BotRecord, bot_id)
            if record is None:
                raise LookupError("البوت غير موجود.")
            folder = self._folder_for_data_path(record.data_path)
            managed_folder = (
                folder.parent == self.data_dir and folder.name.startswith("bot_")
            )
            if folder.exists() and not managed_folder:
                raise ValueError("مسار بيانات البوت غير آمن؛ لم يتم حذف بياناته.")
            assistant = await session.scalar(
                select(AssistantSession).where(
                    AssistantSession.assigned_bot_id == bot_id
                )
            )
            if assistant is not None:
                assistant.assigned_bot_id = None
            await session.execute(
                delete(SubscriptionCheck).where(SubscriptionCheck.bot_id == bot_id)
            )
            await session.delete(record)
            await session.commit()

        try:
            if managed_folder and folder.exists():
                shutil.rmtree(folder)
            for suffix in ("out", "err"):
                (self.logs_dir / f"bot_{bot_id}.{suffix}.log").unlink(
                    missing_ok=True
                )
        except OSError as error:
            logger.exception(
                "تم حذف سجل البوت %s وتحرير جلسته، لكن تعذر تنظيف جميع ملفاته",
                bot_id,
            )
            raise RuntimeError(
                "حُذف سجل البوت وأُتيحت جلسته، لكن تعذر حذف بعض ملفاته من القرص."
            ) from error

    async def stop_all_bots(self) -> None:
        async with self.database.session() as session:
            bot_ids = (
                await session.execute(select(BotRecord.id).order_by(BotRecord.id))
            ).scalars().all()
        for bot_id in bot_ids:
            await self.stop_bot(bot_id)

    async def start_all_bots(self) -> None:
        async with self.database.session() as session:
            bot_ids = (
                await session.execute(select(BotRecord.id).order_by(BotRecord.id))
            ).scalars().all()
        errors: list[str] = []
        for bot_id in bot_ids:
            try:
                await self.start_stored_bot(bot_id)
            except Exception:
                logger.exception("تعذر بدء البوت رقم %s ضمن التشغيل الجماعي", bot_id)
                errors.append(str(bot_id))
        if errors:
            raise RuntimeError(
                "تعذر تشغيل البوتات ذات المعرفات: " + ", ".join(errors)
            )

    async def _supervise(self) -> None:
        while not self._stopping:
            await asyncio.sleep(5)
            for bot_id, managed in list(self.processes.items()):
                if managed.process.returncode is None:
                    continue
                managed.stdout_file.close()
                managed.stderr_file.close()
                self.processes.pop(bot_id, None)
                async with self.database.session() as session:
                    record = await session.get(BotRecord, bot_id)
                    if record:
                        record.status = "stopped"
                        record.pid = None
                        await session.commit()
                        if not record.enabled:
                            continue
                        token = Fernet(self.fernet_key.encode()).decrypt(
                            record.encrypted_token.encode()
                        ).decode()
                    else:
                        continue
                await asyncio.sleep(2)
                try:
                    voice_session = await self._assistant_session_for_bot(bot_id)
                    await self.start_bot(bot_id, token, voice_session)
                except Exception:
                    logger.exception("تعذرت إعادة تشغيل البوت رقم %s", bot_id)

    async def stop_all(self) -> None:
        self._stopping = True
        if self._supervisor:
            self._supervisor.cancel()
            try:
                await self._supervisor
            except asyncio.CancelledError:
                pass
        for bot_id, managed in list(self.processes.items()):
            if managed.process.returncode is None:
                managed.process.terminate()
                try:
                    await asyncio.wait_for(managed.process.wait(), timeout=10)
                except asyncio.TimeoutError:
                    managed.process.kill()
                    await managed.process.wait()
            managed.stdout_file.close()
            managed.stderr_file.close()
            async with self.database.session() as session:
                record = await session.get(BotRecord, bot_id)
                if record:
                    record.status = "stopped"
                    record.pid = None
                    await session.commit()
        self.processes.clear()
