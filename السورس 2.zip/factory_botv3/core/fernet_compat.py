"""Fernet-compatible encryption backed by pure-Python pyaes."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time

import pyaes


class InvalidToken(ValueError):
    pass


class Fernet:
    _VERSION = 0x80
    _SIGNING_KEY_LENGTH = 16
    _ENCRYPTION_KEY_LENGTH = 16
    _HMAC_LENGTH = hashlib.sha256().digest_size

    def __init__(self, key: bytes) -> None:
        if not isinstance(key, bytes):
            raise TypeError("Fernet key must be 32 url-safe base64-encoded bytes.")
        try:
            decoded = base64.b64decode(key, altchars=b"-_", validate=True)
        except (ValueError, base64.binascii.Error) as error:
            raise ValueError(
                "Fernet key must be 32 url-safe base64-encoded bytes."
            ) from error
        if len(decoded) != self._SIGNING_KEY_LENGTH + self._ENCRYPTION_KEY_LENGTH:
            raise ValueError("Fernet key must be 32 url-safe base64-encoded bytes.")
        self._signing_key = decoded[: self._SIGNING_KEY_LENGTH]
        self._encryption_key = decoded[self._SIGNING_KEY_LENGTH :]

    @staticmethod
    def generate_key() -> bytes:
        return base64.urlsafe_b64encode(secrets.token_bytes(32))

    def encrypt(self, data: bytes) -> bytes:
        if not isinstance(data, bytes):
            raise TypeError("Fernet data must be bytes.")
        iv = secrets.token_bytes(16)
        encryptor = pyaes.Encrypter(
            pyaes.AESModeOfOperationCBC(self._encryption_key, iv)
        )
        ciphertext = encryptor.feed(data) + encryptor.feed()
        timestamp = int(time.time()).to_bytes(8, "big")
        payload = bytes((self._VERSION,)) + timestamp + iv + ciphertext
        signature = hmac.new(
            self._signing_key, payload, hashlib.sha256
        ).digest()
        return base64.urlsafe_b64encode(payload + signature)

    def decrypt(self, token: bytes) -> bytes:
        if not isinstance(token, bytes):
            raise TypeError("Fernet token must be bytes.")
        try:
            decoded = base64.b64decode(token, altchars=b"-_", validate=True)
        except (ValueError, base64.binascii.Error) as error:
            raise InvalidToken("Invalid Fernet token.") from error
        minimum_length = 1 + 8 + 16 + 16 + self._HMAC_LENGTH
        if len(decoded) < minimum_length or decoded[0] != self._VERSION:
            raise InvalidToken("Invalid Fernet token.")

        payload = decoded[: -self._HMAC_LENGTH]
        signature = decoded[-self._HMAC_LENGTH :]
        expected_signature = hmac.new(
            self._signing_key, payload, hashlib.sha256
        ).digest()
        if not hmac.compare_digest(signature, expected_signature):
            raise InvalidToken("Invalid Fernet token.")

        iv = decoded[9:25]
        ciphertext = decoded[25:-self._HMAC_LENGTH]
        if not ciphertext or len(ciphertext) % 16:
            raise InvalidToken("Invalid Fernet token.")
        try:
            decryptor = pyaes.Decrypter(
                pyaes.AESModeOfOperationCBC(self._encryption_key, iv)
            )
            return decryptor.feed(ciphertext) + decryptor.feed()
        except (ValueError, IndexError) as error:
            raise InvalidToken("Invalid Fernet token.") from error
