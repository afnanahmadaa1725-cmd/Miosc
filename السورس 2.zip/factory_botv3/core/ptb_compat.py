"""PTB adapters for the factory's existing handler functions and state flows."""

from __future__ import annotations

import inspect
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from telegram import (
    Bot as TelegramBot,
    CallbackQuery as TelegramCallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputFile,
    LabeledPrice,
    Message as TelegramMessage,
    PreCheckoutQuery,
)
from telegram.error import InvalidToken, TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    MessageHandler,
    PreCheckoutQueryHandler,
    filters,
)
from telegram.ext.filters import MessageFilter

class Bot(TelegramBot):
    async def download(self, media: Any, destination: str | Path) -> Path:
        telegram_file = await self.get_file(media.file_id)
        return await telegram_file.download_to_drive(custom_path=destination)


CallbackQuery = TelegramCallbackQuery
Message = TelegramMessage
TelegramAPIError = TelegramError
TelegramUnauthorizedError = InvalidToken


def FSInputFile(path: str | Path) -> InputFile:
    file_path = Path(path)
    return InputFile(file_path.read_bytes(), filename=file_path.name)


class State:
    def __init__(self) -> None:
        self.state = ""

    def __set_name__(self, owner: type, name: str) -> None:
        self.state = f"{owner.__name__}:{name}"


class StatesGroup:
    pass


def _state_storage(application: Application) -> dict[tuple[int, int], dict[str, Any]]:
    return application.bot_data.setdefault("_factory_ptb_states", {})


def _state_key(chat_id: int, user_id: int) -> tuple[int, int]:
    return chat_id, user_id


class FSMContext:
    def __init__(self, storage: dict[tuple[int, int], dict[str, Any]], key: tuple[int, int]):
        self._storage = storage
        self._key = key

    def _record(self) -> dict[str, Any]:
        return self._storage.setdefault(self._key, {"state": None, "data": {}})

    async def get_state(self) -> str | None:
        return self._record()["state"]

    async def set_state(self, state: State | str | None) -> None:
        self._record()["state"] = (
            state.state if isinstance(state, State) else state
        )

    async def get_data(self) -> dict[str, Any]:
        return dict(self._record()["data"])

    async def update_data(self, **kwargs: Any) -> dict[str, Any]:
        self._record()["data"].update(kwargs)
        return await self.get_data()

    async def clear(self) -> None:
        self._storage.pop(self._key, None)


class MessageAdapter:
    def __init__(self, message: TelegramMessage, bot: Bot) -> None:
        self._message = message
        self.bot = bot

    def __getattr__(self, name: str) -> Any:
        return getattr(self._message, name)

    async def answer(self, text: str, **kwargs: Any) -> TelegramMessage:
        return await self._message.reply_text(text, **kwargs)


class CallbackQueryAdapter:
    def __init__(self, callback: TelegramCallbackQuery, bot: Bot) -> None:
        self._callback = callback
        self.bot = bot

    def __getattr__(self, name: str) -> Any:
        if name == "message":
            message = self._callback.message
            return MessageAdapter(message, self.bot) if message else None
        return getattr(self._callback, name)


@dataclass(frozen=True)
class _Expression:
    field_name: str
    operator: str
    value: Any = None


class _Field:
    def __init__(self, field_name: str) -> None:
        self.field_name = field_name

    def __eq__(self, value: Any) -> _Expression:  # type: ignore[override]
        return _Expression(self.field_name, "eq", value)

    def startswith(self, value: str) -> _Expression:
        return _Expression(self.field_name, "startswith", value)

    def regexp(self, value: str | re.Pattern[str]) -> _Expression:
        return _Expression(self.field_name, "regexp", value)


class _FilterNamespace:
    def __getattr__(self, name: str) -> _Field:
        return _Field(name)


F = _FilterNamespace()


@dataclass(frozen=True)
class _Command:
    command: str


def Command(command: str) -> _Command:
    return _Command(command)


def CommandStart() -> _Command:
    return _Command("start")


@dataclass
class _Route:
    kind: str
    callback: Callable[..., Any]
    filters: tuple[Any, ...] = ()


def _event_message(event: Any) -> Any:
    if isinstance(event, TelegramMessage):
        return event
    if isinstance(event, TelegramCallbackQuery):
        return event.message
    return None


def _matches(spec: Any, event: Any, application: Application) -> bool:
    if isinstance(spec, _Command):
        message = _event_message(event)
        text = getattr(message, "text", None)
        if not text:
            return False
        command = text.split(maxsplit=1)[0].split("@", maxsplit=1)[0]
        return command.casefold() == f"/{spec.command}".casefold()
    if isinstance(spec, State):
        message = _event_message(event)
        user = getattr(message, "from_user", None)
        chat = getattr(message, "chat", None)
        if user is None or chat is None:
            return False
        record = _state_storage(application).get(_state_key(chat.id, user.id))
        return bool(record and record["state"] == spec.state)
    if isinstance(spec, _Expression):
        value = getattr(event, spec.field_name, None)
        if spec.operator == "eq":
            return value == spec.value
        if spec.operator == "startswith":
            return isinstance(value, str) and value.startswith(spec.value)
        if spec.operator == "regexp":
            pattern = re.compile(spec.value) if isinstance(spec.value, str) else spec.value
            return isinstance(value, str) and pattern.search(value) is not None
    if isinstance(spec, _Field):
        return bool(getattr(event, spec.field_name, None))
    return False


def _callback_pattern(specs: tuple[Any, ...]) -> str | None:
    patterns = []
    for spec in specs:
        if isinstance(spec, _Expression) and spec.field_name == "data":
            value = re.escape(str(spec.value))
            if spec.operator == "eq":
                patterns.append(f"^{value}$")
            elif spec.operator == "startswith":
                patterns.append(f"^{value}")
    return "|".join(patterns) or None


class _PredicateMessageFilter(MessageFilter):
    def __init__(self, specs: tuple[Any, ...], application: Application) -> None:
        super().__init__()
        self._specs = specs
        self._application = application

    def filter(self, message: TelegramMessage) -> bool:
        return all(_matches(spec, message, self._application) for spec in self._specs)


class Router:
    def __init__(self, name: str = "") -> None:
        self.name = name
        self._routes: list[_Route] = []

    def _decorator(self, kind: str, specs: tuple[Any, ...]):
        def register(callback: Callable[..., Any]):
            self._routes.append(_Route(kind, callback, specs))
            return callback

        return register

    def message(self, *specs: Any):
        return self._decorator("message", specs)

    def callback_query(self, *specs: Any):
        return self._decorator("callback_query", specs)

    def pre_checkout_query(self, *specs: Any):
        return self._decorator("pre_checkout_query", specs)


class Dispatcher:
    def __init__(self, application: Application) -> None:
        self.application = application

    def include_router(self, router: Router) -> None:
        for route in router._routes:
            self.application.add_handler(self._build_handler(route))

    def _build_handler(self, route: _Route):
        application = self.application
        storage = _state_storage(application)

        async def invoke(update: Any, context: Any) -> None:
            if route.kind == "message":
                raw_event = update.effective_message
                event = MessageAdapter(raw_event, context.bot)
                user = raw_event.from_user
                chat_id = raw_event.chat_id
            elif route.kind == "callback_query":
                raw_event = update.callback_query
                event = CallbackQueryAdapter(raw_event, context.bot)
                user = raw_event.from_user
                chat_id = raw_event.message.chat_id if raw_event.message else user.id
            else:
                raw_event = update.pre_checkout_query
                event = raw_event
                user = raw_event.from_user
                chat_id = user.id

            if user is None:
                return
            if not all(_matches(spec, raw_event, application) for spec in route.filters):
                return

            state = FSMContext(storage, _state_key(chat_id, user.id))
            arguments = _handler_arguments(route.callback, event, state, context.bot)
            await route.callback(**arguments)

        if route.kind == "message":
            base_filter = filters.ALL
            if route.filters:
                base_filter = _PredicateMessageFilter(route.filters, application)
            return MessageHandler(base_filter, invoke)
        if route.kind == "callback_query":
            return CallbackQueryHandler(
                invoke,
                pattern=_callback_pattern(route.filters),
            )
        return PreCheckoutQueryHandler(invoke)


def _handler_arguments(
    callback: Callable[..., Any], event: Any, state: FSMContext, bot: Bot
) -> dict[str, Any]:
    arguments: dict[str, Any] = {}
    parameters = list(inspect.signature(callback).parameters)
    if not parameters:
        return arguments
    arguments[parameters[0]] = event
    for name in parameters[1:]:
        if name == "state":
            arguments[name] = state
        elif name == "bot":
            arguments[name] = bot
    return arguments
