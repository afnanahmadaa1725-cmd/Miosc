"""إذاعة اختيارية لمستخدمي البوتات المجانية فقط."""

from __future__ import annotations

import asyncio
import logging

from sqlalchemy import select

from core.telegram_compat import (
    copy_message_to,
    is_forbidden_error,
    is_telegram_api_error,
    retry_after_seconds,
)
from database.connection import Database
from database.models import (
    BotRecord,
    BotSubscriber,
    Broadcast,
    BroadcastConsent,
    User,
)

logger = logging.getLogger(__name__)


async def broadcast_free_users(
    database: Database, bot, admin_id: int, message
) -> tuple[int, int]:
    """انسخ رسالة المشرف للمشتركين الموافقين عبر بوت المصنع."""
    async with database.session() as session:
        result = await session.execute(
            select(BotSubscriber.user_id)
            .join(BotRecord, BotSubscriber.bot_id == BotRecord.id)
            .join(BroadcastConsent, BroadcastConsent.user_id == BotSubscriber.user_id)
            .where(
                BotRecord.tier == "free",
                BotRecord.enabled.is_(True),
                BroadcastConsent.opted_in.is_(True),
            )
            .distinct()
        )
        recipient_ids = result.scalars().all()
        record = Broadcast(
            admin_id=admin_id,
            text=message.text or message.caption or "[وسائط]",
            attempted=len(recipient_ids),
            delivered=0,
        )
        session.add(record)
        await session.flush()
        broadcast_id = record.id
        await session.commit()

    delivered = 0
    for user_id in recipient_ids:
        try:
            await copy_message_to(message, bot, user_id)
            delivered += 1
        except Exception as error:
            if is_forbidden_error(error):
                logger.info("المستخدم %s منع الرسائل أو حظر البوت", user_id)
            elif (retry_after := retry_after_seconds(error)) is not None:
                logger.warning(
                    "حدّ تيليجرام من سرعة الإذاعة؛ انتظار %s ثانية", retry_after
                )
                await asyncio.sleep(retry_after)
            elif is_telegram_api_error(error):
                logger.warning(
                    "تعذر إرسال إذاعة إلى المستخدم %s", user_id, exc_info=True
                )
            else:
                raise
        await asyncio.sleep(0.04)
    async with database.session() as session:
        record = await session.get(Broadcast, broadcast_id)
        if record:
            record.delivered = delivered
            await session.commit()
    return len(recipient_ids), delivered


async def broadcast_factory_users(
    database: Database, bot, admin_id: int, message
) -> tuple[int, int]:
    """Copy an admin message to factory users who opted in to broadcasts."""
    async with database.session() as session:
        result = await session.execute(
            select(User.telegram_id)
            .join(BroadcastConsent, BroadcastConsent.user_id == User.telegram_id)
            .where(BroadcastConsent.opted_in.is_(True))
            .distinct()
        )
        recipient_ids = result.scalars().all()
        record = Broadcast(
            admin_id=admin_id,
            text=message.text or message.caption or "[وسائط]",
            attempted=len(recipient_ids),
            delivered=0,
        )
        session.add(record)
        await session.flush()
        broadcast_id = record.id
        await session.commit()

    delivered = 0
    for user_id in recipient_ids:
        try:
            await copy_message_to(message, bot, user_id)
            delivered += 1
        except Exception as error:
            if is_forbidden_error(error):
                logger.info("المستخدم %s منع الرسائل أو حظر البوت", user_id)
            elif (retry_after := retry_after_seconds(error)) is not None:
                logger.warning(
                    "حدّ تيليجرام من سرعة إذاعة الصانع؛ انتظار %s ثانية",
                    retry_after,
                )
                await asyncio.sleep(retry_after)
            elif is_telegram_api_error(error):
                logger.warning(
                    "تعذر إرسال إذاعة الصانع إلى المستخدم %s",
                    user_id,
                    exc_info=True,
                )
            else:
                raise
        await asyncio.sleep(0.04)

    async with database.session() as session:
        record = await session.get(Broadcast, broadcast_id)
        if record:
            record.delivered = delivered
            await session.commit()
    return len(recipient_ids), delivered
